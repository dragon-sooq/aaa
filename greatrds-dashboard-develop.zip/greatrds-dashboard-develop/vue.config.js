const webpack = require('webpack');
const path = require('path');
const CompressionPlugin = require('compression-webpack-plugin');
const AddAssetHtmlPlugin = require('add-asset-html-webpack-plugin');
// const UglifyPlugin = require('uglifyjs-webpack-plugin');
const TerserPlugin = require('terser-webpack-plugin');
let { version, openGzip, library } = require('./package.json');
const projectConfg = require('./config/project.conf');
// const proxy = require('http-proxy-middleware');
version = version.replace(/\./g, '_');

module.exports = {
  pages: {
    index: {
      entry: projectConfg.projectFilePath,
      template: 'public/index.html'
    }
  },
  // css: {
  //   loaderOptions: {
  //     less: {
  //       modifyVars: {
  //         'primary-color': '#C14141',
  //         'link-color': '#C14141',
  //         'border-radius-base': '2px',
  //       },
  //       javascriptEnabled: true,
  //     },
  //   },
  // },
  publicPath: '/',
  outputDir: 'dist', // 输出文件目录
  assetsDir: 'static',
  lintOnSave: false, // eslint-loader 是否在保存的时候检查
  integrity: false, // 启用该选项可以提供额外的安全性
  filenameHashing: false,
  productionSourceMap: false,
  runtimeCompiler: true,
  transpileDependencies: [
    'vue-echarts',
    'resize-detector'
  ],
  chainWebpack: (config) => {
    // 修复HMR
    config.resolve.symlinks(true);
    // 别名配置
    config.resolve.alias.set('@', path.resolve(__dirname, './src'));
    if (process.env.NODE_ENV === 'production') {
      config.plugin('extract-css').tap(() => [{
        filename: 'static/css/[name].css?v=[chunkhash:8]',
        chunkFilename: 'static/css/[name].css?v=[chunkhash:8]'
      }]);
    }
  },
  configureWebpack: (config) => {
    if (process.env.NODE_ENV === 'production') {
      config.mode = 'production';

      Object.assign(config, {
        output: {
          ...config.output,
          filename: 'static/js/[name].js?v=[chunkhash:8]',
          chunkFilename: 'static/js/[name].js?v=[chunkhash:8]'
        },
        // optimization,
        plugins: [
          ...config.plugins,
          ...Object.keys(library).map((name) => {
            return new webpack.DllReferencePlugin({
              context: process.cwd(),
              manifest: require(`./libs/package/json/${name}.manifest.json`)
            });
          }),
          new AddAssetHtmlPlugin(Object.keys(library).map((name) => {
            return {
              filepath: require.resolve(path.resolve(`libs/package/js/${name}.${version}.dll.js`)),
              outputPath: 'libs',
              publicPath: 'libs',
              includeSourcemap: false
            };
          })),
          // new UglifyPlugin({
          //   uglifyOptions: {
          //     warnings: false,
          //     compress: {
          //       drop_console: true, // console
          //       drop_debugger: true,
          //       pure_funcs: ['console.log'] // 移除console
          //     }
          //   }
          // }),
          
          // new TerserPlugin({
          //   sourceMap: false,
          //   terserOptions: {
          //     compress: {
          //       drop_console: true, // console
          //       drop_debugger: true,
          //       pure_funcs: ['console.log'] // 移除console
          //     }
          //   }
          // })
        ]
      });
      if (openGzip) {
        config.plugins = [
          ...config.plugins,
          new CompressionPlugin({
            test: /\.js$|\.html$|\.css/, // 匹配文件名
            threshold: 10240, // 对超过10k的数据压缩
            deleteOriginalAssets: false // 不删除源文件
          })
        ];
      }
    }

    Object.assign(config, {
      // 开发生产共同配置
      plugins: [
        ...config.plugins,
        new webpack.ProvidePlugin({
          jQuery: 'jquery',
          $: 'jquery',
          'windows.jQuery': 'jquery'
        })
      ]
    });
  },
  parallel: require('os').cpus().length > 1, // 是否为 Babel 或 TypeScript 使用 thread-loader。该选项在系统的 CPU 有多于一个内核时自动启用，仅作用于生产构建。
  pwa: {}, // PWA 插件相关配置 see https://github.com/vuejs/vue-cli/tree/dev/packages/%40vue/cli-plugin-pwa
  // webpack-dev-server 相关配置
  devServer: {
    open: process.platform === 'darwin',
    host: 'localhost', // 允许外部ip访问
    port: 8090, // 端口
    https: false, // 启用https
    overlay: {
      warnings: false,
      errors: true
    }, // 错误、警告在页面弹出
    proxy: {
      '/ws': {
        target: ' http://172.16.64.247:5001',
        ws: true,
        changeOrigin: true
       },
       '/sockjs-node': {
          target: ' http://172.16.64.247:5001',
          ws: false,
          changeOrigin: true
       },
      // '/v1': {
      //   // target: 'http://172.16.70.100:8016', // jl本地
      //   // target: 'http://172.16.70.86:8016', // yp本地
      //   // target: 'http://172.16.11.203:8016', // ljh本地
      //   changeOrigin: true, // 允许webSockets跨域
      //   ws: true
      // }
    } // 代理转发配置，用于调试环境
  }
};
