import router from './routers'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { Message } from 'element-ui'
import { Route } from 'vue-router'
import { Getter, Mutation, Action, namespace } from 'vuex-class'
import { constantRoutes } from '@/routers'
import i18n from '@/lang' // Internationalization
import store from './stores/index'
import CACHE from '@/utils/cache'
NProgress.configure({ showSpinner: false })

const whiteList = ['/login', '/auth-redirect']
let flag = true
const getPageTitle = (key: string) => {
  const hasKey = i18n.te(`route.${key}`)
  if (hasKey) {
    const pageName = i18n.t(`route.${key}`)
    return `${pageName} - RDS`
  }
  return 'RDS'
}

router.beforeEach(async(to: Route, _: Route, next: any) => {
  // Start progress bar
  NProgress.start()
  // Determine whether the user has logged in
  let token = CACHE.localStorage.get('token')
  let role = store.getters['user/role']
  if (token) {
    if (to.path === '/login') {
      // If is logged in, redirect to the home page
      next({ path: '/' })
      NProgress.done()
    } else if (flag) {
      // Check whether the user has obtained his permission roles
      try {
        flag = false
        // Note: roles must be a object array! such as: ['admin'] or ['member'] or ['admin', 'member']
        // Generate accessible routes map based on role
        router['options'].routes = constantRoutes // 重置, 以防动态路由不生效
        store.dispatch('permission/GenerateRoutes', role).then((res) => {
          let copyRoutes = router['options'].routes.concat(res)
          router['options'].routes = copyRoutes
          router.addRoutes(res)
        })
        // Dynamically add accessible routes
        // Hack: ensure addRoutes is complete
        // Set the replace: true, so the navigation will not leave a history record
        next({ ...to, replace: true })
      } catch (err) {
        // Remove token and redirect to login page
        // user.ResetToken()
        Message.error(err || 'Has Error')
        next(`/login?redirect=${to.path}`)
        NProgress.done()
      }
    } else {
      next()
    }
  } else if (whiteList.indexOf(to.path) !== -1) {
    // In the free login whitelist, go directly
    next()
  } else {
    // Other pages that do not have permission to access are redirected to the login page.
    next(`/login?redirect=${to.path}`)
    NProgress.done()
  }
})

router.afterEach((to: Route) => {
  // Finish progress bar
  NProgress.done()

  // set page title
  document.title = getPageTitle(to.meta.title)
})
