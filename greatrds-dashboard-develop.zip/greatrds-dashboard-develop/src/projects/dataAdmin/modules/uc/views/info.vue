<template>
  <div class="uc-info-containers">
    <!-- 头部 -->
    <containers-header
      title="demo2"
      current-title="test1"
    />
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import ContainersHeader from '../../../components/containersHeader.vue'
const userModule = namespace('user')
const contactModule = namespace('contact')

@Component({
  components: {
    ContainersHeader
  }
})
export default class UcInfo extends Vue {
  @Getter loading;
  @userModule.Getter('userInfo') loginUser; // 获取当前登录用户信息
  @contactModule.Getter('companyId') cachCompanyId;

  userInfo: any = {};
  userId: any = '';
  companyId: number = 0;

  created() {
    let that = this
    that.userInfo = that.loginUser
    that.userId = that.userInfo.id
    let companyId = that.cachCompanyId
    that.companyId = companyId
  }
}
</script>
<style lang="scss" scope>
  .uc-info-containers{
    color: #333;
    background: #f4f5f6;
    // height: 100vh;
    height: 100%;
    display: flex;
    flex-direction: column;
  }
</style>
