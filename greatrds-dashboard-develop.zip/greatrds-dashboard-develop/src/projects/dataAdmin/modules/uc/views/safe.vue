<template>
  <div class="uc-safe-containers">
    <!-- 头部 -->
    <containers-header
      title="我的"
      current-title="账户与安全"
    />
    <ul class="clearfix es-uc-safe">
      <li class="clearfix padding-15 border-b-solid">
        <i class="fa fa-shouji pull-left" />
        <el-button
          class="width-100 pull-left mt-10"
          type="primary"
          plain
        >
          test
        </el-button>
      </li>
    </ul>
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
const userModule = namespace('user')

@Component
export default class UcSafe extends Vue {
  @Getter loading;

  created() {
  }
}
</script>
<style lang="scss" scope>
  .uc-safe-containers{
    color: #333;
    background: #fff;
    height: 100%;
    .es-uc-safe{
      i{
        margin-right: 15px;
        font-size: 48px;
        color: #00a3f2;
      }
      .is-plain{
        margin-top: 7px;
      }
    }
    .wechat-tip{
      margin-top: 20px;
      margin-left: 15px;
      font-size: 14px
    }
  }
</style>
