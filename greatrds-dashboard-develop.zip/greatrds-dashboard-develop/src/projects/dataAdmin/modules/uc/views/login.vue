<template>
  <div class="ice-layout ice-blank-layout">
    <div
      class="login-page"
    >
      <div class="user-login-common user-login">
        <h2 class="es-logo-lg">
          logo位置
        </h2>
        <div class="es-loginreg-box clearfix">
          <el-tabs
            tab-position="let"
            v-model="activeName"
            style="height: 65px;"
            @tab-click="resetForm('loginForm')"
          >
            <el-tab-pane
              v-for="tab in tabList"
              :key="tab.label"
              :label="tab.label"
              :name="tab.name"
            />
          </el-tabs>
          <el-form
            class="login-form"
            :model="loginForm"
            ref="loginForm"
            :rules="loginRules"
            @submit.native.prevent
          >
            <el-form-item
              v-if="activeName === 'email'"
              prop="email"
              label
              :rules="[
                { required: true, message: '请输入邮箱', trigger: 'blur' },
                { type: 'email', message: '请输入正确的邮箱地址', trigger: ['blur'] }
              ]"
            >
              <el-input
                v-model="loginForm.email"
                placeholder="请输入邮箱"
              />
            </el-form-item>
            <el-form-item
              v-if="activeName !== 'code'"
              prop="password"
            >
              <el-input
                type="password"
                v-model="loginForm.password"
                autocomplete="off"
                :minlength="6"
                :maxlength="20"
                placeholder="请输入6到20位密码"
              />
            </el-form-item>
            <el-form-item class="clearfix mb-0">
              <el-checkbox
                class="pull-left"
                v-model="loginForm.remember"
              >
                7天自动登录
              </el-checkbox>
              <el-link
                :underline="false"
                class="pull-right text-gray-9"
                href="#/forget"
              >
                忘记密码
              </el-link>
            </el-form-item>
            <el-form-item class="mb-0">
              <el-button
                class="width-all"
                native-type="submit"
                type="primary"
                :loading="loading"
                @click="submitForm('loginForm')"
              >
                {{ btn.submit }}
              </el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { Getter, Mutation, namespace } from 'vuex-class'
import { getLocationHref, getRequestLinkStr } from '@/utils/url'
import { getCountries } from '@/utils/business'
import MD5 from 'crypto-js/md5'
const userModule = namespace('user')
const companyModule = namespace('company')

@Component
export default class Login extends Vue {
  @Getter loading;
  @userModule.Action('saveUserAndToken') updateUserAndToken;
  @companyModule.Action('saveCompany') updateCompany;

  private activeName: any = '';
  private tabList: any[] = [
    {
      label: '邮箱登录',
      name: 'email'
    }
  ];
  private loginForm: any = {
    remember: false, // 七天自动登录
    mobile: '',
    email: '',
    securityCode: '',
    countryCode: '',
    password: ''
  };
  private captcha: any = {
    text: '获取验证码',
    disabled: false
  };
  private btn: any = {
    submit: '登 录'
  };
  private openid: any = '';
  private unionid: any = '';
  private wxCode: any = '';
  private loginRules: any = {};
  private countryCodes: any[] = [];

  created() {
    let that = this
    let validatePwd = (rule: any, value: any, callback: any) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (value.length < 6) {
          callback(new Error('密码为6-20位字符，区分大小写'))
        }
        callback()
      }
    }
    let checkCode = (rule: any, value: any, callback: any) => {
      if (!value) {
        return callback(new Error('请输入验证码'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('请输入数字值'))
        } else {
          callback()
        }
      }, 1000)
    }
    // 表单验证规则
    that.loginRules = {
      password: [{ validator: validatePwd, trigger: 'blur' }],
      securityCode: {
        validator: checkCode,
        trigger: 'blur'
      }
    }
    // 初始化登录类型
    that.activeName = 'email'
  }

  /**
   * 关闭验证码定时器
   */
  cancelMobileInterval() {
    let that = this
    clearInterval(that.captcha.dsq)
    that.captcha.text = '获取验证码'
    that.captcha.disabled = false
  }

  /**
   * 重置表单验证
   */
  resetForm(formName: string) {
    let that = this
    that.$nextTick(() => {
      (that.$refs[formName] as any).clearValidate() // 移除验证
    })
  }

  /**
   * 提交
   */
  submitForm(formName: any) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: boolean) => {
      if (valid) {
        that.doSubmit()
      }
    })
  }
  async doSubmit() {
    let that = this
    // 组装参数
    let {
      remember,
      mobile,
      password,
      countryCode,
      securityCode,
      email
    } = that.loginForm
    let ajaxData: any = {}
    console.log(mobile, password)
    password = MD5(password).toString()
    let ajaxPre = ''
    ajaxData.email = email
    ajaxData.password = password
    ajaxPre = 'usercenter/u/emailLogin'
    // 增加不验证token
    ajaxData.skipAuth = true
    // 缓存用户信息
  }

}
</script>
<style lang="scss">
.user-login {
  .el-tabs__nav-scroll {
    background-color: #e9eef1;
    height: 48px;
    .el-tabs__nav {
      width: 100%;
    }
    .el-tabs__item {
      text-align: center;
      height: 48px;
      line-height: 48px;
      width: 33.33333%;
      border-bottom: 2px solid #e9eef1;
    }
    .is-active {
      border-bottom: 2px solid #409eff;
    }
  }
  .el-select .el-input {
    width: 130px;
  }
  .login-form {
    padding: 5px 15px;
    .el-input-group__append {
      padding: 10px;
      .el-button {
        display: block;
        width: 130px;
      }
    }
    .input-with-select .el-input-group__prepend {
      background-color: #fff;
    }
  }
  .wx-icon {
    float: left;
    margin-top: 13px;
    margin-right: 5px;
  }
}
</style>
