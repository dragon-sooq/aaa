<template>
  <div class="uc-safe-containers">
    <!-- 头部 -->
    <containers-header
      title="demo"
      current-title="12"
    />
    <div class="privacy-box">
      <div class="privacy-title">
        test
      </div>
      <div class="clearfix privacy-item">
        <div class="pull-left">
          <p>
            test1
          </p>
          <p class="font-12 text-gray-6">
            test12
          </p>
        </div>
        <span class="text-second col-xs-8 pull-right">
          123
        </span>
      </div>
      <div class="line" />
      <div class="privacy-title">
        test3
      </div>
    </div>
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'

@Component
export default class UcPrivacy extends Vue {
}
</script>
<style lang="scss" scope>
  .uc-safe-containers{
    color: #333;
    background: #fff;
    height: 100%;
    // height: 100vh;
    // 分割线
    .line{
      height: 10px;
      background: #f4f5f6;
    }
    .privacy-box{
      font-size: 14px;
      background: #fff;
      .privacy-title{
        font-size: 12px;
        color: #666;
        padding: 10px 0;
        margin-left: 15px;
        border-bottom: 1px solid #eee;
      }
      .privacy-item{
        &:first-child{
          padding: 20px 0 10px 0;
          border: none;
        }
        padding: 20px 20px 20px 0;
        margin-left: 15px;
        border-bottom: 1px solid #eee;
        &:last-child{
          border: none;
        }
      }
    }
  }
</style>
