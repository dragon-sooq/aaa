<template>
  <div class="uc-about-us-containers">
    <!-- 头部 -->
    <containers-header
      title="我的"
      current-title="关于我们"
    />
  </div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import ContainersHeader from '../../../components/containersHeader.vue'

@Component({
  components: {
    ContainersHeader
  }
})
export default class UcAboutUs extends Vue {
  cooperationCaseList: any[] = [];
}
</script>
<style lang="scss" scope>
  .uc-about-us-containers{
    font-size: 14px;
    color: #333;
    background: #fff;
    // height: 100vh;
    height: 100%;
    .line-30{
      line-height: 30px;
    }
    .hide{
      display: none;
    }
  }
</style>
