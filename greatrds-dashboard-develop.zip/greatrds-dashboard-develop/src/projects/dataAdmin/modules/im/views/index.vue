<template>
  <div>SQL操作</div>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'

@Component
export default class IM extends Vue {}
</script>
