<template>
  <!-- header-->
  <el-header class="el-layout-header logined">
    <div class="header-container clearfix">
      <div class="header-left">
        <a
          href="#/"
          class="header-title"
        >DB</a>
      </div>
      <div class="header-center">
        <ul class="el-menu--horizontal el-menu">
          <li
            class="el-menu-item"
            v-for="(v,vindex) in headnavs"
            :key="vindex"
            :class="{'is-active':$route.name.indexOf(v.name)>-1}"
          >
            <a
              :href="'/#/dash/'+v.path"
              :target="v.target?'_blank':'_self'"
            >{{ v.meta.title }}</a>
          </li>
        </ul>
      </div>
      <div class="header-right">
        <el-dropdown
          @command="handleCommand"
          class="ml"
        >
          <div class="user-box">
            <span class="user-name ml-5">root</span>
          </div>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="logout">
              <i class="fa fa-exit" />退出
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </el-header><!-- ./header-->
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
const userModule = namespace('user')
const companyModule = namespace('company')

@Component
export default class EsHeader extends Vue {
  @userModule.Getter('userInfo') loginUser;
  @userModule.Action('removeUserAndCompany') removeUserAndCompany;
  @companyModule.Getter('company') company;

  // 顶部导航s
  private headnavs: any = [];

  created() {
    let that = this
    let router: any = (that as any).$router
    that.headnavs = router.options.routes[0].children
  }

  // 右上角操作更多
  handleCommand(command: string) {
    let that = this
    if (command === 'logout') {
      that.logout()
    }
  }
  // 退出登录
  async logout() {
    let that = this
    await (that as any).removeUserAndCompany();
    (that as any).$router.push({
      name: 'Login'
    })
  }
}
</script>
<style lang="scss">
.el-layout-header {
  background-color: #2a3f54;
  color: #fff;
  padding: 0 15px;
  height: 60px;
  line-height: 60px;
  overflow: hidden;
  &.logined {
    .header-title {
      font-size: 16px;
    }
    .user-name {
      color: #fff;
    }
    .user-face {
      background: #fff;
    }
  }
  .grid-content {
    font-weight: bold;
  }
  .header-left {
    float: left;
    width: 350px;
    @media (max-width: 1260px) {
      width: 280px;
    }
    .header-title {
      font-family: "Myriad Pro", "Helvetica Neue", Arial, Helvetica, sans-serif;
      font-weight: 600;
      display: inline-block;
      vertical-align: middle;
      padding-left: 50px;
      height: 40px;
      line-height: 40px;
    }
  }
  .header-center {
    float: left;
    margin-left: 50px;
    @media (max-width: 1300px) {
      margin-left: 15px;
    }
  }
  .header-right {
    float: right;
  }
  .el-menu {
    background: transparent;
  }
  .el-menu-item {
    padding: 0 30px;
  }
  .el-menu-item.is-active {
    color: #fff;
  }
  .el-menu-item:not(.is-disabled):hover {
    background: transparent;
    color: #fff;
  }
  .user-face {
    display: inline-block;
    width: 35px;
    height: 35px;
    border-radius: 50px;
    text-align: center;
    vertical-align: middle;
    margin-top: -5px;
    line-height: 38px;
    overflow: hidden;
    .fa-ren {
      font-size: 18px;
      color: #2290ff;
    }
  }
  .user-name {
    cursor: pointer;
    font-size: 15px;
  }
}
</style>
