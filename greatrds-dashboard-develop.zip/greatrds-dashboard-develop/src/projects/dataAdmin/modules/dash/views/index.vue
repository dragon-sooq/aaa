<template>
  <el-container
    class="el-layout fixed"
    :class="{'had-aside': $route.name.indexOf('Things')>-1 || $route.name.indexOf('Uc')>-1, 'overflow-hide': isOverflowHide}"
  >
    <EsHeader />
    <el-container class="el-layout-content">
      <el-aside
        class="el-layout-aside"
        width="200px"
      >
        <el-menu
          :default-active="menuNow"
          :router="true"
        >
          <template
            v-for="(v, vind) in menuList"
          >
            <div
              :key="vind"
              v-if="!v.meta.hide"
            >
              <el-submenu
                :index="'/dash/'+v.path"
                v-if="v.children && v.children.length"
              >
                <template slot="title">
                  <i
                    class="fa mr-5"
                    :class="v.meta.icon"
                    v-if="v.meta.icon"
                  />
                  <span>{{ v.meta.title }}</span>
                </template>
                <template v-for="(vv, vvind) in v.children">
                  <el-menu-item
                    :key="vvind"
                    :index="'/dash/'+v.path+'/'+vv.path"
                    v-if="!vv.meta.hide"
                  >
                    <span slot="title">{{ vv.meta.title }}</span>
                  </el-menu-item>
                </template>
              </el-submenu>
              <el-menu-item
                :index="'/dash/'+v.path"
                v-else
              >
                <i
                  class="fa"
                  :class="v.meta.icon"
                  v-if="v.meta.icon"
                />
                <span slot="title">{{ v.meta.title }}</span>
              </el-menu-item>
            </div>
          </template>
        </el-menu>
      </el-aside>
      <el-main class="el-layout-main">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>
<script lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import { Getter } from 'vuex-class'
import EsHeader from '../components/header.vue'

@Component({
  components: {
    EsHeader
  }
})
export default class Dash extends Vue {
  // 是否锁定滚动条
  @Getter isOverflowHide;

  get menuList() {
    const that: any = this
    if (that.$route && that.$route.name) {
      if (that.$route.name.indexOf('Things') > -1) {
        return that.$router.options.routes[0].children[2].children || []
      } else if (that.$route.name.indexOf('Uc') > -1) {
        return [that.$router.options.routes[0].children[3]] || []
      }
    } else {
      return []
    }
  }
  get menuNow() {
    return (this as any).$route.path
  }

}
</script>
<style lang="scss">
.el-layout {
  &.fixed {
    .el-layout-header {
      position: fixed;
      top: 0;
      right: 0;
      left: 0;
      z-index: 99;
    }
    .el-layout-content {
      min-height: 100vh;
    }
    .el-layout-aside {
      display: none;
      position: fixed;
      top: 60px;
      left: 0;
      bottom: 0;
      z-index: 99;
      overflow-x: hidden;
      overflow-y: auto;
      .el-menu--horizontal {
        border-bottom: none;
      }
      .el-menu-item {
        font-size: 13px;
      }
    }
    .el-layout-main {
      padding: 65px 10px 0 10px;
      background: #f9f9f9;
    }
  }
  &.had-aside{
    .el-layout-aside {
      display: block;
    }
    .el-layout-main {
      margin-left: 200px;
    }
  }
  &.overflow-hide{
    .el-layout-main {
      overflow: hidden;
    }
  }
}

// 面包屑
.el-breadcrumb__inner.is-link,
.el-breadcrumb__inner a {
  color: #2290ff;
  font-weight: 400;
}
</style>
