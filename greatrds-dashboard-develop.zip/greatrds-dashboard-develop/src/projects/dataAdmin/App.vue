<template>
  <div
    id="app"
    class="app-warpper"
    :class="{'iframe': $root.isIframe}"
  >
    <link
      type="text/css"
      rel="stylesheet"
    >
    <transition
      name="el-fade-in"
      mode="out-in"
    >
      <router-view />
    </transition>
    <div
      role="dialog"
      v-show="esModal !== null"
    >
      <transition name="fade">
        <component
          :is="esModal"
        />
      </transition>
    </div>
  </div>
</template>
<script  lang="ts">
import { Vue, Component } from 'vue-property-decorator'
import Utils from '@/utils'

@Component
export default class App extends Vue {
  private esModal: any = null;
  private isSetRealName: boolean = false;

  mounted() {
    const that = this
    // 基于屏幕检测尺寸
    that.watchWindow()
    window.onresize = that.watchWindow
  }

  /**
   * 基于屏幕检测尺寸
   */
  watchWindow = Utils.Lodash.debounce(() => {
    let commonSize =
      document.body.clientWidth && document.body.clientWidth <= 1360 ?
        'small' :
        'medium'
    if (commonSize !== (this as any).$root.commonSize) {
      (this as any).$root.commonSize = commonSize
    }
  }, 300);
}
</script>
<style lang="scss">
@import './assets/css/core.scss';

.app-warpper{
  // iframe下隐藏头部、左侧菜单栏
  &.iframe{
    .es-header, .es-main .es-aside{
      display: none;
    }
    // 在页面的组件上去添加样式 这样不会导致出现横向的滚动条
    // .es-container-main{
    //   padding: 10px 0 0 10px;
    // }
  }
}

// 样式重置
// 弹窗
.el-dialog{
  margin-top: 5vh !important;
}

</style>
