export default (Vue) => {
  Vue.directive('clickoutside', {
    bind(el, binding) {
      function documentHandler(e) {
        if (el.contains(e.target)) {
          return false
        }
        if (binding.expression) {
          binding.value(e)
        }
      }
      function KeyUp(e) {
        if (e.keyCode === 27) {
          if (binding.expression) {
            binding.value(e)
          }
        }
      }
      el.__vueClickOutSize__ = documentHandler
      el.__vueKeyup__ = KeyUp
      document.addEventListener('keyup', KeyUp)
      document.addEventListener('click', documentHandler)
    },
    unbind(el) {
      document.removeEventListener('click', el.__vueClickOutSize__)
      // eslint-disable-next-line prefer-reflect
      delete el.__vueClickOutSize__
      // eslint-disable-next-line consistent-return
      document.removeEventListener('keyup', el.__vueKeyup__)
      if (el.__vueKeyup__) {
        // eslint-disable-next-line prefer-reflect
        delete el.__vueKeyup__
      }
    }
  })
}
