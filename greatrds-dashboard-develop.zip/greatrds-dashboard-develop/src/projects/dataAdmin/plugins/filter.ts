/**
 * [esFilter description]
 * @type {Object}
 */
import Vue from 'vue'
import { dateFilter } from '@/utils/date'

/**
 * 日期转换[按照通用规则]
 */
Vue.filter('dbDateFilter', (dateVal: any, format: any) => {
  return dateFilter(dateVal, format)
})
