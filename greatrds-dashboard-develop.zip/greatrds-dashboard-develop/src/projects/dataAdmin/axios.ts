import Vue from '@/compkg/configs/main'
import router from './router'
import store from './stores/index'
import jstz from 'jstz'
import { getApiPrefix } from '@/utils/api'
// import CACHE from '@/utils/cache';
import { goLoginConfirm } from '@/utils/token'
let { $axios, $vars, $api, $safeApi, $handleError } = Vue.prototype

// axios 配置
$axios.defaults.baseURL = $api
$axios.defaults.timeout = 25000
$axios.defaults.headers.post['Content-Type'] = 'application/json'
$axios.defaults.headers.routerName = location.hash.split('?')[0]

// 是否正在刷新的标记
let isRefreshing = false
// 重试队列，每一项将是一个待执行的函数形式
let retryRequests = []
// 缓存请求使用token端
let ajaxCacheTokens = {}
// 不显示错误消息的白名单code
const whiteCodeList = ['1011', '1051', '1081']

// Add a request interceptor
$axios.interceptors.request.use((config: any) => {
  let params = config.data || config.params || {}
  // skipLoading 跳过loading状态
  if (!params.skipLoading) {
    store.commit('toggleLoading', true)
  } else {
    Reflect.deleteProperty(params, 'skipLoading')
  }
  // skipAuth 跳过token
  if (!params.skipAuth) {
    // 判断当前页面是否为iframe 检测页面类型确定是否更换api前缀
    const iframePageType = store.getters['user/iframePageType']
    if (parent !== window && iframePageType) {
      // system and 排除oss
      if (iframePageType === 'system' && config.url.indexOf('osscenter/') < 0) {
        params.useSystemToken = true
      } else if (iframePageType === 'admin') {
        params.useAdminToken = true
      } else {
        params.useWebToken = true
      }
    }
    // 获取accessToken
    let userAndToken: any = null
    if (params.useWebToken) { // 强制使用web端token
      config.headers.deviceId = config.headers.channelType = 'pc'
      userAndToken = store.getters['user/userAndTokenWeb']
      if (userAndToken) {
        userAndToken.authcode = 'authcode:pc'
      }
      Reflect.deleteProperty(params, 'useWebToken')
      ajaxCacheTokens[config.url] = {
        source: 'web',
        userToken: userAndToken && userAndToken.userToken
      }
      // 更换api前缀
      if (config.url.indexOf('rest/') < 0) {
        config.url = getApiPrefix('web') + '/rest/' + config.url
      }
    } else {
      userAndToken = store.getters['user/userAndToken']
      ajaxCacheTokens[config.url] = {
        source: iframePageType || 'web',
        userToken: userAndToken && userAndToken.userToken
      }
    }
    // 无userAndToken直接返回
    if (!userAndToken) {
      return config
    }
    const { accessToken } = userAndToken.userToken
    config.headers.accessToken = accessToken
    if (!params.skipSafeApi) { // 是否跳过api加密
      const { authcode } = userAndToken
      return $safeApi(config, authcode).then((res: any) => {
        config.headers.nonce_str = res.nonce_str
        config.headers.sign = res.sign
        return config
      })
    }
    return config
  }
  Reflect.deleteProperty(params, 'skipAuth')
  return config
}, (error: any) => {
  // loading
  store.commit('toggleLoading', false)
  // message
  $handleError($vars.msg.error.api)
  return Promise.reject(error)
})

/**
 * 跳转登录页
 */
const goLogin = () => {
  goLoginConfirm().then(() => {
    // 移除用户缓存 跳转登录页
    store.dispatch('user/removeUserAndCompany').then(() => {
      router.push({
        name: 'Login'
      })
    })
  })
}

// Add a response interceptor
$axios.interceptors.response.use((response: any) => {
  // loading
  store.commit('toggleLoading', false)
  const { data, config } = response
  const { responseType, responseURL } = response && response.request
  if (responseType === 'arraybuffer') { // 导出文件流
    return Promise.resolve(data)
  }
  if (data.code === $vars.ajax.code.success) { // 0000
    // 移除掉ajaxCacheTokens缓存
    let configUrl = config.url.split('/rest/')[1]
    Reflect.deleteProperty(ajaxCacheTokens, configUrl)
    // 保存常用 需要整个data
    if (configUrl === 'common/query/new') {
      return Promise.resolve(data)
    }
    return Promise.resolve(data && data.data)
  }
  // 处理
  const { code } = data
  const errMsg = $vars.code[code] || $vars.msg.error.api
  if (code === '1006') {
    if (!isRefreshing) {
      isRefreshing = true
      // 检测当前是否为web
      let configUrl = config.url.split('/rest/')[1]
      const ajaxSource = ajaxCacheTokens[configUrl]
      if (ajaxSource && ajaxSource.source && ajaxSource.source === 'web' && ajaxSource.userToken) {
        let { refreshToken } = ajaxSource.userToken
        $axios({
          url: 'u/token/referesh',
          method: 'POST',
          params: {
            refreshToken,
            skipLoading: true,
            skipAuth: true
          },
          headers: {
            companyId: config.headers && config.headers.companyId
          }
        }).then((tokenData: any) => {
          // 更新token
          store.dispatch('user/updateTokenWeb', tokenData)
          // 已经刷新了token，将所有队列中的请求进行重试
          // @ts-ignore
          retryRequests.forEach((cb) => cb())
          // 重试完清空这个队列
          retryRequests = []
          return $axios(config)
        }).catch((error) => {
          console.error(error)
          goLogin()
        }).finally(() => {
          isRefreshing = false
        })
      } else {
        // 非web端直接提示要跳转到登录页
        goLogin()
      }
    } else {
      // 正在刷新token，返回一个未执行resolve的promise
      return new Promise((resolve) => {
        // 将resolve放进队列，用一个函数形式来保存，等token刷新后直接执行
        // @ts-ignore
        retryRequests.push(() => {
          resolve($axios(config))
        })
      })
    }
  } else if (code === '1007') {
    goLogin()
  } else if (code === '1058') {
    // 这块后面引用通用 未认证已到期引导认证
    return Promise.reject('请您企业认证')
  } else if (whiteCodeList.indexOf(code) < 0) {
    // [临时]不在白名单中就错误消息提示
    $handleError(errMsg)
  }
  // 错误回执response
  return Promise.reject(response)
}, (error: any) => {
  // loading
  store.commit('toggleLoading', false)
  // message
  $handleError($vars.msg.error.api)
  return Promise.reject(error)
})

export default $axios
