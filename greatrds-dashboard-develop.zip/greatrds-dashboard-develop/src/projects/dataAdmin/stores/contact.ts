/**
 * demo
 */
import CACHE from '@/utils/cache'

const state = {
  statetest: null
}

const getters = {
  demo() {
    return state.statetest || CACHE.sessionStorage.get('demo')
  }
}

/**
 * actions
 */
const actions = {
  // 存储企业
  saveDemo({ commit }: any, data: any) {
    commit('saveDemo2', data)
    return Promise.resolve()
  },
  // 移除缓存
  removeDBCache() {
    // CACHE.sessionStorage.remove('dbcache')
    // return Promise.resolve()
  }
}

/**
 * mutations
 */
const mutations = {
  // saveDemo2: (state: any, playload: any) => {
  //   CACHE.sessionStorage.put('save', playload)
  //   state.company = playload
  // }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
