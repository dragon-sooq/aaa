import Vue from 'vue'
import Vuex from 'vuex' // vuex
import contact from './contact'

Vue.use(Vuex)

// 导出
export default new Vuex.Store({
  state: {
    loading: false,
    isOverflowHide: false // 是否锁定页面不可滚动
  },
  getters: {
    loading(state): boolean {
      return state.loading
    },
    isOverflowHide(state): boolean {
      return state.isOverflowHide
    }
  },
  mutations: {
    toggleLoading(state, playload) {
      state.loading = playload
    },
    toggleOverflowHide(state, playload) {
      state.isOverflowHide = playload
    }
  },
  modules: {
    contact
  }
})
