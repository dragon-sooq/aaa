import Vue from 'vue'
import Router from 'vue-router'
import store from './stores/index'
import axios from 'axios'
import CACHE from '@/utils/cache'

Vue.use(Router)


let router = new Router({
  routes: [{
    path: '/dash',
    name: 'Dash',
    component: () => import('./modules/dash/views/index.vue'),
    meta: {
      title: '首页'
    },
    children: [{
      path: 'im',
      name: 'IM',
      component: () => import('./modules/im/views/index.vue'),
      meta: {
        title: 'SQL'
      }
    }, {
      path: 'uc',
      name: 'Uc',
      component: () => import('./modules/uc/views/index.vue'),
      redirect: { // 重定向
        name: 'UcInfo'
      },
      meta: {
        title: '我的',
        icon: 'fa-my'
      },
      children: [{
        path: 'info',
        name: 'UcInfo',
        component: () => import('./modules/uc/views/info.vue'),
        meta: {
          title: '个人资料'
        }
      }, {
        path: 'safe',
        name: 'UcSafe',
        component: () => import('./modules/uc/views/safe.vue'),
        meta: {
          title: '账户与安全'
        }
      }, {
        path: 'privacy',
        name: 'UcPrivacy',
        component: () => import('./modules/uc/views/privacy.vue'),
        meta: {
          title: '隐私设置'
        }
      }, {
        path: 'aboutUs',
        name: 'UcAboutUs',
        component: () => import('./modules/uc/views/aboutUs.vue'),
        meta: {
          title: '关于我们'
        }
      }]
    }]
  }, {
    path: '/',
    name: 'Login',
    component: () => import('./modules/uc/views/login.vue'),
    meta: {
      title: '登录'
    }
  }]
});

(<any>window).esVueRouter = new Vue()

/**
 * 全局后置钩子
 */
const whiteList: any = {
  'Login': 1,
  'Reg': 1,
  'Forget': 1,
  'Bindphone': 1,
  'Resetpwd': 1,
  'H5': 1,
  'Ui': 1
}
router.beforeEach((to: any, from, next) => {
  // 非白名单 and 非iframe引入
  if (!whiteList[to.name] && parent === window) {
    const userId = store.getters['user/userId']
    const userInfo = store.getters['user/userInfo']
    if (userInfo && userId) {
      // 判断是否已输入真实姓名
      let isSetRealName = CACHE.sessionStorage.get('isSetRealName_' + userId) || false
      if (!isSetRealName) {
        try {
          const company = store.getters['company/company']
          axios.get(`usercenter/u/id/${userId}`, {
            headers: {
              companyId: company && company.id
            }
          }).then((json?: any) => {
            let setRealName = json.setRealName
            CACHE.sessionStorage.put('isSetRealName_' + userId, !!setRealName)
            // 触发提供真实姓名
            if (!setRealName) {
              (window as any).esVueRouter.$emit('isSetRealName', {
                isSetRealName: setRealName
              })
            }
          })
        } catch (error) {
          console.log(error)
        }
      }
    }
  }
  next()
})

/**
 * 全局后置钩子
 */
router.afterEach(() => {
  setTimeout(() => {
    window.scrollTo(0, 0)
  }, 100)
})

export default router

