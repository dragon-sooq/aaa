import Vue from '@/compkg/configs/main'
import directives from './plugins/directives.js'
import i18n from '@/compkg/configs/i18n'
import App from './App.vue'
import router from './router'
import store from './stores/index'
import './axios'
import './plugins/filter'
import DICT from '@/utils/dict'
Vue.use(directives)

const initVue = async() => {
  new Vue({
    router,
    store,
    i18n,
    data: () => {
      return {
        DICT: DICT, // 字典引入为$root数据
        isDark: true, // 是否深色主题
        commonSize: 'medium', // 通用尺寸
        reloadFn: null
      }
    },
    render: (handler) => handler(App)
  }).$mount('#app')
}

initVue()
