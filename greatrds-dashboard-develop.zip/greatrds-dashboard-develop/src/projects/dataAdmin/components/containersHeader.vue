<!--
  通用头部：
    1. title: 标题
    2. currentTitle: 当前标签页
-->
<template>
  <dir class="containers-header">
    <div class="header">
      <div class="header-left">
        <span>{{ title }}</span>
        <span class="fa fa-right" />
        <span class="active">{{ currentTitle }}</span>
      </div>
    </div>
    <div class="line" />
  </dir>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class ContainersHeader extends Vue {
  @Prop(String) readonly title: string
  @Prop(String) readonly currentTitle: string
}
</script>
<style lang="scss">
  .containers-header{
    padding: 0;
    margin: 0;
    .header{
      line-height: 34px;
      background: #fff;
      padding: 8px 15px;
      .header-left{
        font-size: 16px;
        .active{
          color: #2196f3;
        }
      }
    }
    // 分割线
    .line{
      height: 10px;
      background: #f4f5f6;
    }
  }
</style>
