/**
 * 通用获取数据
 * @author Nan
 * @description - 项目中存在多个地方调用同一个接口数据的情况，为保证代码的简洁及接口管理的便捷性，封装所有数据获取的
 *                接口调用到该文件。使用规范：
 *                  1. 方法必须全部通用options的形式传入请求参数
 *                  2. 方法都为同步加载数据，并返回接口返回的数据。
*/

import Vue from '@/compkg/configs/main'
// import DICT from '@/utils/dict';
const { $axios, $vars } = Vue.prototype
const markUrl: string = $vars.ajax.wtBaseURL

namespace Api {

  /**
   * 获取工作表模板
   * @param companyId: 公司id
   * @param templateId: 模板id
   */
  export const getTemplateInfo = (templateId: string, companyId: number) => {
    return $axios({
      url: `${markUrl}/worktablenew/findTemplateById`,
      method: 'GET',
      params: {
        id: templateId
      },
      headers: {
        companyId
      }
    })
  }

  /**
   * 获取工作表实例数据
   */
  export const getTemplateRecord = (recordId: string, companyId: number) => {
    return $axios({
      url: `${markUrl}/worktabledata/findTemplateDataById`,
      method: 'GET',
      params: {
        id: recordId
      },
      headers: {
        companyId
      }
    })
  }

  // 获取字典列表数据
  export const getDictsList = async(options: any) => {
    const res: any = await $axios({
      url: `${markUrl}/worktablenew/findSysDicByCompanyIdToPage`,
      method: 'GET',
      params: options,
      headers: {
        companyId: options.companyId
      }
    })
    return res
  }

  // 获取字典项数据
  export const getDictData = async(options: any) => {
    const res: any = await $axios({
      url: `${markUrl}/worktablenew/findSysDicItemToPage`,
      method: 'GET',
      params: options,
      headers: {
        companyId: options.companyId
      }
    })
    return res
  }

  // 获取供关联表类表数据
  export const getAssociationSheetsList = async(options: any) => {
    const res: any = await $axios({
      url: `${markUrl}/worktablenew/relationTableData/relationTableTemplates`,
      method: 'POST',
      data: options,
      headers: {
        companyId: options.companyId
      }
    })
    return res
  }

  // 获取模板中的项数据
  export const getTemplateFieldsList = async(options: any) => {
    const res: any = await $axios({
      url: `${markUrl}/worktablenew/findTemplateById`,
      method: 'GET',
      params: options,
      headers: {
        companyId: options.companyId
      }
    })
    return res
  }
}

export default Api
