/**
 * 根上的mutations
 */
const mutations = {
  toggleAsideCollapse(state, playload) {
    state.asideCollapse = playload
  },
  toggleLoading(state, playload) {
    state.loading = playload
  },
  toggleBodyHidden(state, playload) {
    state.layoutHidden = playload
  },
  toggleMenuHidden(state, playload) {
    state.menuHidden = playload
  },
  toggleRouterKey(state, playload) {
    state.routerKey = playload
  }
}

export default mutations
