import Vue from 'vue'
import Vuex from 'vuex'
import actions from './actions'
import mutations from './mutations'
import getters from './getters'
import user from '@/stores/modules/user'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    loading: false, // loading状态
    layoutHidden: false, // 窗口锁定
    asideCollapse: false, // 菜单栏左右
    menuHidden: false, // 全部服务列表菜单展示状态
    routerKey: 'rds' // 左侧菜单默认展示rds的一级路由
  },
  actions,
  mutations,
  getters,
  modules: {
    user
  }
})
