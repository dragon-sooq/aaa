/**
 * 根上的getters
 */
const getters = {
  loading(state): boolean {
    return state.loading
  },
  asideCollapse(state): boolean {
    return state.asideCollapse
  },
  layoutHidden(state): boolean {
    return state.layoutHidden
  },
  menuHidden(state): boolean {
    return state.menuHidden
  },
  routerKey(state): boolean {
    return state.routerKey
  }
}

export default getters

