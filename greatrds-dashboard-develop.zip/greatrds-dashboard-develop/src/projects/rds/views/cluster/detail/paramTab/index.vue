
<template>
  <div class="table-containers">
    qwe
  </div>
</template>
<script lang='ts'>

import { Vue, Component, Prop } from 'vue-property-decorator'
import { Drawer } from '@/compkg/components/index'
interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer
  }
})
class ProjectComponent extends Vue {
}
export default ProjectComponent
</script>

