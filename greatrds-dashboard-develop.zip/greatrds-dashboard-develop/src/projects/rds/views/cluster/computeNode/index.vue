<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <!-- 项目详情弹窗 -->
    <Drawer
      :title="currentNode.hostname"
      :visible.sync="isViewShow"
      :show-modal="false"
    >
      <Detail
        :data-source="currentNode"
      />
    </Drawer>
  </div>
</template>
<script lang='ts'>

import { Vue, Component } from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import { Drawer } from '@/compkg/components'
import Detail from './detail.vue'

interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Table,
    Detail
  }
})
class NodeComponent extends Vue {
  private isViewShow: boolean = false
  private currentNode: object = {}

  private like: string = '' // 搜索字段
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  public tableDataSource: object = {
    btnConfig: {
      // left: true,
      dropdownList: [{
        titleName: '操作',
        list: [
          {
            name: '启用',
            disabled: true
          },
          {
            name: '禁用',
            disabled: true
          }
        ]
      }],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tabsConfig: {
      activeName: '节点',
      list: [{
        id: 1,
        label: '节点',
        name: '节点'
      }]
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '主机名称',
          prop: 'hostname',
          scopedSlots: { customRender: 'templateCode' },
          sortable: 'custom',
          click: (row) => {
            this.showDetail(row)
          }
        }, {
          label: '实例数目',
          prop: 'total_instances'
        }, {
          label: '运行实例',
          prop: 'running_instances'
        }, {
          label: '节点id',
          prop: 'uuid'
        }, {
          label: '启用状态',
          prop: 'enabled',
          filter: 'dbStatusFilter'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  /**
   * 表格的排序条件发生变化时触发
   * @param item - 当前表格对象项及order
   */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  showDetail(item: object) {
    this.isViewShow = false
    this.isViewShow = true
    this.currentNode = item
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.choosedIds = list.map((chooseItem: any) => chooseItem.uuid)
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (item['name'] === '启用') {
        item['disabled'] = list.length === 0
      } else if (item['name'] === '禁用') {
        item['disabled'] = list.length === 0
      }
    })
  }

  /**
   * @description 头部按钮操作
   */
  btnOperation(name: string) {
    if (name === '启用' && this.choosedIds.length) {
      this.handleChangeStatus('enable')
    } else if (name === '禁用' && this.choosedIds.length) {
      this.handleChangeStatus('disable')
    }
  }

  /**
   * 改变节点状态 启用/禁用
   * @param status
   */
  handleChangeStatus(status: string) {
    let items = this.choosedIds
    this.$confirm('是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.changeStatus(item, status)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
  * 改变节点状态 启用/禁用
  */
  async changeStatus(id, status) {
    try {
      await this.$axios({
        method: 'get',
        url: `/rds/hosts/${id}/${status}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}状态变更成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 获取列表
   */
  async getList() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/hosts',
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      this.tableDataSource['tableConfig'].data = json.hosts || []
      this.tableDataSource['pageConfig'].totalCount = json.total
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default NodeComponent
</script>

