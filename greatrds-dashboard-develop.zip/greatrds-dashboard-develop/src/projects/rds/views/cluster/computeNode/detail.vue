<template>
  <div class="common-detail">
    <el-row>
      <el-col :span="24">
        <h4>
          基本属性
        </h4>
      </el-col>
    </el-row>
    <template v-for="(item, index) in detailInfoList">
      <el-row :key="index">
        <el-col :span="2">
          <span>
            {{ item.name }}
          </span>
        </el-col>
        <el-col :span="12">
          <div>
            {{ filterValue(nodeInfo[item.value], item.filter) }}
          </div>
        </el-col>
      </el-row>
    </template>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Drawer } from '@/compkg/components'
@Component({
  components: {
    Drawer
  }
})
class NodeDetailComponent extends Vue {
  @Prop({required: true}) dataSource: any
  private nodeInfo: object = this.dataSource
  private detailInfoList: object[] = [
    {name: '主机ID', value: 'uuid', filter: ''},
    {name: '主机名称', value: 'hostname', filter: ''},
    {name: '物理内存', value: 'mem_total', filter: ''},
    {name: '空闲内存', value: 'mem_free', filter: ''},
    {name: '可用内存', value: 'mem_available', filter: ''},
    {name: '处理器数目', value: 'cpus', filter: ''},
    {name: '处理器负载', value: 'cpu_used', filter: ''},
    {name: '实例数目', value: 'total_instances', filter: ''},
    {name: '运行实例', value: 'running_instances', filter: ''},
    {name: '暂停实例', value: 'paused_instances', filter: ''},
    {name: '停止实例', value: 'stopped_instances', filter: ''},
    {name: '系统架构', value: 'architecture', filter: ''},
    {name: '操作系统', value: 'os_type', filter: ''},
    {name: '系统详情', value: 'os', filter: ''},
    {name: '启用状态', value: 'enabled', filter: 'dbStatusFilter'},
    {name: '内核版本', value: 'kernel_version', filter: ''},
    {name: '标签', value: 'labels', filter: 'dbLabelFilter'},
    {name: '创建时间', value: 'created_at', filter: 'dbDateFilter'},
    {name: '更新时间', value: 'updated_at', filter: 'dbDateFilter'}
  ]

  /**
  * 过滤器
  * @param value 展示数据
  * @param filter 过滤器名称
  * @returns 过滤后的展示数据
  */
  filterValue(value: string, filter: any) {
    /**
     * filter: string or array
        参考：filter: 'esNullFilter' or
        [
          {
            name: 'dateStrFilter',
            arg: ['YYYY-MM-DD HH:mm']
          },
          'esNullFilter'
        ]
    */
    let val = value
    if (filter) {
      if (Vue.filter(filter)) {
        val = Vue.filter(filter)(val)
      } else if (Array.isArray(filter)) {
        filter.forEach((item: any) => {
          if (typeof item === 'string' && Vue.filter(item)) {
            val = Vue.filter(item)(val)
          }
          if (typeof item === 'object' && Vue.filter(item.name)) {
            const { name, arg } = item
            val = Reflect.apply(Vue.filter(name), null, [val, ...arg])
          }
        })
      }
    }
    return val
  }

  created() {
  }
}
export default NodeDetailComponent
</script>

<style lang="scss">
</style>

