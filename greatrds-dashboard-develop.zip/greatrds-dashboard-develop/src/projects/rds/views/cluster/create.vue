
<template>
  <div
    class="cluster-containers"
  >
    <el-form
      ref="clusterForm" 
      label-position="left"
      :model="clusterForm"
      size="small"
      label-width="140px"
      :rules="rules"
    >
      <el-row :gutter="12">
        <el-card>
          <el-col :span="12">
            <el-form-item
              label="集群名称:"
              prop="name"
            >
              <el-input
                v-model="clusterForm.name"
                style="width: 40%;"
              />
            </el-form-item>

            <el-form-item
              label="集群模板:"
            >
              <el-radio-group
                size="small"
                v-model="clusterForm.cluster_template_id"
              >
                <el-radio-button
                  :label="item.uuid"
                  v-for="item in clusterList"
                  :key="item.name"
                >
                  {{ item.name }}
                </el-radio-button>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              label="集群类型:"
            >
              <span>
                {{ currentTemplate.cluster_type || '暂无' }}
              </span>
            </el-form-item>

            <el-form-item
              label="操作系统版本:"
            >
              <span>
                {{ currentTemplate.cluster_distro || '暂无' }}
              </span>
            </el-form-item>

            <el-form-item
              label="集群版本:"
            >
              <span>
                {{ currentTemplate.cluster_version || '暂无' }}
              </span>
            </el-form-item>

            <el-form-item
              label="服务器类型:"
            >
              <span>
                {{ currentTemplate.server_type || '暂无' }}
              </span>
            </el-form-item>
          </el-col>

        <!-- <el-col :span="12">
          <img
            v-if="radio1 === '分布式'"
            src="../../assets/images/jq.png"
            class="logo mr-5"
          >
          <img
            v-else
            style="height: 200px; width: 100%;"
            src="../../assets/images/jq2.png"
            class="logo mr-5"
          >
        </el-col> -->
        </el-card>
      </el-row>

      <el-row :gutter="12">
        <el-card style="margin-top: 10px;">
          <el-form-item label="主机数量:">
            <el-slider
              v-model="clusterForm.host_count"
              :min="1"
              :max="maxHostCount"
              style="width: 20%;"
            />
          </el-form-item>

          <el-form-item label="分片数量:">
            <el-slider
              v-model="clusterForm.partition_count"
              @change="($event) => changeCount($event, 'partition')"
              :min="1"
              :max="maxHostCount"
              style="width: 20%;"
            />
          </el-form-item>

          <el-form-item label="冗余数量:">
            <el-slider
              v-model="clusterForm.slave_count"
              :min="1"
              :max="maxHostCount"
              style="width: 20%;"
            />
          </el-form-item>

          <el-form-item label="调度节点数量:">
            <el-slider
              v-model="clusterForm.scheduler_count"
              :min="1"
              :max="maxHostCount"
              @change="($event) => changeCount($event, 'scheduler')"
              style="width: 20%;"
            />
          </el-form-item>

          <el-form-item label="vip:">
            <el-input
              v-model="clusterForm.address"
              :controls="false"
              style="width: 20%;"
            />
          </el-form-item>
        </el-card>
      </el-row>

      <el-row :gutter="12">
        <el-card
          style="margin-top: 10px; height: 40%; min-height: 0;"
        >
          <el-form-item label="参数模板:">
            <el-select
              placeholder="请选择"
              size="small"
              style="width: 20%;"
              v-model="clusterForm.configuration_id"
            >
              <el-option
                v-for="item in templateList"
                :key="item.uuid"
                size="small"
                :label="item.name"
                :value="item.uuid"
              />
            </el-select>
            <el-link
              type="primary"
              class="ml-10"
            >
              <router-link
                target="_blank" 
                :to="{ path:'/ops/template' }"
              >
                查看参数模板
              </router-link>
            </el-link>
          </el-form-item>
        </el-card>
      </el-row>

      <el-row :gutter="12">
        <el-card style="margin-top: 10px; margin-bottom: 5%;">
          <el-form-item label="设置密码:">
            <el-radio-group
              size="small"
              v-model="setPwd"
            >
              <el-radio-button label="现在设置" />
              <el-radio-button label="创建后设置" />
            </el-radio-group>
          </el-form-item>

          <el-form-item
            label="管理员账户名:"
          >
            <span>
              root
            </span>
          </el-form-item>

          <el-form-item
            v-if="setPwd === '现在设置'"
            label="管理员密码:"
            prop="password"
          >
            <div>
              <el-input
                placeholder="请输入密码"
                size="small"
                v-model="clusterForm.password"
                :disabled="setPwd === '创建后设置'"
                style="width: 20%;"
                show-password
              />
              <div class="create-tip font-12">
                请妥善管理密码，系统无法获取您设置的密码内容。
              </div>
            </div>
          </el-form-item>

          <el-form-item
            v-if="setPwd === '现在设置'"
            label="确认密码:"
            prop="confirmPwd"
          >
            <el-input
              v-model="clusterForm.confirmPwd"
              placeholder="请输入密码"
              size="small"
              :disabled="!clusterForm.password || setPwd === '创建后设置'"
              style="width: 20%;"
              show-password
            />
          </el-form-item>
        </el-card>
      </el-row>
    </el-form>
    <div
      class="city-buy-layer"
      style="width: 100%; border-top: 1px solid rgba(0, 0, 0, 0.1); height: 80px; left: 0px;"
    >
      <div class="cti-buy-layer-wrapper">
        <div class="cti-buyLayer-right">
          <div
            class="cti-buyLayer-right"
            style="width: 92px !important; min-width: 92px !important; padding-top: 15px;"
          >
            <el-button
              type="primary"
              @click="submitForm('clusterForm')"
            >
              创建
            </el-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Utils from '@/utils'
import Table from '@/compkg/components/Table/index.vue'
import echarts from 'echarts'
import { Drawer, Banner } from '@/compkg/components/index'

@Component({
  components: {
    Table,
    Drawer,
    Banner
  }
})
class WorkTableListComponent extends Vue {
  private clusterForm: Object = {
    name: '', // 模板名称
    cluster_template_id: '', // 集群模板id
    configuration_id: '', // 配置
    host_count: 1, // 主机数量
    partition_count: 1, // 分片数量
    slave_count: 1, // 冗余节点数量
    scheduler_count: 1, // 调度节点数量
    address: null, // vip
    username: 'root', // 用户名
    password: '', // 密码
    confirmPwd: ''
  };
  private customColor: Array<Object> = [
    {color: '#f56c6c', percentage: 20},
    {color: '#e6a23c', percentage: 40},
    {color: '#5cb87a', percentage: 60},
    {color: '#1989fa', percentage: 80},
    {color: '#6f7ad3', percentage: 100}
  ];
  private maxHostCount: number = 0; // 主机最大可选数量
  private partationMax: number = 0; // 分片可选最大数量
  private partationMin: number = 0; // 
  private currentTemplate: Object = {}; // 当前选中集群模板
  private clusterList: Array<Object> = [];
  private templateList: Array<Object> = []; // 参数模板list
  private templateRadio: String = '2.5GB';
  private radio1: Number = 0;
  private radio4: String = '可用区1';
  private setPwd: String = '现在设置';
  private websock: any = null;
  private tableData: Array<Object> = [
    {
      gg: '2.5GB',
      zd: '1.5GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '42/512Mbit/s',
      db: '256'
    }, {
      gg: '4GB',
      zd: '3.2GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '42/512Mbit/s',
      db: '256'
    }, {
      gg: '8GB',
      zd: '6.4GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '42/512Mbit/s',
      db: '256'
    }, {
      gg: '16GB',
      zd: '12.8GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '85/3072Mbit/s',
      db: '256'
    }, {
      gg: '4.2GB',
      zd: '3.2GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '85/3072Mbit/s',
      db: '256'
    }, {
      gg: '64GB',
      zd: '51.2GB',
      cc: 'DRAM',
      zdl: '10,000',
      jz: '64/1536Mbit/s',
      db: '256'
    }
  ];
  public options: any = {
    xAxis: {
      type: 'category',
      data: ['15:30:00', '15:30:15', '15:30:45', '15:31:00', '15:31:15', '15:31:45', '15:32:00']
    },
    yAxis: {
      type: 'value'
    },
    series: [{
      data: [13, 20, 7, 4, 18, 11, 2, 18],
      type: 'line'
    }]
  };
  private checkConfirmPwd: any = (rule, value, callback) => {
    if (this.setPwd === '现在设置') {
      if (!value) {
        return callback(new Error('密码不能为空'))
      }
      setTimeout(() => {
        if (value.length < 6) {
          callback(new Error('密码长度需要大于等于六位'))
        } else if (value !== this.clusterForm['password']) {
          callback(new Error('两次输入密码不同 请检查'))
        } else {
          callback()
        }
      }, 1000)
    }
  };
  private checkPwd: any = (rule, value, callback) => {
    if (this.setPwd === '现在设置') {
      if (!value) {
        return callback(new Error('密码不能为空'))
      }
      setTimeout(() => {
        if (value.length < 6) {
          callback(new Error('密码长度需要大于等于六位'))
        } else if (value !== this.clusterForm['password']) {
          callback(new Error('两次输入密码不同 请检查'))
        } else {
          callback()
        }
      }, 1000)
    }
  };
  private rules: Object = {
    name: [
      { required: true, message: '请填写集群名称', trigger: 'blur' }
    ],
    pwd: [
      { validator: this.checkConfirmPwd, trigger: 'blur' }
    ],
    password: [
      { validator: this.checkPwd, trigger: 'blur' }
    ],
    confirmPwd: [
      { validator: this.checkPwd, trigger: 'blur' }
    ]
  }

  /**
   * @description 确保分片/调度节点数量 拖动时 两个和相加不大于主机数量
   */
  changeCount(val: number, type: string) {
    console.log(val, type)
    if (type === 'partition' && (val + this.clusterForm['scheduler_count'] < this.maxHostCount)) {
      // 当前值是分片数量
      this.clusterForm['partition_count'] = this.maxHostCount - this.clusterForm['scheduler_count']
    } else if (val + this.clusterForm['partition_count'] < this.maxHostCount) {
      this.clusterForm['scheduler_count'] = this.maxHostCount - this.clusterForm['partition_count']
    }
  }

  format(percentage: number) {
    console.log(percentage)
    return percentage === 100 ? '满' : percentage
  }

  created() {
    this.getClusterTemplate()
    this.getTemplateList()
  }

  /**
   * @description 获取集群模板
   */
  async getClusterTemplate() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/cluster_template'
      })
      this.clusterList = json.clustertemplates || []
      if (this.clusterList.length) {
        this.clusterForm['cluster_template_id'] = this.clusterList[0]['uuid']
        this.getAvailablCount() // 通过当前集群模板获取可用主机数量
        this.currentTemplate = this.clusterList[0]
      }
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 获取当前选择集群模板的可用主机数量
   */
  async getAvailablCount() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: `/rds/hosts/${this.clusterForm['cluster_template_id']}/availabl_count`
      })
      this.maxHostCount = json
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 获取参数模板列表
   */
  async getTemplateList() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/configurations',
        params: {
          public: true
        }
      })
      console.log(json)
      this.templateList = json.configurations || []
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 验证表单
   */
  submitForm(formName: any) {
    this.$refs[formName]['validate']((valid) => {
      if (valid) {
        console.log(this.clusterForm)
        Reflect.deleteProperty(this.clusterForm, 'confirmPwd')
        console.log(this.clusterForm)
        this.createCluster()
      } else {
        console.log('error submit!!')
        return false
      }
    })
  }

  async createCluster() {
    try {
      let json = await this.$axios({
        method: 'POST',
        url: '/rds/cluster',
        data: this.clusterForm
      })
      console.log(json)
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 跳转模板页面
   */
  jumpTemplate() {
    let routeData = this.$router.resolve({
      name: 'detail'
    })
    window.open(routeData.href, '_blank')
  }
}
export default WorkTableListComponent
</script>
<style lang="scss" scoped>
.cluster-containers{
  .el-table__header tr,
  .el-table__header th {
    padding: 0;
    height: 40px;
  }
  .create-tip {
    // float: left;
    margin-left: 10px;
    line-height: 32px;
    color: #999;
  }
  .city-buy-layer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    min-width: 1260px;
    height: 80px;
    box-shadow: 0 0 6px 0 rgba(0,0,0,.1);
    background: #fff;
    z-index: 10;
    padding-left: 48px;
    *zoom: 1;
    .cti-buy-layer-wrapper {
      width: 100%;
      padding: 0 30px;
      height: 100%;
      margin: 0 auto;
      .cti-buyLayer-right {
        width: 60%;
        text-align: right;
        float: right;
        height: 100%;
        position: relative;
      }
    }
  }  
  .list-main{
    height: 100%;
    display: flex;
    flex-direction: column;
    .create-btns{
      flex-shrink: 0;
    }
    .table-list-container{
      flex: 1;
      height: 0;
    }
  }
}
</style>
