
<template>
  <div class="cluster-monitoring-containers">
    <iframe
      src="http://172.16.70.243/pages/charts/echarts"
      frameborder="0"
      style="width:100%; height: 100%;"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Utils from '@/utils'
import Table from '@/compkg/components/Table/index.vue'
import echarts from 'echarts'
import { Drawer } from '@/compkg/components/index'

@Component({
  components: {
    Table,
    Drawer
  }
})
class WorkTableListComponent extends Vue {
  private radio1: string = '分布式';
  private radio2: string = '性能模式';
  private radio3: string = '可用区1';
  private radio4: string = '可用区1';
  private radio5: string = '现在设置';
  public options: any = {
    xAxis: {
      type: 'category',
      data: ['15:30:00', '15:30:15', '15:30:45', '15:31:00', '15:31:15', '15:31:45', '15:32:00']
    },
    yAxis: {
      type: 'value'
    },
    series: [{
      data: [13, 20, 7, 4, 18, 11, 2, 18],
      type: 'line'
    }]
  }

  mounted() {
    console.log(this.$refs.chart)
    const Chart = echarts.init(this.$refs.chart as HTMLCanvasElement)
    const Chart1 = echarts.init(this.$refs.chart1 as HTMLCanvasElement)
    Chart.setOption(this.options)
    Chart1.setOption(this.options)
  }

}
export default WorkTableListComponent
</script>
<style lang="scss" scoped>
.cluster-monitoring-containers{
  height: 100%;
  .el-main {
    padding: 0;
  }
}
</style>
