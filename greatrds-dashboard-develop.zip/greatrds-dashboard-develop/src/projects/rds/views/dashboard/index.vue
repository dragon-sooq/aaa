<template>
  <div class="dashboard-container">
    <component :is="currentRole" />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
import CACHE from '@/utils/cache'
import AdminDashboard from './admin/index.vue'
import MemberDashboard from './member/index.vue'

@Component({
  name: 'Dashboard',
  components: {
    AdminDashboard,
    MemberDashboard
  }
})
export default class extends Vue {
  private currentRole = 'admin-dashboard'

  get roles() {
    return CACHE.localStorage.get('role')
  }

  created() {
    if (this.roles !== 'admin') {
      this.currentRole = 'member-dashboard'
    }
  }
}
</script>
