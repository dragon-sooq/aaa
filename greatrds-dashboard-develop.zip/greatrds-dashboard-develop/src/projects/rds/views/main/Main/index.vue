<template>
  <router-view v-if="isRouterAlive" />
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'
@Component
class MainComponent extends Vue {
  private isRouterAlive = true;

  created() {
    this.$root['reloadFn'] = this.reload
  }

  reload() {
    this.isRouterAlive = false
    this.$nextTick(() => (this.isRouterAlive = true))
  }

}

export default MainComponent
</script>
