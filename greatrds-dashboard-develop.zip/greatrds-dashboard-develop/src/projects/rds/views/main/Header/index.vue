<template>
  <el-row class="wt-layout-header">
    <el-col
      :span="12"
      style="margin-top: -0.3%; height: 100%;"
    >
      <div
        class="header-title"
        @click="goRouter('Dash')"
      >
        <!-- <img
          src="../../../assets/images/logo_03.png"
          class="logo mr-5"
          title="万里开源"
        > -->
      </div>
      <!-- <i
        class="el-icon-s-operation cursor-p font-24"
        @click="showMenu=!showMenu"
      /> -->
      <el-dropdown
        style="margin-left: 15px;"
        @command="handleCommand"
        v-if="userAndToken.role === 'member'"
        trigger="click"
      >
        <span
          class="wt-layout-header-trigger font-12"
          style="color: #fff;
            font-weight: 500;"
        >
          <i class="el-icon-coin mr-3" />
          <span>{{ currentProject }}</span>
          <i class="el-icon-arrow-down" />
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item
            v-for="item in userAndToken.projects"
            :key="item.id"
          >
            <div @click="changeProject(item)">
              {{ item.name }}
            </div>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <el-select
        style="margin-left: 15px;"
        v-if="userAndToken.role === 'member'"
        v-model="regionVal"
        placeholder="请选择"
      >
        <el-option
          v-for="group in userAndToken.regions"
          :key="group.name"
          :label="group.name"
          :value="group.name"
        />
      </el-select>
    </el-col>
    <el-col
      :span="12"
    >
      <el-dropdown
        @command="handleCommand"
        class="pull-right"
        v-if="userAndToken"
      >
        <span class="wt-layout-header-trigger">
          <i class="fa fa-people mr-3" />
          <span>{{ userAndToken.username }}</span>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="logout">
            <i class="fa fa-exit" />退出
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <span
        class="wt-layout-header-trigger pull-right"
        @click="refeshPage()"
      >
        <i class="el-icon-bell" />
      </span>
    </el-col>
    <Drawer 
      v-if="showMenu"
      :direction="'ltr'"
      :width="'37%'"
      :visible.sync="showMenu"
    >
      <Menu />
    </Drawer>
  </el-row>
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'
import { Getter, Mutation, namespace } from 'vuex-class'
import { Drawer, Menu } from '@/compkg/components/index'
import i18n from '@/compkg/configs/i18n'
const userModule = namespace('user')
const companyModule = namespace('company')

@Component({
  components: {
    Menu,
    Drawer
  }
})
class HeaderComponent extends Vue {
  // @Getter asideCollapse;
  @userModule.Getter('userInfo') userAndToken;
  @userModule.Action('LogOut') logoutUser;
  // @Mutation('toggleAsideCollapse') toggleAsideCollapse;
  private regionVal: string = 'BJ';
  private currentProject: string = '';
  private showMenu: boolean = false;

  mounted() {
    this.initProject()
  }

  /**
   * 从项目列表中查找当前所属project
   */
  initProject() {
    if (this.userAndToken.role === 'member') {
      this.userAndToken.projects.forEach((item: Object) => {
        if (item['current_project']) {
          this.currentProject = item['name']
        }
      })
    }
  }

  // 刷新当前页组件
  refeshPage() {
    this.$root['reloadFn'] && this.$root['reloadFn']()
  }

  // 右上角操作更多
  handleCommand(command: string) {
    if (command === 'logout') {
      this.logout()
    } else if (command === 'zh' || command === 'en') {
      i18n.locale = command
    }
  }

  /**
   * 切换项目
   */
  async changeProject(project: Object) {
    console.log(project)
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${project['id']}`
      })
      console.log(json)
      that.currentProject = project['name']
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * 退出登录
   */
  async logout() {
    const that = this
    await that.logoutUser()
    that.goRouter('Login')
  }

  /**
   * 跳转路由
   */
  goRouter(name) {
    const that = this
    that['$router'].push({
      name,
      query: {}
    })
  }
}

export default HeaderComponent
</script>

<style lang="scss">
.wt-layout-header {
  padding-left: 15px;
  padding-right: 15px;
  background-color: #333854;//#fff;
  color: #ADB0B8;//#333;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  transition: all 0.2s ease-in-out;
  height: 100%;
  overflow: hidden;
  .el-input__inner {
    color: #ADB0B8;
    border-radius: 2px;
    border: 1px solid #4d516a;
    background: #4d516a;
    &:hover, &.active {
      border: 1px solid #4d516a;
      transition: color 0.3s linear;
      color: #fff;
    }
  }
  .el-input--suffix {
    &:hover, &.active {
      border: 0px;
      transition: color 0.3s linear;
    }
  }
  .header-title {
    font-size: 14px;
    height: 40px;
    display: inline-block;
    cursor: pointer;
    .logo{
      vertical-align: middle;
      height: 115%;
    }
  }
  .region-view {
    padding: 20px;
    .area-title {
      background-color: #f8f8f9;
      display: block;
      clear: both;
      padding: 4px 10px;
      margin-bottom: 10px;
    }
    .region-city-box {
      column-count: 3;
      column-width: 120px;
      column-gap: 12px;
    }
    .region-city {
      margin-bottom: 10px;
      display: inline-block;
      width: 100%;
      break-inside: avoid;
    }
    .city-title {
      height: 30px;
      line-height: 30px;
      font-size: 12px;
      font-weight: 300;
      color: rgb(136, 136, 136);
      padding: 0px 10px;
      transition: all 250ms linear 0s;
    }
    .region-item {
      a > .item {
        cursor: pointer;
        display: block;
        padding: 5px 10px;
        &:hover, &.active {
          background-color: rgba(36, 104, 242, 0.1);
        }
      }
    }
  }
}
.wt-layout-header-trigger {
  display: inline-block;
  width: auto;
  margin-left: 10px;
  height: 50px;
  font-size: 18px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s ease-in-out;
  color:#ADB0B8;
  &:hover {
    // background: #f8f8f9;
    transition: color 0.3s linear;
    color: #FFF
  }
}
.wt-layout-header-breadcrumb {
  display: inline-block;
  margin-left: 30px;
  .el-breadcrumb__inner a, .el-breadcrumb__inner.is-link,
  .el-breadcrumb__item:last-child .el-breadcrumb__inner, .el-breadcrumb__item:last-child .el-breadcrumb__inner a, .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover, .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover{
    color:#2f2f2f;
  }
}
</style>
