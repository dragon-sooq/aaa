<template>
  <div class="one">
    <el-scrollbar
      :native="false"
      class="common-aside"
      :noresize="true"
      tag="div"
    >
      <el-menu
        :unique-opened="true"
        :default-active="routeMenu"
      >
        <div
          class="aside-item"
          @mouseenter="enterMenuEvent"
          @mouseleave="leaveMenuEvent"
          @click="checkMenuEvent"
        >
          <p 
            class="title"
          >
            <i class="el-icon-s-operation title-icon" />
            <span style="margin-left: 2px;">服务列表</span>
          </p>
        </div>
        <div class="sidebar-line" />
        <template
          v-for="(v, ind) in $router.options.routes"
        >
          <template v-if="v.meta && !v.meta.isAsideHide">
            <!-- 概览 -->
            <div
              class="aside-item"
              :class="{'active-tab': $route.meta.breadcrumb === v.meta.breadcrumb}"
              @click="goRoute(v.name)"
              :key="ind"
              v-if="v.name === 'Dashboard'"
            >
              <p 
                class="title"
              >
                <i class="el-icon-s-home title-icon" />
                <span style="margin-left: 2px;">{{ v.meta.breadcrumb }}</span>
              </p>
            </div>
            <!-- 其他路由 -->
            <el-submenu 
              :index="'' + ind"
              :key="ind"
              v-if="v.meta && v.meta.categoryKey === routerKey"
            >
              <template 
                slot="title"
                style="padding-left: 13px"
              >
                <i
                  class="title-icon"
                  :class="v.meta.iconName"
                />
                <span>{{ v.meta.breadcrumb }}</span>
              </template>
              <template
                v-for="(vv, vvindex) in v.children"
              >
                <el-menu-item 
                  :key="vvindex"
                  :index="ind + '-' + vvindex"
                  v-if="vv.meta && !vv.meta.isAsideHide"
                  @click="goRoute(vv.name)"
                  :class="{'active-tab': $route.meta.breadcrumb === vv.meta.breadcrumb}"
                >
                  {{ vv.meta.breadcrumb }}
                </el-menu-item>
              </template>
            </el-submenu>
          </template>
        </template>
        <!-- <el-submenu
          :index="v.name"
          :key="vindex"
        >
          <template slot="title">
            <span>{{ v.meta && v.meta.breadcrumb }}</span>
          </template>
          <el-menu-item
            v-for="(vv, vvindex) in v.children"
            :key="vvindex"
            :index="vv.name"
            @click="goRoute(vv.name)"
          >
            <i
              class="fa"
              :class="vv.meta.icon"
              v-if="vv.meta && vv.meta.icon"
            />
            <span
              class="title"
              slot="title"
            >{{ vv.meta && vv.meta.breadcrumb }}</span>
          </el-menu-item>
        </el-submenu> -->
      </el-menu>
    </el-scrollbar>
    <div
      class="all-menulist"
      @mouseenter="enterMenuCont"
      @mouseleave="leaveMenuCont"
      :class="menuHidden ? 'show-menulist' : ''"
    >
      <Menu />
    </div>
  </div>
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'
import { Getter, Mutation } from 'vuex-class'
import { Menu } from '@/compkg/components/index'

@Component({
  components: {
    Menu
  }
})

class AsideComponent extends Vue {

  @Mutation('toggleMenuHidden') toggleMenuHidden;
  @Getter menuHidden;
  @Getter routerKey;

  // 是否收起左侧菜单栏
  // @Getter asideCollapse;
  private showMenu: boolean = false;

  // 获取当前路由
  get routeMenu() {
    const routeNow = (this as any).$route
    return (routeNow.meta && routeNow.meta.menu) || routeNow.name
  }

  // 点击切换服务列表展示状态，并清空状态值
  checkMenuEvent() {
    this.toggleMenuHidden(!this.menuHidden)
  }

  // 滑入菜单列表
  enterMenuCont() {
    this.toggleMenuHidden(true)
  }

  // 移出菜单列表
  leaveMenuCont() {
    this.toggleMenuHidden(false)
  }

  // 鼠标滑入‘服务列表’，设置状态，侧边栏展开状态并展示全部菜单
  enterMenuEvent() {
    this.toggleMenuHidden(true)
  }

  // 鼠标离开‘服务列表’，收起全部
  leaveMenuEvent() {
    this.toggleMenuHidden(false)
  }

  mounted() {
    console.log((this as any).$route)
  }

  /**
   * 跳转路由
   */
  goRoute(routeName: string) {
    console.log(routeName)
    if (routeName) {
      const that: any = this
      that.$router.push({
        name: routeName
      })
    }
  }
}

export default AsideComponent
</script>

<style lang="scss">
.one {
  position: relative;
}
.all-menulist{
  width: 500px;
  height: 100%;
  position: absolute;
  background: white;
  z-index: -50;
  left: -500px;
  top: 0;
  transition: left .4s cubic-bezier(0,0,.2,1);
}
.show-menulist {
  left: 180px;
}
.common-aside {
  height: 100%;
  // .aside-menu{
  //   width: 100px;
  // }
  .el-submenu .el-menu-item{
    padding-left: 45px !important;
  }
  .active-tab {
    background-color: #526ECC;
    color: #fff;
    i, span {
      color: #fff!important;
    }
  }
  .el-submenu__title{
    height: 44px !important;
    line-height: 44px !important;
    padding-left: 13px !important;
  }
  .el-menu-item {
    height: 44px !important;
    line-height: 44px !important;
  }
  .sidebar-line{
    height: 1px;
    background-color: #dfe1e6;
    width: auto;
  }
  .aside-item {
    width: 180px;
    i, span {
      color: #303133;
    }
    // &:hover {
    //   background: #f2f5fc;
    //   .title-icon {
    //     color: #526ECC;
    //   }
    // }
  }
  .router-title {
    margin: 0;
    padding-left: 20px;
    height: 38px;
    font-size: 12px;
    font-weight: 400;
    line-height: 38px;
    color: #818a91;
  }
  .title-icon {
    margin-right: 12px;
    color: #252b3a;
    display: inline-block;
    font-size: 20px;
  }
  .title {
    display: block;
    height: 38px;
    text-decoration: none;
    line-height: 38px;
    color: #373a3c;
    padding-left: 13px;
    font-weight: 500;
    border-left: 3px solid transparent;
    &:hover{
      color: #526ECC;
      background: 0 0;
      text-decoration: none;
      outline: 0;
      cursor: pointer;
      transition: color .2s ease;
    }
  }
  // .title-icon:before {
  //   position: absolute;
  //   left: 10px;
  //   /*top: 45px;*/
  //   content: "";
  //   width: 2px;
  //   height: 32px;
  //   background: #5e7ce0;
  // }
}
.el-submenu{
  &.is-opened{
    background: #ecf6fd;
    .el-menu{
      background: #ecf6fd;
    }
  }
}
</style>
