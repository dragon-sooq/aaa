import HeaderComponent from './Header/index.vue'
import AsideComponent from './Aside/index.vue'
import MainComponent from './Main/index.vue'
import FooterComponent from './Footer/index.vue'

export class Header extends HeaderComponent {}

export class Aside extends AsideComponent {}

export class Main extends MainComponent {}

export class Footer extends FooterComponent {}
