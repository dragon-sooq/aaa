<template>
  <div class="clearfix">
    footer
  </div>
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'
@Component
class FooterComponent extends Vue {}

export default FooterComponent
</script>
