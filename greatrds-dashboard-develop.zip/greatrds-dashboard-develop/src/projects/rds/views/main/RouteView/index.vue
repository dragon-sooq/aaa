<template>
  <!-- <router-view /> -->
  <transition name="el-fade-in-linear">
    <router-view />
  </transition>
</template>
<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'

@Component
class RouteViewComponent extends Vue {}

export default RouteViewComponent
</script>
