
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import moment from 'moment'
interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Table
  }
})
class AlarmComponent extends Vue {

  private taskData: any = {
    isShow: false
  };

  private like: string = '' // 搜索字段
  private isAdmin: Boolean = true; // 系统默认true / 自定义 false
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  public tableDataSource: object = {
    tabsConfig: {
      activeName: '告警规则',
      list: [{
        id: 1,
        label: '告警规则',
        name: '告警规则'
      }, {
        id: 2,
        label: '告警历史',
        name: '告警历史'
      }],
      change: (name: string) => {
        this.changeTab(name)
      }
    },
    btnConfig: {
      dropdownList: [{
        titleName: '更多操作',
        list: [
          {
            name: '启用',
            disabled: true
          },
          {
            name: '停用',
            disabled: true
          },
          {
            name: '删除',
            disabled: true
          }
        ]
      }],
      list: [
        {
          name: '创建告警规则',
          type: 'danger'
        }
      ],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tableConfig: {
      isMultiple: 1,
      // isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '名称',
          prop: 'name',
          sortable: 'custom',
          click: (row) => {
            this.viewDetail(row)
          }
        },
        {
          label: '资源类型',
          prop: 'cluster_type'
        },
        {
          label: '监控对象',
          prop: 'metric_alias_name',
          filter: 'TaskStatusFilter'
        },
        {
          label: '告警级别',
          prop: 'severity',
          filter: 'AlarmLevelFilter'
        },
        {
          label: '告警策略',
          prop: 'alarmDesc',
          filter: 'dbNullFilter'
        },
        {
          label: '状态',
          prop: 'status',
          filter: 'AlarmRuleStatusFilter'
        },
        {
          label: '最近状态改变时间',
          prop: 'time'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  changeTab(name: String) {
    console.log(name)
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (list.length) {
        this.choosedIds.push(list[0]['uuid'])
        if (list.length === 1) {
          // 只选中一个,把所有按钮置为可用状态
          item['disabled'] = false
          // 如果选中行状态是启用 把
          if (list[0]['status'] === 'up' && item['name'] === '启用') {
            item['disabled'] = true
          } else if (list[0]['status'] === 'down' && item['name'] === '禁用') {
            item['disabled'] = true
          }
        } else {
          item['disabled'] = true
          if (item['name'] === '删除') {
            item['disabled'] = false
          }
          this.choosedIds = list.map((chooseItem: any) => chooseItem.uuid)
        }
        this.choosedIds = Array.from(new Set(this.choosedIds))
      } else {
        item['disabled'] = true
        this.choosedIds = []
      }
    })
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    console.log(name)
    if (name !== '创建告警规则') {
      this.changeAlarmStatus(name)
    } else {
      this.createAlarm()
    }
  }

  /**
   * @description 创建告警规则
   */
  createAlarm() {
    this.$router.push({ path: 'alarmOperation' })
  }

  /**
   * @description 编辑任务
   */
  editTask() {
    let task = this.tableDataSource['tableConfig'].data.filter((data) => data.uuid === this.choosedIds[0])[0]
    this.taskData.isEdit = true
    this.taskData.uuid = this.choosedIds[0]
    this.taskData.resource = task.resource
    this.taskData.type = task.type
    this.taskData.task_name = task.task_name
    this.taskData.isShow = true
  }

  /**
   * @description 告警规则操作 删除 启用 / 禁用
   */
  async changeAlarmStatus(name: string) {
    let that = this
    try {
      await (that as any).$confirm(`确定要${name}这条告警规则吗？`)
      let url = `/rds/cluster/alert/rule/${that.choosedIds[0]}`
      if (name !== '删除') {
        let flag = name === '启用' ? 'enable' : 'disable'
        url += '/' + flag
      }
      let json = await this.$axios({
        method: name !== '删除' ? 'GET' : 'DELETE',
        url: url
      })
      that.getList()
    } catch (error) {
      console.error(error)
    }
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/cluster/alert/rule'
      })
      this.tableDataSource['tableConfig'].data = json.alertrules || []
      this.tableDataSource['tableConfig'].data.forEach((item: any) => {
        item.time = moment(item.updated_at || item.created_at).format('YYYY-MM-DD HH:mm')
        item.alarmDesc = item.metric_alias_name + '  ' + item.expr + item.expr_value + '\n' + '持续' + item.for_time + '个周期' + '则告警' + '   ' + this.handleRepeatVal(item.repeat_interval)
      })
      console.log(this.tableDataSource['tableConfig'].data)
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
   * @description 处理告警重复周期值
   */
  handleRepeatVal(time: number) {
    if (time === 0) {
      return '只告警一次'
    } else if (time === 300) {
      return '每5分钟告警一次'
    } else if (time === 600) {
      return '每10分钟告警一次'
    } else if (time === 900) {
      return '每15分钟告警一次'
    } else if (time === 1800) {
      return '每30分钟告警一次'
    } else if (time === 3600) {
      return '每1小时告警一次'
    } else if (time === 10800) {
      return '每3小时告警一次'
    } else if (time === 21600) {
      return '每6小时告警一次'
    } else if (time === 43200) {
      return '每12小时告警一次'
    } else if (time === 86400) {
      return '每1天告警一次'
    }
  }

  /**
  * 删除角色
  * @param items 选中行
  */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteRole(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
   * @param id 要删除的id
   * @description 删除角色
   */
  async deleteRole(id: String) {
    try {
      let json = await this.$axios({
        method: 'DELETE',
        url: `/auth/roles/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 查看模板详情
   * @param item 当前行
   */
  viewDetail(item: Object) {
    console.log(item['uuid'])
    this.$router.push({ path: `/monitoringAlarm/alarmDetail/${item['uuid']}` })
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default AlarmComponent
</script>

<style lang="scss">
  .schedulers-detail {
    .box-card {
      width: 95%;
    }
  }
</style>

