
<template>
  <div
    class="alarm-detail-containers"
  >
    <el-form
      ref="alarmForm"
      label-position="left"
      :model="alarmForm"
      size="small"
      label-width="140px"
    >
      <el-card style="margin-bottom: 10px;">
        <el-row 
          :gutter="12"
        >
          <el-col
            :span="12"
            style="margin-bottom: 16px;"
          >
            <span
              class="common-title"
            >基本信息</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">告警规则名称</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.name }}</span>
          </el-col>

          <el-col :span="2">
            <span class="second-title">告警规则UUID</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.uuid }}</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">24小时内告警次数</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.alert_times_24 }}</span>
          </el-col>

          <el-col :span="2">
            <span class="second-title">告警级别</span>
          </el-col>
          <el-col :span="10">
            <i
              class="el-icon-bell"
              style="font-size: 18px;"
              :style="{color: alarmForm.severity === 'info' ? '#2b93ec' : ''}"
            />
            <span>{{ alarmForm.severity | AlarmLevelFilter }}</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">72小时内告警次数</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.alert_times_72 }}</span>
          </el-col>

          <el-col :span="2">
            <span class="second-title">告警级别</span>
          </el-col>
          <el-col :span="10">
            <i
              style="font-size: 18px;"
              :class="statusIcon"
              :style="{color: alarmForm.status === 'up' ? '#28cea2' : ''}"
            />
            <span>{{ alarmForm.status | TaskStatusFilter }}</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">描述</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.description | dbNullFilter }}</span>
          </el-col>
        </el-row>
      </el-card>

      <el-card style="margin-bottom: 10px;">
        <el-row 
          :gutter="12"
        >
          <el-col
            :span="12"
            style="margin-bottom: 16px;"
          >
            <span
              class="common-title"
            >监控对象及指标</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">资源类型</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.cluster_type }}</span>
          </el-col>

          <el-col :span="2">
            <span class="second-title">维度</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.member_role }}</span>
          </el-col>
        </el-row>

        <el-row
          :gutter="12"
          style="padding-bottom: 20px;"
        >
          <el-col :span="2">
            <span class="second-title">24小时内告警次数</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.alert_times_24 }}</span>
          </el-col>

          <el-col :span="2">
            <span class="second-title">告警策略</span>
          </el-col>
          <el-col :span="10">
            <span>{{ alarmForm.alarmDesc }}</span>
          </el-col>
        </el-row>
      </el-card>

      <el-card>
        <el-row 
          :gutter="12"
        >
          <el-col
            :span="12"
            style="margin-bottom: 16px;"
          >
            <span
              class="common-title"
            >告警历史</span>
          </el-col>
        </el-row>

        <el-row :gutter="12">
          <el-col
            :span="24"
            style="margin-bottom: 16px;"
          >
            <el-table
              ref="quotaTable"
              :data="alarmForm.alert_history"
              height="250"
              :header-cell-style="getRowClass"
              style="max-height: 200px; overflow: auto;"
            >
              <el-table-column
                prop="alert_name"
                label="告警资源"
              />
              <el-table-column
                prop="time"
                label="产生时间"
              />
              <el-table-column
                prop="alarmDesc"
                label="告警策略"
              />
              <el-table-column
                prop="severity"
                label="告警级别"
              />
            </el-table>
          </el-col>
        </el-row>
      </el-card>
    </el-form>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Utils from '@/utils'
import Table from '@/compkg/components/Table/index.vue'
import echarts from 'echarts'
import moment from 'moment'
import { Drawer, Banner } from '@/compkg/components/index'

@Component({
  components: {
    Table,
    Drawer,
    Banner
  }
})
class WorkTableListComponent extends Vue {
  private alarmForm: Object = {} // 表单model
  private statusIcon: string = ''; // 状态图标名字
  created() {
    this.getClusterTemplate()
  }

  /**
   * @description 获取告警规则详情
   */
  async getClusterTemplate() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: `/rds/cluster/alert/rule/${this.$route.params.id}`
      })
      this.alarmForm = json
      this.statusIcon = this.alarmForm['status'] === 'up' ? 'el-icon-success' : 'el-icon-remove'
      this.alarmForm['alarmDesc'] = this.alarmForm['metric_alias_name'] + '  ' + this.alarmForm['expr'] + this.alarmForm['expr_value'] + '%' + '\n' + '持续' + this.alarmForm['for_time'] + '个周期' + '则告警' + '   ' + this.handleRepeatVal(this.alarmForm['repeat_interval'])
      this.alarmForm['alert_history'].forEach((item: any) => {
        console.log(item.ext_labels['repeat_interval'])
        item.time = moment(item.created_at).format('YYYY-MM-DD HH:mm')
        item.alarmDesc = this.alarmForm['metric_alias_name'] + '  ' + item.ext_labels['expr'] + item.ext_labels['expr_value'] + '%' + '\n' + '持续' + this.alarmForm['for_time'] + '个周期' + '则告警' + '   ' + this.handleRepeatVal(item.ext_labels['repeat_interval'])
        item.severity = this.handleSeverity(item.severity)
      })
      console.log(this)
    } catch (error) {
      this.$handleError(error)
    }
  }

  getRowClass() {
    return 'background:#f0f3fb;color:#4c5360;font-size:9px;font-weight:500;height: 30px;'
  }

  /**
   * @description 处理告警级别
   */
  handleSeverity(val: string) {
    if (val) {
      if (val === 'critical') {
        return '紧急'
      } else if (val === 'major') {
        return '重要'
      } else if (val === 'minor') {
        return '次要'
      } else if (val === 'info') {
        return '提示'
      }
    }
  }

  /**
   * @description 处理告警重复周期值
   */
  handleRepeatVal(time: number | string) {
    if (time === 0 || time === '0') {
      return '只告警一次'
    } else if (time === 300 || time === '300') {
      return '每5分钟告警一次'
    } else if (time === 600 || time === '600') {
      return '每10分钟告警一次'
    } else if (time === 900 || time === '900') {
      return '每15分钟告警一次'
    } else if (time === 1800 || time === '1800') {
      return '每30分钟告警一次'
    } else if (time === 3600 || time === '3600') {
      return '每1小时告警一次'
    } else if (time === 10800 || time === '10800') {
      return '每3小时告警一次'
    } else if (time === 21600 || time === '21600') {
      return '每6小时告警一次'
    } else if (time === 43200 || time === '43200') {
      return '每12小时告警一次'
    } else if (time === 86400 || time === '86400') {
      return '每1天告警一次'
    }
  }
}
export default WorkTableListComponent
</script>
<style lang="scss" scoped>
.alarm-detail-containers{
  .second-title {
    color: #8a8e99;
  }
  > span {
    color: #252b3a;
  }
  .el-table__header tr,
  .el-table__header th {
    padding: 0;
    height: 40px;
  }
  .create-tip {
    // float: left;
    margin-left: 10px;
    line-height: 32px;
    color: #999;
  }
  .city-buy-layer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    min-width: 1260px;
    height: 80px;
    box-shadow: 0 0 6px 0 rgba(0,0,0,.1);
    background: #fff;
    z-index: 10;
    padding-left: 48px;
    *zoom: 1;
    .cti-buy-layer-wrapper {
      width: 100%;
      padding: 0 30px;
      height: 100%;
      margin: 0 auto;
      .cti-buyLayer-right {
        width: 60%;
        text-align: right;
        float: right;
        height: 100%;
        position: relative;
      }
    }
  }  
  .list-main{
    height: 100%;
    display: flex;
    flex-direction: column;
    .create-btns{
      flex-shrink: 0;
    }
    .table-list-container{
      flex: 1;
      height: 0;
    }
  }
}
</style>
