
<template>
  <div
    class="cluster-containers"
  >
    <el-form
      ref="alarmForm" 
      label-position="right"
      :model="alarmForm"
      size="small"
      label-width="110px"
      style="padding-bottom: 80px;"
      :rules="rules"
    >
      <el-row :gutter="12">
        <el-card>
          <el-col :span="12">
            <el-form-item
              label="名称:"
              prop="name"
            >
              <el-input
                v-model="alarmForm.name"
                style="width: 40%;"
              />
            </el-form-item>

            <el-form-item
              label="描述:"
            >
              <el-input
                type="textarea"
                :autosize="{ minRows: 2}"
                placeholder="请输入简介"
                v-model="alarmForm.description"
              />
            </el-form-item>
          </el-col>
        </el-card>
      </el-row>

      <el-row :gutter="12">
        <el-card style="margin-top: 10px;">
          <el-form-item label="资源类型:">
            <el-select
              placeholder="请选择"
              size="small"
              style="width: 20%;"
              v-model="resourceId"
            >
              <el-option
                v-for="item in resourcesList"
                :key="item.id"
                size="small"
                :label="item.label"
                :value="item.id"
              />
            </el-select>
          </el-form-item>

          <el-form-item label="选择集群:">
            <el-select
              placeholder="请选择"
              size="small"
              style="width: 20%;"
              v-model="clusterUUID"
              @change="getDimension()"
            >
              <el-option
                v-for="item in clusterList"
                :key="item.uuid"
                size="small"
                :label="item.name"
                :value="item.uuid"
              />
            </el-select>
          </el-form-item>

          <el-form-item label="维度:">
            <el-radio-group
              size="small"
              v-model="dimesion"
            >
              <el-radio-button
                v-for="dimesions in dimensionList"
                :label="dimesions"
                :key="dimesions"
              >
                {{ dimesions }}
              </el-radio-button>
            </el-radio-group>
          </el-form-item>

          <el-form-item label="">
            <el-transfer
              v-model="alarmForm.members"
              :data="memberList"
              :titles="['全部', '已选']"
            />
          </el-form-item>
        </el-card>
      </el-row>

      <el-row :gutter="12">
        <el-card
          style="margin-top: 10px; height: 40%; min-height: 0;"
        >
          <el-form-item label="告警策略:">
            <el-select
              placeholder="请选择"
              size="small"
              style="width: 14%;"
              v-model="alarmForm.metric_name"
            >
              <el-option
                v-for="item in alarmItemList"
                :key="item.name"
                size="small"
                :label="item.alias_name"
                :value="item.name"
              />
            </el-select>

            <el-select
              placeholder="请选择"
              size="small"
              style="width: 14%; padding-left: 5px;"
              v-model="alarmForm.for_time"
            >
              <el-option
                v-for="item in cycleList"
                :key="item.value"
                size="small"
                :label="item.label"
                :value="item.value"
              />
            </el-select>

            <el-select
              placeholder="请选择"
              size="small"
              style="width: 14%; padding-left: 5px;"
              v-model="alarmForm.expr"
            >
              <el-option
                v-for="item in rangeList"
                :key="item"
                size="small"
                :label="item"
                :value="item"
              />
            </el-select>

            <el-input-number
              v-model="alarmForm.expr_value"
              :controls="false"
            />

            <el-select
              placeholder="请选择"
              size="small"
              style="width: 14%; padding-left: 5px;"
              v-model="alarmForm.repeat_interval"
            >
              <el-option
                v-for="item in alarmTimeList"
                :key="item.value"
                size="small"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>

          <el-form-item label="告警级别:">
            <el-radio-group v-model="alarmForm.severity">
              <el-radio :label="'critical'">紧急</el-radio>
              <el-radio :label="'major'">重要</el-radio>
              <el-radio :label="'minor'">次要</el-radio>
              <el-radio :label="'info'">提示</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-card>
      </el-row>
    </el-form>
    <div
      class="city-buy-layer"
      style="width: 100%; border-top: 1px solid rgba(0, 0, 0, 0.1); height: 80px; left: 0px;"
    >
      <div class="cti-buy-layer-wrapper">
        <div class="cti-buyLayer-right">
          <div
            class="cti-buyLayer-right"
            style="width: 112px !important; min-width: 112px !important; padding-top: 15px;"
          >
            <el-button
              type="primary"
              @click="submitForm('alarmForm')"
            >
              立即创建
            </el-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Utils from '@/utils'
import Table from '@/compkg/components/Table/index.vue'
import echarts from 'echarts'
import { Drawer, Banner } from '@/compkg/components/index'

@Component({
  components: {
    Table,
    Drawer,
    Banner
  }
})
class WorkTableListComponent extends Vue {
  private clusterUUID: String = ''; // 当前选中的集群UUID
  private resourceId: Number = 1; // 当前选中的资源类型ID
  private alarmForm: Object = {
    name: '', // 模板名称
    members: [],
    repeat_interval: 1, // 告警周期
    expr_value: 0, // 告警重复次数
    expr: '>=', // 告警值范围
    severity: 'critical', // 告警级别
    metric_name: '' // 告警项name
  };
  private dimensionList: Array<string> = []; // 维度数组
  private dimesion: String = ''; // 选中的维度
  private clusterList: Array<Object> = []; // 集群数组
  private memberList: Array<Object> = []; // 选择维度后下方穿梭框list
  private alarmItemList: Array<Object> = []; // 需要告警的项list
  private resourcesList: Array<Object> = [
    {
      label: 'MySql主从',
      id: 1
    },
    {
      label: 'MGR',
      id: 2
    },
    {
      label: '分布式数据库',
      id: 3
    }
  ]; // 资源类型list
  private cycleList: Array<Object> = [
    {
      label: '连续1个周期',
      value: 1
    },
    {
      label: '连续2个周期',
      value: 2
    },
    {
      label: '连续3个周期',
      value: 3
    },
    {
      label: '连续4个周期',
      value: 4
    },
    {
      label: '连续5个周期',
      value: 5
    }
  ] // 告警周期list
  private rangeList: Array<Object> = ['>=', '>', '<=', '<', '='] // 告警周期list
  private alarmTimeList: Array<Object> = [
    {
      label: '只告警一次',
      value: 0
    },
    {
      label: '每5分钟告警一次',
      value: 300
    },
    {
      label: '每10分钟告警一次',
      value: 600
    },
    {
      label: '每15分钟告警一次',
      value: 900
    },
    {
      label: '每30分钟告警一次',
      value: 1800
    },
    {
      label: '每1小时告警一次',
      value: 3600
    },
    {
      label: '每3小时告警一次',
      value: 10800
    },
    {
      label: '每6小时告警一次',
      value: 21600
    },
    {
      label: '每12小时告警一次',
      value: 43200
    },
    {
      label: '每1天告警一次',
      value: 86400
    }
  ] // 告警周期list
  private websock: any = null;
  private rules: Object = {
    name: [
      { required: true, message: '请填写告警规则名称', trigger: 'blur' }
    ]
  }

  format(percentage: number) {
    return percentage === 100 ? '满' : percentage
  }

  created() {
    this.getClusterList()
  }

  /**
   * @description 获取可用集群
   */
  async getClusterList() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/cluster'
      })
      this.clusterList = json.clusters || []
      if (this.clusterList.length) {
        this.clusterUUID = this.clusterList[0]['uuid']
        this.getDimension() // 通过默认选中的集群获取维度
      }
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 获取维度
   */
  async getDimension() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/${that.clusterUUID}/monitor_member`
      })
      if (json.length) {
        that.dimensionList = json || []
        that.dimesion = json[1] // 维度默认值
        that.getDimensionResources() // 获取选中维度下的资源
        that.getAlarmItem() // 获取告警项
      }
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 根据选择的集群id和维度id获取告警项
   */
  async getAlarmItem() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/monitor_member/metric/${that.clusterUUID}/${that.dimesion}`
      })
      that.alarmItemList = json.monitormetrics || []
      if (that.alarmItemList.length) {
        that.alarmForm['metric_name'] = json.monitormetrics[0].name
      }
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 获取选中维度下的资源
   */
  async getDimensionResources() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/${that.clusterUUID}/monitor_member/${that.dimesion}`
      })
      if (json.monitor_members) {
        that.memberList = json.monitor_members || []
        that.memberList.forEach((item) => {
          item['key'] = item['uuid']
          item['label'] = item['address'] + '-' + item['name']
        })
      }
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 验证表单
   */
  submitForm(formName: any) {
    this.$refs[formName]['validate']((valid) => {
      if (valid) {
        console.log(this.alarmForm)
        this.createAlarm()
      } else {
        console.log('error submit!!')
        return false
      }
    })
  }

  async createAlarm() {
    try {
      let json = await this.$axios({
        method: 'POST',
        url: `/rds/cluster/alert/rule/${this.clusterUUID}`,
        data: this.alarmForm
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 跳转模板页面
   */
  jumpTemplate() {
    let routeData = this.$router.resolve({
      name: 'detail'
    })
    window.open(routeData.href, '_blank')
  }
}
export default WorkTableListComponent
</script>
<style lang="scss">
.cluster-containers{
  margin-left: 12%;
  margin-right: 12%;
  .el-transfer-panel{
    width: 400px;
    min-height: 120px;
  }
  .el-transfer-panel__list.is-filterable{
      min-height: 120px;
  }
  .el-table__header tr,
  .el-table__header th {
    padding: 0;
    height: 40px;
  }
  .create-tip {
    // float: left;
    margin-left: 10px;
    line-height: 32px;
    color: #999;
  }
  .city-buy-layer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    min-width: 1260px;
    height: 80px;
    box-shadow: 0 0 6px 0 rgba(0,0,0,.1);
    background: #fff;
    z-index: 10;
    padding-left: 48px;
    *zoom: 1;
    .cti-buy-layer-wrapper {
      width: 100%;
      padding: 0 30px;
      height: 100%;
      margin: 0 auto;
      .cti-buyLayer-right {
        width: 60%;
        text-align: right;
        float: right;
        height: 100%;
        position: relative;
      }
    }
  }  
  .list-main{
    height: 100%;
    display: flex;
    flex-direction: column;
    .create-btns{
      flex-shrink: 0;
    }
    .table-list-container{
      flex: 1;
      height: 0;
    }
  }
}
</style>
