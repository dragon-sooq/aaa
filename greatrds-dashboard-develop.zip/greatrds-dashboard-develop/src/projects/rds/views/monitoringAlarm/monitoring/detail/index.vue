
<template>
  <div class="monitoring-containers">
    <div class="dis-inline">
      <el-radio-group
        @change="changeLimit"
        v-model="chooseLimit"
        size="small"
      >
        <el-radio-button label="近1小时" />
        <el-radio-button label="近3小时" />
        <el-radio-button label="近12小时" />
        <el-radio-button label="24小时" />
        <el-radio-button label="近7天" />
      </el-radio-group>指标

      <!-- <date-search :store="store" /> -->
      <el-date-picker
        v-model="customizeTime"
        ref="headerSearchTime"
        type="datetimerange"
        class="header-search-select"
        style="margin-bottom: 8px;"
        :picker-options="$root.DICT.TIME_OPTIONS"
        @change="chooseDate"
        format="yyyy-MM-dd HH:mm"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        align="right"
      />
    </div>

    <div class="pull-right">
      <el-button
        @click="dataSource.isShow = true"
        size="small"
        plain
      >
        设置监控指标
      </el-button>
    </div>
    <el-row :gutter="12">
      <el-col
        v-for="(item, index) in lineChartData"
        :key="index"
        :span="8"
      >
        <div style="height: 273px;">
          <line-chart
            :store="store"
            :chart-data="item"
            :choose-limit="chooseLimit"
          />
        </div>
      </el-col>
      <!-- <div style="height: 253px;">
          <line-chart :chart-data="lineChartData" />
        </div> -->
      <!-- </el-col> -->
    </el-row>

    <Quota
      v-if="dataSource.isShow"
      :data-source="dataSource"
      :store="store"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Store from '../store'
import CACHE from '@/utils/cache'
import LineChart, { ILineChartData } from './card/index.vue'
import Quota from './quota.vue'
import DateSearch from './dateSearch.vue'
import Utils from '@/utils'
import moment from 'moment'
import echarts from 'echarts'

const lineChartData: { [type: string]: ILineChartData } = {
  newVisitis: {
    xData: [],
    yData: []
  }
}

@Component({
  components: {
    DateSearch,
    Quota,
    LineChart
    // ChooseLimit
  }
})
class MonitoringDetailComponent extends Vue {

  // 实例store
  public store: Store;
  private customizeTime: Array<string> = [];
  private start: String = moment().subtract(1, 'hours').format('YYYY-MM-DD HH:mm')
  private end: String = moment().format('YYYY-MM-DD HH:mm')

  private lineChartData = {
  };

  public chooseLimit: String = '近1小时'; // 快捷选择时间


  public dataSource: Object = {
    isShow: false
  }

  constructor() {
    super()
    this.store = new Store(this)
  }

  private monitorView: Array<object> = [
    {
      label: '集群总览',
      value: 1
    },
    {
      label: '数据节点',
      value: 2
    },
    {
      label: '集群性能',
      value: 3
    },
    {
      label: '集群主机',
      value: 4
    },
    {
      label: 'QPS',
      value: 5
    }
  ]
  private select: any = '';
  private value: any = '';

  /**
   * @description 自定义选择时间回调
   */
  chooseDate() {
    if (this.customizeTime.length) {
      this.chooseLimit = ''
      this.start = moment(this.customizeTime[0]).format('YYYY-MM-DD HH:mm')
      this.end = moment(this.customizeTime[1]).format('YYYY-MM-DD HH:mm')
      this.initChart()
    }
  }

  /**
   * @description 重新生成图表
   */
  initChart() {
    this.lineChartData = {}
    this.repeatRequest()
  }

  created() {
    this.store.currentUUID = this.$route.params.uuid
    this.store.currentRole = this.$route.params.role
    if (this.$route.params.clusterUUid) {
      this.store.clusterUUID = this.$route.params.clusterUUid
    }
    this.store.currentUUID = this.$route.params.uuid
    this.getMonitorMetrics() // 获取全部监控指标数据
  }

  /**
   * @description 获取全部监控指标数据
   */
  async getMonitorMetrics() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/monitor_member/metric/${this.store.clusterUUID}/${this.store.currentRole}`
      })
      json.monitormetrics.forEach((item) => {
        item.choosed = false
      })
      this.lineChartData = {}
      this.store.targetList = json.monitormetrics || []
      this.store.choosedList = this.store.targetList.filter((item: any) => (CACHE.localStorage.get('monitor_quota_key') as any).indexOf(item.alias_name) > -1)
      console.log(this.store.choosedList)
      this.repeatRequest()
    } catch (error) {
      (that as any).vmm.$handleError(error)
    }
  }

  /**
   * @description 快捷切换日期范围
   */
  changeLimit(val: any) {
    this.lineChartData = {}
    this.end = moment().format('YYYY-MM-DD HH:mm')
    if (val === '近1小时') {
      this.start = moment().subtract(1, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近3小时') {
      this.start = moment().subtract(3, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近12小时') {
      this.start = moment().subtract(12, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近24小时') {
      this.start = moment().subtract(1, 'days').format('YYYY-MM-DD HH:mm')
    } else {
      this.start = moment().subtract(7, 'days').format('YYYY-MM-DD HH:mm')
    }
    this.initChart()
  }

  async repeatRequest() {
    console.log(this.store.choosedList)
    await Promise.all(this.store.choosedList.map((item) => this.getHistoryMonitoringData(item['name'])))
  }

  /**
   * @description 获取已选监控指标历史数据
   */
  async getHistoryMonitoringData(metricName: any) {
    let that = this
    let data = {
      member_uuid: that.store.currentUUID,
      start: that.start,
      end: that.end
    }
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/monitor_member/metric/${that.store.clusterUUID}/${that.store.currentRole}/${metricName}/history`,
        params: data
      })
      console.log(json)
      if (json.length) {
        let obj: any = {
          name: '',
          unit: '',
          metricName: metricName,
          xData: [],
          yData: []
        }
        obj.name = json[0].metric.metric_alias_name
        obj.unit = json[0].metric.unit
        json[0].values.forEach((item: any) => {
          if (that.chooseLimit !== '近7天') {
            item[0] = moment(item[0] * 1000).format('HH:mm')
          } else {
            item[0] = moment(item[0] * 1000).format('YYYY/MM/DD HH:mm')
          }
          obj.xData.push(item[0])
          obj.yData.push(item[1])
        })
        that.$set(this.lineChartData, json[0].metric.metric_name, obj)
      }
      console.log(this.lineChartData)
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

}
export default MonitoringDetailComponent
</script>
<style lang="scss">
.monitoring-containers{
  min-height: calc(100vh - 100px);
  background: #fff;
  padding: 24px 32px;
  .header-search-select {
    font-size: 18px;
    .el-range-separator {
      line-height: 1.8;
      padding: 0 !important;
    }
    .el-range__icon {
      line-height: 1.8;
    }
    .el-input__inner {
      border-radius: 0;
      border: 0;
      padding-left: 0;
      padding-right: 0;
      box-shadow: none !important;
      border-bottom: 1px solid #d9d9d9;
      vertical-align: middle;
    }
  }
  .el-input__suffix-inner {
    .el-input__icon {
      line-height: 0;
    }
  }
  .input-with-select {
    .el-input-group__prepend {
      background-color: #fff;
    }      
  }
}
</style>
