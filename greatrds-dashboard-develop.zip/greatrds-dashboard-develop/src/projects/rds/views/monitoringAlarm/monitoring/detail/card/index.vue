/* eslint-disable */
<template>
  <div
    class="monitor-card"
    style="height: 100%; width: 100%; margin-top: 15px;"
  >
    <div class="monitor-card-header">
      <span>
        {{ chartName }}
      </span>
      <div
        class="pull-right card-header-max-width"
      >
        <p
          style="border: 1px solid #999;"
          @click="showPlusCard"
        >
          <i
            style="padding: 5px;"
            class="el-icon-full-screen font-16"
          />
        </p>
      </div>
    </div>
    
    <div
      class="monitor-card-body"
    >
      <div class="unit">
        <span style="color: #999">
          {{ unit }}
        </span>
      </div>
    </div>
    <div
      :class="className"
      :id="echartId"
      ref="chart"
      :style="{height: height, width: width}"
    />
    <!-- 放大弹窗 -->
    <PlusCard
      style="height: 100%;"
      :data-source="plusCardData"
      :store="store"
      :chart-data="plusCardData.chartData"
      v-if="plusCardData.isShow"
    />
  </div>
</template>

<script lang="ts">
import echarts, { EChartOption } from 'echarts'
import { Component, Prop, Watch } from 'vue-property-decorator'
import { mixins } from 'vue-class-component'
import PlusCard from './plusCard.vue'
import ResizeMixin from '@/compkg/components/Charts/mixins/resize'

export interface ILineChartData {
  xData: number[]
  yData: number[]
}

@Component({
  name: 'LineChart',
  components: {
    PlusCard
  }
})
export default class extends mixins(ResizeMixin) {
  @Prop({ required: true }) private chartData!: ILineChartData
  @Prop({ required: true }) private chooseLimit: String // 所选日期范围
  @Prop({ default: 'chart' }) private className!: string
  @Prop({ default: '100%' }) private width!: string
  @Prop({ default: '85%' }) private height!: string
  @Watch('chartData', { deep: true })
  @Prop({ required: true }) store: any;
  private chartName: any = ''; // 监控项名称
  private unit: any = ''; // 单位
  private plusCardData: Object = {
    isShow: false,
    chartData: {}
  };
  private onChartDataChange(value: ILineChartData) {
    this.setOptions(value)
  }

  mounted() {
    console.log(this.chartData)
    this.$nextTick(() => {
      console.log(this.chooseLimit)
      this.plusCardData['chartData']['name'] = this.chartName = this.chartData['name']
      this.plusCardData['chartData']['unit'] = this.unit = this.chartData['unit']
      // this.plusCardData['chartData']['xData'] = this.chartData['xData']
      // this.plusCardData['chartData']['yData'] = this.chartData['yData']
      this.plusCardData['chartData']['metricName'] = this.chartData['metricName']
      this.initChart()
    })
  }

  get echartId() {
    return 'echarts' + Math.random() * 100000
  }

  /**
   * @description 弹窗展示图表
   */
  showPlusCard() {
    this.plusCardData['isShow'] = true
  }

  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  }

  private initChart() {
    // this.chart = echarts.init(this.$el as HTMLDivElement, 'macarons')
    this.chart = echarts.init(this.$refs.chart as HTMLCanvasElement)
    this.setOptions(this.chartData)
  }

  private setOptions(chartData: ILineChartData) {
    if (this.chart) {
      this.chart.setOption({
        xAxis: {
          data: chartData.xData,
          boundaryGap: false,
          axisLine: { // x轴线
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: { // 坐标轴刻度标签的相关设置。
            formatter: (params) => {
              if (this.chooseLimit !== '近7天') {
                return params
              }
              let newParamsName = ''// 最终拼接成的字符串
              let paramsNameNumber = params.length// 实际标签的个数
              let provideNumber = 11// 每行能显示的字的个数
              let rowNumber = Math.ceil(paramsNameNumber / provideNumber)// 换行的话，需要显示几行，向上取整
              if (paramsNameNumber > provideNumber) {
                /** 循环每一行,p表示行 */
                for (let row = 0; row < rowNumber; row++) {
                  let tempStr = ''// 表示每一次截取的字符串
                  let start = row * provideNumber// 开始截取的位置
                  let end = start + provideNumber// 结束截取的位置
                  // 此处特殊处理最后一行的索引值
                  if (row === rowNumber - 1) {
                    // 最后一次不换行
                    tempStr = params.substring(start, paramsNameNumber)
                  } else {
                    // 每一次拼接字符串并换行
                    tempStr = params.substring(start, end) + '\n'
                  }
                  newParamsName += tempStr// 最终拼成的字符串
                }

              } else {
                // 将旧标签的值赋给新标签
                newParamsName = params
              }
              // 将最终的字符串返回
              return newParamsName
            }
          }
        },
        grid: {
          left: 20,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: 8
        },
        yAxis: {
          splitLine: { // 网格线
            lineStyle: {
              type: 'dashed' // 设置网格线类型 dotted：虚线   solid:实线
            }
          },
          axisLine: { // y轴线
            show: false
          },
          show: true, // 隐藏或显示
          axisTick: {
            show: false
          }
        },
        // legend: {
        //   data: ['expected', 'actual']
        // },
        series: [{
          name: this.chartName,
          // itemStyle: {
          //   color: '#FF005A',
          //   lineStyle: {
          //     color: '#FF005A',
          //     width: 2
          //   }
          // },
          // smooth: true,
          type: 'line',
          data: chartData.yData,
          showSymbol: false,
          hoverAnimation: true,
          animationDuration: 2800,
          animationEasing: 'cubicInOut',
          itemStyle: {
            normal: {
              color: '#547df0', // 改变折线点的颜色
              lineStyle: {
                color: '#547df0' // 改变折线颜色
              }
            }
          },
          markPoint: {
            symbol: 'triangle',
            symbolSize: 20,
            data: [
              {
                name: '最大值',
                type: 'max'
              },
              {
                name: '最小值',
                type: 'min',
                value: 0
              }
            ]
          }
        }]
      } as EChartOption<EChartOption.SeriesLine>)
      this.showTip()
    }
  }

  showTip() {
    /* eslint-disable */
    let that = this as any
    (this.chart as any).on('mouseover', function(target: HTMLElement) {
      // series name 为 'uuu' 的系列中的图形元素被 'mouseover' 时，此方法被回调。
      console.log(123)
      that.chart.dispatchAction({ 
        type: 'showTip',
        // eslint-disable-next-line id-length
        x: 100,
        // eslint-disable-next-line id-length
        y: 100
      })
    })
  }

  // showEvery() {
    
  // }
}
</script>

<style lang="scss" scoped>
  .monitor-card {
    border: 1px solid #adb0b8;
    .card-header-max-width {
      display: none;
    }
    .monitor-card-header {
      position: relative;
      height: 41px;
      padding: 9px 10px 0 20px;
      background-color: #fff;
    }
    .monitor-card-header > span {
      font-size: 14px;
      color: #252b3a;
    }
    .monitor-card-body {
      .unit {
        z-index: 1;
        padding-left: 20px;
      }
    }
    &:hover{
      border-color: #526ECC;
      background: 0 0;
      text-decoration: none;
      outline: 0;
      cursor: pointer;
      transition: color .2s ease;
    }
    &:hover div {
      display: block;
      transition: all .2s ease-in-out;
    }
  }
</style>
