<!-- 设置监控指标弹窗组件 -->
<template>
  <DialogLayer
    ref="dialog"
    :visible.sync="dataSource.isShow"
    class="monitoring-quota"
    title="设置监控指标"
    :width="'700px'"
    :success="submit"
  >
    <el-alert
      title="选择您在页面中要展示的指标名称，拖动选中指标可以对指标进行排序。"
      :closable="false"
      type="info"
      center
      show-icon
    />
    <div class="mt-15 mb-15">
      <span
        style="line-height: 32px;"
        class="pull-left"
      >
        您选中的指标
      </span>
      <span
        style="line-height:32px; color:#ff4c4c"
        class="pull-left ml-10"
      >
        {{ store.choosedIds.length }}
      </span>
      <br>
      <div class="item-drop clearfix">
        <!-- @end="categoryOrder" -->
        <draggable
          v-model="store.choosedList"
          id="target-drag-item"
        >
          <div
            v-for="(item, index) in store.choosedList"
            :key="index"
            style="display: inline;"
          >
            <div
              class="target-item drag-style mb-5"
              style="vertical-align:middle; width:23%; display: inline-block;"
            >
              <label
                class="target-label"
                :title="item.alias_name"
              >
                {{ item.alias_name }}
              </label>
              <label
                class="el-icon-close cursor-p del-icon"
              />
            </div>
          </div>
        </draggable>
      </div>
    </div>

    <div class="mt-15 mb-15">
      <span
        style="line-height: 32px;"
        class="pull-left"
      >
        全部指标
      </span>
      <span
        style="line-height:32px; color:#ff4c4c"
        class="pull-left ml-10"
      >
        {{ store.targetList.length }}
      </span>
      <div class="monitoring-quota-table">
        <el-table
          ref="quotaTable"
          :data="store.targetList"
          height="250"
          :header-cell-style="getRowClass"
          style="max-height: 200px; overflow: auto;"
          @selection-change="(val) => store.handleSelectionChange(val)"
        >
          <el-table-column
            type="selection"
            width="55"
          />
          <el-table-column
            prop="alias_name"
            label="指标名称"
            width="180"
          />
          <el-table-column
            prop="description"
            label="指标描述"
          />
        </el-table>
      </div>
    </div>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import Draggable from 'vuedraggable'
// import CurrentTable from './table'
import CACHE from '@/utils/cache'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
const quotaModule = namespace('quota')

@Component({
  components: {
    DialogLayer,
    Draggable
    // CurrentTable
  }
})
class MonitoringQuotaComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  @Prop({required: true}) store: any;

  private template: any = null;
  private loading: boolean = false;
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private projectForm: any = {
    name: '',
    description: ''
  };
  private projectRules: Object = {
    name: [{ required: true, message: '请输入项目名称', trigger: 'change' }]
  };

  mounted() {
    this.$nextTick(() => {
      this.initQuota()
    })
  }

  /**
   * @description 如果缓存中有值, 根据localStorage中缓存的key初始化选中的指标 如果没有 把全部指标勾选
   */
  public initQuota() {
    this.store.choosedIds = []
    let ids = this.store.targetList.filter((item: any) => (CACHE.localStorage.get('monitor_quota_key') as any).indexOf(item.alias_name) > -1)
    this.store.choosedIds = ids.map((item: any) => item.alias_name)
    if (this.store.choosedIds.length) {
      this.store.choosedIds.forEach((name: any) => {
        this.store.targetList.forEach((item: any) => {
          if (item.alias_name === name) {
            (this.$refs.quotaTable as any).toggleRowSelection(item, true)
          }
        })
      })
    } else {
      this.store.targetList.forEach((item: any) => {
        (this.$refs.quotaTable as any).toggleRowSelection(item, true)
      })
    }
  }

  getRowClass() {
    return 'background:#f0f3fb;color:#4c5360;font-size:9px;font-weight:500;height: 30px;'
  }

  submit() {
    let that = this
    if (this.store.choosedIds.length) {
      CACHE.localStorage.put('monitor_quota_key', this.store.choosedIds)
    } else {
      this.$message({
        message: '请至少选择一项监控指标',
        type: 'warning'
      })
      return false
    }
    (that as any).$parent.getMonitorMetrics()
  }

  async getProjectDetail() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/projects/${that.dataSource.id}`
      })
      that.projectForm.name = json.name
      that.projectForm.description = json.description
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

}

export default MonitoringQuotaComponent
</script>

<style lang="scss">
  .monitoring-quota {
    .monitoring-quota-table {
      .el-table__row {
        height: 40px;
      }
      .cell {
        font-size: 12px;
      }
    }
    .item-drop {
      // width: 24%;
      margin: 15px 1.3% 0 0;
      border: 1px dashed #fff;
    }
    .hover-shadow{
      .shadow-show{
        display: none;
      }
      &:hover{
        -webkit-transition: background-color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
        transition: background-color 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
        -webkit-box-shadow: 0 2px 0 rgba(0, 0, 0, 0.015);
        box-shadow: 0 2px 0 rgba(0, 0, 0, 0.015);
        .shadow-show{
          display: inline-block;
        }
        .shadow-hide{
          display: none;
        }
      }
    }
    .text-gray {
      color: #999;
      float: right;
    }
    .target-item {
      padding: 2px 5px 3px 10px;
      margin: 3px 1.3% 0 0;
      border: 1px solid #ccc;
      background: #e9edef;
      font-size: 12px;
      display: inline-block;
      .target-label {
        float: left;
        overflow: hidden;
        width: 100px;
        line-height: 20px;
        vertical-align: middle;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }
    .drag-style {
      position: relative;
      display: inline-block;
      cursor: move;
    }
    .del-icon {
      float: right;
      font-style: normal;
      font-size: 15px;
      font-weight: 700;
      padding-top: 3px;
      font-variant: normal;
      text-transform: none;
    }
    .el-alert--info {
      background: #f2f5fc;
      border: 1px solid #4e72d7;
      border-radius: 5px;
      // .el-icon-info {
      //   background: #5e7ce0;
      //   color: #fff;
      // }
      .el-alert__content {
        color: #252b3a;
      }
    }
  }
</style>

