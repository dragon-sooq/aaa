/**
 * monitor Component
 * @author nn
 * @description
*/


import ILineChartData from './detail/card/index.vue'
class Store {
  private vmm: any;
  private params: any;
  public chooseLimit: String = '近1小时'; // 快捷选择时间
  public currentUUID: String = ''; // 当前所选UUID
  public clusterUUID: String = ''; // 当前所选集群UUID
  public currentRole: String = ''; // 当前所选角色类型
  public customizeTime: Array<String> = []; // 自定义时间范围
  public choosedIds: Array<number> = []; // 记录选中指标个数
  public choosedList: Array<Object> = []; // 记录选中指标
  public targetList: Array<Object> = []; // 监控指标list
  public lineChartData: { [type: string]: ILineChartData } = {}; // 所有监控历史数据
  public show: Boolean = false; // 是否展开日期选择控件

  constructor(vmm: any) {
    this.vmm = vmm // 设置DOM绑定事件的this指向性
    console.log(this)
  }

  /**
   * 输出框变化时触发
   */
  changeKeyWord(keyWord: string) {
    this.vmm.dataSource.keyWord = keyWord
  }

  /**
   * @description 选择日期回调
   */
  public chooseDate() {
    console.log(this)
    if (this.customizeTime.length) {
      this.chooseLimit = ''
    }
  }

  /**
   * @description 快捷选择日期回调 近1小时 3小时...
   */
  public changeLimit() {
    console.log(this)
    this.show = false
    this.customizeTime = []
  }

  

  /**
   * @description 表格选择回调
   * @param val 所选行
   */
  public handleSelectionChange(val: Array<Object>) {
    this.choosedIds = []
    this.choosedList = val
    console.log(val)
    val.forEach((value: any) => {
      this.choosedIds.push(value.alias_name)
    })
  }

  /**
   * Radio变化时触发
   */
  changeShowType(showType: number) {
    this.vmm.dataSource.keyWord = ''
    this.vmm.dataSource.showType = showType
  }
}

export default Store
