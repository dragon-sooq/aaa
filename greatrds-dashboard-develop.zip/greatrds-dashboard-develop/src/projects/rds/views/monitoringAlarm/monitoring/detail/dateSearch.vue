<template>
  <div
    id="header-search"
    :class="{'show': store.show}"
    class="header-search"
  >
    <button
      @click.stop="click"
      type="button mb-10"
      class="btn"
      style="margin-bottom: 8px;
            margin-left: 5px;
            "
    >
      <i
        class="el-icon-date search-icon"
        name="search"
      />
    </button>

    <el-date-picker
      v-model="store.customizeTime"
      ref="headerSearchTime"
      type="datetimerange"
      class="header-search-select"
      style="margin-bottom: 8px;"
      :picker-options="$root.DICT.TIME_OPTIONS"
      @change="chooseDate"
      range-separator="至"
      start-placeholder="开始日期"
      end-placeholder="结束日期"
      align="right"
    />
  </div>
</template>

<script lang="ts">
import path from 'path'
import { Component, Vue, Watch, Prop } from 'vue-property-decorator'
import { RouteConfig } from 'vue-router'
import i18n from '@/lang' // Internationalization

@Component
export default class extends Vue {
  @Prop({ required: true }) store: any;
  private search = ''
  private options: RouteConfig[] = []
  private searchPool: RouteConfig[] = []


  mounted() {
    this.store.chooseDate()
  }

  private click() {
    this.store.show = !this.store.show
    if (this.store.show) {
      this.$refs.headerSearchTime && (this.$refs.headerSearchTime as HTMLElement).focus()
    }
  }

  private close() {
    this.$refs.headerSearchTime && (this.$refs.headerSearchTime as HTMLElement).blur()
    this.options = []
    this.store.show = false
    console.log(this.store.show)
  }

  private chooseDate() {
    this.store.chooseDate()
  }

  private change(route: RouteConfig) {
    this.$router.push(route.path)
    this.search = ''
    this.options = []
    this.$nextTick(() => {
      this.store.show = false
    })
  }
}
</script>

<style lang="scss">
.header-search {
  font-size: 0 !important;
  display: inline;

  .search-icon {
    cursor: pointer;
    font-size: 18px;
    vertical-align: middle;
  }

  .btn {
    margin-bottom: 0;
    font-weight: 400;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    background-image: none;
    padding: 4px 12px;
    font-size: 14px;
    line-height: 1.42857143;
    border-radius: 4px;
  }
  button:hover {
    color: #333854;
    background: #fff;
    border-color: #333854 !important;
  }

  .header-search-select {
    font-size: 18px;
    transition: width 0.2s;
    width: 0;
    visibility: hidden;
    overflow: hidden;
    background: transparent;
    border-radius: 0;
    padding: 0 !important;
    display: inline-block;
    vertical-align: middle;
    .el-range-separator {
      padding: 0 !important;
    }
    .el-input__inner {
      border-radius: 0;
      border: 0;
      padding-left: 0;
      padding-right: 0;
      box-shadow: none !important;
      border-bottom: 1px solid #d9d9d9;
      vertical-align: middle;
    }
  }

  &.show {
    .header-search-select {
      width: 370px;
      visibility: visible;
      margin-left: 10px;
    }
  }
}
</style>
