/* eslint-disable */
<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="chartData.name"
    :use-footer="false"
    :width="'1100px'"
  >
    <div
      class="monitor-plus-card"
      style="min-height: 440px; width: 100%;"
    >
      <div class="monitor-plus-card-header">
        <el-radio-group
          @change="changeLimit"
          v-model="chooseLimit"
          size="mini"
        >
          <el-radio-button label="近1小时" />
          <el-radio-button label="近3小时" />
          <el-radio-button label="近12小时" />
          <el-radio-button label="24小时" />
          <el-radio-button label="近7天" />
        </el-radio-group>
        <div
          class="pull-right"
        >
          <el-date-picker
            v-model="customizeTime"
            ref="headerSearchTime"
            type="datetimerange"
            class="header-search-select"
            style="margin-bottom: 8px;"
            :picker-options="$root.DICT.TIME_OPTIONS"
            @change="chooseDate"
            format="yyyy-MM-dd HH:mm"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            align="right"
          />
        </div>
      </div>

      <div
        class="monitor-plus-card-body"
      >
        <div class="unit">
          <span style="color: #999">
            {{ unit }}
          </span>
        </div>
      </div>
      <div
        :class="className"
        :id="echartId"
        ref="chart"
        :style="{height: height, width: width}"
      />
    </div>
  </DialogLayer>
</template>

<script lang="ts">
import echarts, { EChartOption } from 'echarts'
import { Component, Prop, Watch } from 'vue-property-decorator'
import { mixins } from 'vue-class-component'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
import ResizeMixin from '@/compkg/components/Charts/mixins/resize'
import moment from 'moment'

export interface ILineChartData {
  xData: number[]
  yData: number[]
}

@Component({
  name: 'LineChart',
  components: {
    DialogLayer
  }
})
export default class extends mixins(ResizeMixin) {
  @Prop({required: true}) dataSource: any;
  @Prop({ required: true }) private chartData!: ILineChartData
  @Prop({ default: 'chart' }) private className!: string
  @Prop({ default: '100%' }) private width!: string
  @Prop({ default: '380px' }) private height!: string
  @Prop({ required: true }) store: any;
  @Watch('chartData', { deep: true })
  private chartName: String = ''; // 监控项名称
  private customizeTime: Array<string> = [];
  public chooseLimit: String = '近1小时'; // 快捷选择时间
  private start: String = moment().subtract(1, 'hours').format('YYYY-MM-DD HH:mm')
  private end: String = moment().format('YYYY-MM-DD HH:mm')
  private unit: String = ''; // 单位
  private onChartDataChange(value: ILineChartData) {
    this.setOptions(value)
  }

  mounted() {
    this.$nextTick(() => {
      this.chartName = this.chartData['name']
      this.unit = this.chartData['unit']
      this.getChartData() // 获取当前图表数据
    })
  }

  get echartId() {
    return 'echarts' + Math.random() * 100000
  }

  async getChartData() {
    let that = this
    let data = {
      member_uuid: that.store.currentUUID,
      start: that.start,
      end: that.end
    }
    that.chartData.xData = []
    that.chartData.yData = []
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/rds/cluster/monitor_member/metric/${that.store.clusterUUID}/${that.store.currentRole}/${this.chartData['metricName']}/history`,
        params: data
      })
      if (json.length) {
        json[0].values.forEach((item: any) => {
          if (that.chooseLimit !== '近7天') {
            item[0] = moment(item[0] * 1000).format('HH:mm')
          } else {
            item[0] = moment(item[0] * 1000).format('YYYY/MM/DD HH:mm')
          }
          that.chartData.xData.push(item[0])
          that.chartData.yData.push(item[1])
        })
        that.initChart()
      }
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 自定义选择时间回调
   */
  chooseDate() {
    if (this.customizeTime.length) {
      this.chooseLimit = ''
      this.start = moment(this.customizeTime[0]).format('YYYY-MM-DD HH:mm')
      this.end = moment(this.customizeTime[1]).format('YYYY-MM-DD HH:mm')
      this.getChartData()
    }
  }

  /**
   * @description 快捷切换日期范围
   */
  changeLimit(val: any) {
    this.end = moment().format('YYYY-MM-DD HH:mm')
    if (val === '近1小时') {
      this.start = moment().subtract(1, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近3小时') {
      this.start = moment().subtract(3, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近12小时') {
      this.start = moment().subtract(12, 'hours').format('YYYY-MM-DD HH:mm')
    } else if (val === '近24小时') {
      this.start = moment().subtract(1, 'days').format('YYYY-MM-DD HH:mm')
    } else {
      this.start = moment().subtract(7, 'days').format('YYYY-MM-DD HH:mm')
    }
    this.getChartData()
  }

  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  }

  private initChart() {
    // this.chart = echarts.init(this.$el as HTMLDivElement, 'macarons')
    this.chart = echarts.init(this.$refs.chart as HTMLCanvasElement)
    this.setOptions(this.chartData)
  }

  private setOptions(chartData: ILineChartData) {
    if (this.chart) {
      this.chart.setOption({
        xAxis: {
          data: chartData.xData,
          boundaryGap: false,
          axisLine: { // x轴线
            show: false
          },
          axisTick: {
            show: false
          },
          axisLabel: { // 坐标轴刻度标签的相关设置。
            // 'interval': 44
            formatter: (params) => {
              if (this.chooseLimit !== '近7天') {
                return params
              }
              let newParamsName = ''// 最终拼接成的字符串
              let paramsNameNumber = params.length// 实际标签的个数
              let provideNumber = 11// 每行能显示的字的个数
              let rowNumber = Math.ceil(paramsNameNumber / provideNumber)// 换行的话，需要显示几行，向上取整
              if (paramsNameNumber > provideNumber) {
                /** 循环每一行,p表示行 */
                for (let row = 0; row < rowNumber; row++) {
                  let tempStr = ''// 表示每一次截取的字符串
                  let start = row * provideNumber// 开始截取的位置
                  let end = start + provideNumber// 结束截取的位置
                  // 此处特殊处理最后一行的索引值
                  if (row === rowNumber - 1) {
                    // 最后一次不换行
                    tempStr = params.substring(start, paramsNameNumber)
                  } else {
                    // 每一次拼接字符串并换行
                    tempStr = params.substring(start, end) + '\n'
                  }
                  newParamsName += tempStr// 最终拼成的字符串
                }

              } else {
                // 将旧标签的值赋给新标签
                newParamsName = params
              }
              // 将最终的字符串返回
              return newParamsName
            }
          }
        },
        grid: {
          left: 20,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: 8
        },
        yAxis: {
          splitLine: { // 网格线
            lineStyle: {
              type: 'dashed' // 设置网格线类型 dotted：虚线   solid:实线
            }
          },
          axisLine: { // y轴线
            show: false
          },
          show: true, // 隐藏或显示
          axisTick: {
            show: false
          }
        },
        // legend: {
        //   data: ['expected', 'actual']
        // },
        series: [{
          name: this.chartData['name'],
          // itemStyle: {
          //   color: '#FF005A',
          //   lineStyle: {
          //     color: '#FF005A',
          //     width: 2
          //   }
          // },
          // smooth: true,
          type: 'line',
          data: chartData.yData,
          showSymbol: false,
          hoverAnimation: true,
          animationDuration: 2800,
          animationEasing: 'cubicInOut',
          itemStyle: {
            normal: {
              color: '#547df0', // 改变折线点的颜色
              lineStyle: {
                color: '#547df0' // 改变折线颜色
              }
            }
          },
          markPoint: {
            symbol: 'triangle',
            symbolSize: 20,
            data: [
              {
                name: '最大值',
                type: 'max'
              },
              {
                name: '最小值',
                type: 'min',
                value: 0
              }
            ]
          }
        }]
      } as EChartOption<EChartOption.SeriesLine>)
      this.showTip()
    }
  }

  showTip() {
    /* eslint-disable */
    let that = this as any
    (this.chart as any).on('mouseover', function(target: HTMLElement) {
      // series name 为 'uuu' 的系列中的图形元素被 'mouseover' 时，此方法被回调。
      console.log(123)
      that.chart.dispatchAction({ 
        type: 'showTip',
        // eslint-disable-next-line id-length
        x: 100,
        // eslint-disable-next-line id-length
        y: 100
      })
    })
  }

  // showEvery() {
    
  // }
}
</script>

<style lang="scss">
  .monitor-plus-card {
    // border: 1px solid #adb0b8;
    .card-header-max-width {
      display: none;
    }
    .monitor-plus-card-header {
      position: relative;
      height: 41px;
      padding: 9px 10px 0 20px;
      background-color: #fff;
      .header-search-select {
        font-size: 18px;
        .el-range-separator {
          line-height: 1.8;
          padding: 0 !important;
        }
        .el-range__icon {
          line-height: 1.8;
        }
        .el-input__inner {
          border-radius: 0;
          border: 0;
          padding-left: 0;
          padding-right: 0;
          box-shadow: none !important;
          border-bottom: 1px solid #d9d9d9;
          vertical-align: middle;
        }
      }
    }
    .monitor-plus-card-header > span {
      font-size: 14px;
      color: #252b3a;
    }
    .monitor-plus-card-body {
      height: 100%;
      width: 100%;
      .unit {
        z-index: 1;
        padding-left: 20px;
      }
    }
  }
</style>
