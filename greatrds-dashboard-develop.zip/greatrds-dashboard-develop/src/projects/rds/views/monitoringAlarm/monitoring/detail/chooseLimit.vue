
<template>
  <div class="monitoring-choose-limit-containers">
    {{ chooseLimit }}
    
    <div
      v-if="chooseLimit === '快速选择'"
      class="mt-20"
    >
      <div>
        <span class="mr-10">时间范围</span>
        <el-select
          v-model="timeLimit"
          placeholder="请选择"
        >
          <el-option
            v-for="item in timeLimitList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>

      <div class="mt-15">
        <span class="mr-10">刷新间隔</span>
        <el-select
          v-model="refreshInterval"
          placeholder="请选择"
        >
          <el-option
            v-for="item in refreshIntervalList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
    </div>

    <div
      v-else
      class="mt-20"
    >
      <el-date-picker
        v-model="customizeTime"
        type="datetimerange"
        :picker-options="$root.DICT.TIME_OPTIONS"
        range-separator="至"
        start-placeholder="开始日期"
        end-placeholder="结束日期"
        align="right"
      />
    </div>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Getter, namespace } from 'vuex-class'
import Utils from '@/utils'
import echarts from 'echarts'

@Component
class ChooseLimitComponent extends Vue {
  @Prop({required: true}) store: any;
  private customizeTime: any = '';
  private chooseLimit: String = '快速选择'; // 筛选范围 默认快速选择
  private refreshInterval: number = 3; // 刷新间隔默认5分钟
  private refreshIntervalList: Array<Object> = [
    {
      label: '关闭',
      value: 1
    },
    {
      label: '1分钟',
      value: 2
    },
    {
      label: '5分钟',
      value: 3
    },
    {
      label: '15分钟',
      value: 4
    },
    {
      label: '30分钟',
      value: 5
    }
  ];
  private timeLimit: number = 1; // 时间范围默认近5分钟
  private timeLimitList: Array<Object> = [ // 时间范围list
    {
      label: '近5分钟',
      value: 1
    },
    {
      label: '近15分钟',
      value: 2
    },
    {
      label: '近1小时',
      value: 3
    },
    {
      label: '近12小时',
      value: 4
    },
    {
      label: '近1天',
      value: 5
    },
    {
      label: '近2天',
      value: 6
    }
  ];

  created() {
    console.log(this.store)
  }
}
export default ChooseLimitComponent
</script>
<style lang="scss">
.monitoring-choose-limit-containers{
  margin: 10px;
  .el-input__icon {
    line-height: 0px;
  }
  .el-range-separator {
    line-height: 1.9px;
  }
}
</style>
