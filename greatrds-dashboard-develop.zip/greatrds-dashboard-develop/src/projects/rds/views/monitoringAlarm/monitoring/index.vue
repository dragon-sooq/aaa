
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <MonitorTable />
  </div>
</template>
<script lang='ts'>

import { Vue, Component, Prop } from 'vue-property-decorator'
import { Drawer, DelayedSearch, Table } from '@/compkg/components/index'
import Utils from '@/utils'
import MonitorTable from './table.vue'

interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Table,
    MonitorTable
  }
})
class MonitoringComponent extends Vue {
  public tableDataSource: Object = {
    onlyHeader: true,
    // tabsConfig: {
    //   activeName: '项目成员',
    //   list: [{
    //     id: 1,
    //     label: '项目成员',
    //     name: '项目成员'
    //   }]
    // },
    tableConfig: {
      columns: [
      ]
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true
    }
  }
  created() {
  }
}
export default MonitoringComponent
</script>

