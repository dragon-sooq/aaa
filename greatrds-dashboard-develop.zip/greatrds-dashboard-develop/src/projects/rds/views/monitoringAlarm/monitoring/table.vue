
<template>
  <div
    class="table-containers"
    style="padding: 0 15px 15px 15px;"
  >
    <el-table
      :data="tableData"
      :header-cell-style="getRowClass"
      style="overflow: auto;"
      height="calc(100vh - 280px)"
      stripe
    >
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-table
            :data="props.row.compute_nodes.hosts"
            :header-cell-style="getRowClass"
            height="calc(100vh - 320px)"
            stripe
          >
            <el-table-column type="expand">
              <template slot-scope="childProps">
                <el-table
                  :data="childProps.row.members.cluster_members"
                  :header-cell-style="getRowClass"
                  height="100%"
                  stripe
                >
                  <el-table-column
                    prop="name"
                    label="实例名称"
                  />
                  <el-table-column
                    prop="address"
                    label="地址"
                  />
                  <el-table-column
                    prop="nodegroup_id"
                    label="节点组ID"
                  />
                </el-table>
              </template>
            </el-table-column>
            <el-table-column
              prop="os_type"
              label="节点名称"
            />
            <el-table-column
              prop="uuid"
              label="UUID"
            />
            <el-table-column
              prop="os_type"
              label="节点类型"
            />
            <el-table-column
              fixed="right"
              label="操作"
              width="160"
            >
              <template slot-scope="scope">
                <span 
                  @click="jumpDetail(scope.row)"
                  class="cursor-p"
                  style="color: #526ECC"
                >
                  查看监控指标
                </span>
              </template>
            </el-table-column>
          </el-table>
          <!-- {{ props }} -->
        </template>
      </el-table-column>

      <el-table-column
        prop="name"
        label="集群名称"
      />

      <el-table-column
        prop="uuid"
        label="UUID"
      />

      <el-table-column
        prop="address"
        label="地址"
      />

      <el-table-column
        fixed="right"
        label="操作"
        width="160"
      >
        <template slot-scope="scope">
          <span
            @click="jumpDetail(scope.row)"
            class="cursor-p"
            style="color: #526ECC"
          >
            查看监控指标
          </span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>
<script lang='ts'>

import { Vue, Component, Prop } from 'vue-property-decorator'
import { Drawer, Table } from '@/compkg/components/index'
import Utils from '@/utils'

interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Table
  }
})
class MonitoringTableComponent extends Vue {
  private isViewShow: Boolean = false;
  private loading: Boolean = false;
  private tableData: Array<Object> = [];
  private currentProject: Object = {}
  private manageMemberData: Object = {
    isShow: false
  };
  private projectData: any = {
    isShow: false,
    isEdit: false
  };

  private page: Object = {
    currentPage: 1,
    pageSize: 20
  }

  private like: string = '' // 搜索字段
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = [];

  created() {
    this.getList()
  }

  /**
   * @description 展示详情
   */
  jumpDetail(item: object) {
    console.log(item)
    let clusterUUid: any = ''
    if (item['cluster_uuid']) {
      clusterUUid = item['cluster_uuid']
    }
    this.$router.push({ path: `/monitoringAlarm/detail/${item['uuid']}/${clusterUUid}/${item['role']}` })
  }

  /**
   * 表格的排序条件发生变化时触发
   * @param item - 当前表格对象项及order
   */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  showDetail(item: Object) {
    this.isViewShow = true
    this.currentProject = item
  }

  getRowClass() {
    return 'background:#f0f3fb;color:#4c5360;font-size:9px;font-weight:500;height: 30px;'
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.loading = true
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/cluster',
        params: {
          limit: this.page['pageSize'],
          offset: this.page['currentPage'],
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      console.log(json)
      this.tableData = json.clusters || []
    } catch (error) {
      this.loading = false
      this.$handleError(error)
    }
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

  editTemplate(item: object) {
    console.log(item)
    const that: any = this
    that.$router.push({
      name: 'AlarmEdit',
      query: {
        id: item['id']
      }
    })
  }
}
export default MonitoringTableComponent
</script>

