<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="'创建参数模板'"
    :width="'720px'"
  >
    <el-form
      ref="templateForm"
      label-align="right"
      layout="horizontal"
      style="padding: 35px;"
      label-width="140px"
      v-bind="formItemLayout"
      :model="templateForm"
      :rules="templateRules"
    >
      <el-form-item
        has-feedback
        label="数据库引擎版本"
        prop="version"
      >
        <el-select
          v-model="value"
          filterable
          style="width: 80%;"
          placeholder="请选择"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        has-feedback
        label="参数模板名"
        prop="name"
      >
        <el-input
          v-model="templateForm.name"
          style="width: 80%;"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="描述"
      >
        <el-input
          v-model="templateForm.description"
          :rows="4"
          style="width: 80%;"
          type="textarea"
          autocomplete="off"
        />
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm('templateForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
import { handleTreeV2 } from '@/utils/tree'
const worktableModule = namespace('worktable')

@Component({
  components: {
    DialogLayer
  }
})
class UserOperationComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  private treeData: Array<Object> = []
  private loading: Boolean = false;
  private chooseIds: Array<String> = [];
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private templateForm: any = {
    name: '',
    description: '',
    version: []
  }
  private templateRules: Object = {
    name: [{ required: true, message: '请输入参数模板名', trigger: 'change' }],
    version: [{ required: true, message: '请选择数据库引擎版本', trigger: 'change' }]
  }
  created() {
    if (this.dataSource.isEdit) {
      this.templateForm = this.dataSource.role
    }
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: Boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PATCH' : 'POST',
        url: that.dataSource.isEdit ? `/auth/roles/${that.dataSource.id}` : '/auth/roles',
        data: that.templateForm
      })
      that.loading = false
      that.$message({
        message: '操作成功',
        type: 'success'
      })
      that.dataSource.isShow = false;
      (that as any).$parent.getList()
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default UserOperationComponent
</script>

