
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <Operation
      :data-source="userData"
      v-if="userData.isShow"
    />
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import {Drawer} from '@/compkg/components'

interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Table
  }
})
class OpsDetailComponent extends Vue {

  private userData: any = {
    isShow: false,
    isEdit: false,
    type: 'admin'
  };

  private like: string = '' // 搜索字段
  private templateId: string = '';
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  public tableDataSource: object = {
    btnConfig: {
      list: [
        {
          icon: 'el-icon-arrow-left',
          name: '返回'
        }
      ],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '参数名称',
          prop: 'name',
          sortable: 'custom',
          click: (row) => {
            this.editRole(row)
          }
        },
        {
          label: '是否需要重启',
          prop: 'restart',
          filter: 'dbTFFilter'
        },
        {
          label: '值',
          prop: 'value',
          filter: 'dbNullFilter'
        },
        {
          label: '允许值',
          prop: 'validation',
          filter: 'dbNullFilter'
        },
        {
          label: '描述',
          prop: 'description',
          filter: 'dbNullFilter'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.templateId = this.$route.params.templateId
    console.log(this.$route.params)
    this.getList()
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.tableDataSource['btnConfig'].list[0].disabled = !(list && list.length)
    this.choosedIds = list.map((chooseItem: any) => chooseItem.id)
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    console.log(name)
    this.$router.push({ path: '/ops/template' })
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      let json = await this.$axios({
        method: 'GET',
        url: `/rds/configurations/${this.templateId}`
      })
      this.tableDataSource['tableConfig'].data = json.items || []
      this.tableDataSource['pageConfig'].totalCount = json.items.length || 0
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 删除角色
  * @param items 选中行
  */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteRole(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
   * @param id 要删除的id
   * @description 删除角色
   */
  async deleteRole(id: String) {
    try {
      let json = await this.$axios({
        method: 'DELETE',
        url: `/auth/roles/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * 编辑角色
   * @param item 当前行
   */
  editRole(item: Object) {
    this.userData.isShow = true
    this.userData.isEdit = true
    this.userData.role = {
      name: item['name'],
      type: item['type'],
      description: item['description'],
      functions_ids: item['functions_ids']
    }
    this.userData.id = item['id']
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default OpsDetailComponent
</script>

