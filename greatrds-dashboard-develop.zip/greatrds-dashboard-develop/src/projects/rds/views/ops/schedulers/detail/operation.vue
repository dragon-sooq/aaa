<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.isEdit ? '修改定时器任务' : '创建定时器任务'"
    :width="'620px'"
    class="schedulersTask-create-modal"
  >
    <el-form
      ref="schedulersTask"
      label-align="right"
      layout="horizontal"
      style="padding: 35px;"
      label-width="140px"
      v-bind="formItemLayout"
      :model="schedulersTask"
      :rules="templateRules"
    >
      <el-form-item
        has-feedback
        label="名称"
        prop="task_name"
      >
        <el-input
          v-model="schedulersTask.task_name"
          style="width: 70%;"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="类型"
      >
        <el-select
          v-model="schedulersTask.type"
          placeholder="请选择"
          style="width: 70%;"
        >
          <el-option
            v-for="item in typeList"
            :key="item.id"
            :label="item.label"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm('schedulersTask')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import moment from 'moment'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
@Component({
  components: {
    DialogLayer
  }
})
class SchedulersTaskOperationComponent extends Vue {
  @Prop() dataSource: any;
  private loading: Boolean = false;
  private typeList: Array<Object> = [ // 任务类型数组
    {
      label: '测试任务1',
      id: '1'
    },
    {
      label: '测试任务2',
      id: '2'
    }
  ];
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private schedulersTask: any = {
    task_name: '',
    scheduler_uuid: '',
    type: '1',
    resource: 'test'
  }
  private templateRules: Object = {
    task_name: [{ required: true, message: '请输入定时器任务名称', trigger: 'change' }]
  }
  created() {
    this.initModel()
  }

  /**
   * @description 初始化表单内容
   */
  initModel() {
    this.schedulersTask.scheduler_uuid = this.$route.params.uuid
    if (this.dataSource.isEdit) {
      this.schedulersTask.resource = this.dataSource.resource
      this.schedulersTask.type = this.dataSource.type
      this.schedulersTask.task_name = this.dataSource.task_name
    }
    console.log(this.dataSource)
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: Boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let period = `$${that.schedulersTask.period}-`
      let flag = false
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PUT' : 'POST',
        url: that.dataSource.isEdit ? `/rds/scheduler/task/${that.dataSource.uuid}` : '/rds/scheduler/task',
        data: that.schedulersTask
      })
      that.loading = false
      that.$message({
        message: '操作成功',
        type: 'success'
      })
      that.dataSource.isShow = false;
      (that as any).$parent.getList()
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default SchedulersTaskOperationComponent
</script>

<style lang="scss">
  .schedulersTask-create-modal {
    .tip {
      padding: 0 !important;
      display: block;
      color: #939ea9;
      padding: 9px 0;
      font-size: 12px;
    }
  }
</style>

