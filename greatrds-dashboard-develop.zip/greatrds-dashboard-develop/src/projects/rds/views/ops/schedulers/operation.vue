<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.isEdit ? '修改定时器' : '创建定时器'"
    :width="'620px'"
    class="schedulers-create-modal"
  >
    <el-form
      ref="schedulers"
      label-align="right"
      layout="horizontal"
      style="padding: 35px;"
      label-width="140px"
      v-bind="formItemLayout"
      :model="schedulers"
      :rules="templateRules"
    >
      <el-form-item
        has-feedback
        label="名称"
        prop="scheduler_name"
      >
        <el-input
          v-model="schedulers.scheduler_name"
          style="width: 70%;"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="类型"
      >
        <el-radio
          v-model="schedulers.repeat"
          :label="1"
        >
          重复执行
        </el-radio>
        <el-radio
          v-model="schedulers.repeat"
          :label="0"
        >
          仅执行一次
        </el-radio>
      </el-form-item>

      <el-form-item
        v-if="schedulers.repeat === 1"
        label="周期"
      >
        <el-select
          v-model="schedulers.period"
          placeholder="请选择"
          style="width: 70%;"
        >
          <el-option
            v-for="item in cycle"
            :key="item.id"
            :label="item.label"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        v-else
        label="时间"
      >
        <el-date-picker
          v-model="schedulers.scheduler_time"
          type="datetime"
          style="width: 70%;"
          placeholder="选择日期时间"
        />
      </el-form-item>

      <!-- 周期选择每n天 / 每n小时展示的内容 -->
      <el-form-item
        v-if="schedulers.repeat === 1 && (schedulers.period === '2' || schedulers.period === '0')"
        :label="schedulers.period === '2' ? '天数' : '小时数'"
      >
        <el-input-number
          v-model="count"
          :min="1"
          :max="schedulers.period === '2' ? 99 : 23"
          :controls="false"
          controls-position="right"
          style="width: 70%;"
        />
        <div class="tip">{{ schedulers.period === '2' ? '每 n 天执行一次，其中 n 取值范围[1~99]。' : '每 n 小时执行一次，其中 n 取值范围[1~23]。' }}</div>
      </el-form-item>

      <!-- 周期选择每月展示的内容 -->
      <el-form-item
        v-if="schedulers.repeat === 1 && schedulers.period === '4'"
        label="日期"
      >
        <el-select
          v-model="countList"
          multiple
          style="width: 70%;"
          size="small"
          placeholder="请选择"
        >
          <el-option
            v-for="item in monthList"
            :key="item"
            :label="item === 31 ? '月末' : (item + 1) + '号'"
            :value="item"
          />
        </el-select>
      </el-form-item>

      <!-- 周期选择每周展示的内容 -->
      <el-form-item
        v-if="schedulers.repeat === 1 && schedulers.period === '3'"
        label="日期"
      >
        <el-select
          v-model="countList"
          multiple
          style="width: 70%;"
          size="small"
          placeholder="请选择"
        >
          <el-option
            v-for="item in weekList"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        v-if="schedulers.repeat === 1"
        label="时间"
      >
        <el-input-number
          v-model="currentHour"
          :disabled="schedulers.period === '0'"
          :min="1"
          :max="24"
          :controls="false"
          controls-position="right"
          style="width: 15%;"
        />
        :
        <el-input-number
          v-model="currentMinute"
          :min="1"
          :max="60"
          :controls="false"
          controls-position="right"
          style="width: 15%;"
        />
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm('schedulers')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import moment from 'moment'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
import { handleTreeV2 } from '@/utils/tree'
@Component({
  components: {
    DialogLayer
  }
})
class UserOperationComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  private loading: Boolean = false;
  private currentHour: number = moment().hour(); // 当前小时
  private currentMinute: number = moment().minute(); // 当前分钟
  private count: number = 1; // 选择的日期 用于和周期拼接
  private countList: Array<number> = []; // 每周和每月绑定的值 用于和周期拼接
  private monthList: Array<any> = [ // 周期选择每月 展示选择一月中的某一天
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31
  ];
  private weekList: Array<Object> = [ // 周期选择每周 展示选择一周中的某一天
    {
      label: '周一',
      value: 0
    },
    {
      label: '周二',
      value: 1
    },
    {
      label: '周三',
      value: 2
    },
    {
      label: '周四',
      value: 3
    },
    {
      label: '周五',
      value: 4
    },
    {
      label: '周六',
      value: 5
    },
    {
      label: '周日',
      value: 6
    }
  ];
  private cycle: Array<Object> = [ // 周期数组
    {
      label: '每天',
      id: '1'
    },
    {
      label: '每n天',
      id: '2'
    },
    {
      label: '每n小时',
      id: '0'
    },
    {
      label: '每周',
      id: '3'
    },
    {
      label: '每月',
      id: '4'
    }
  ];
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private schedulers: any = {
    scheduler_name: '',
    period: '0',
    scheduler_time: '',
    repeat: 1
  }
  private templateRules: Object = {
    scheduler_name: [{ required: true, message: '请输入定时器名称', trigger: 'change' }]
  }
  created() {
    this.initModel()
  }

  /**
   * @description 初始化表单
   */
  initModel() {
    if (this.dataSource.isEdit) {
      console.log(this.dataSource)
      let form = this.dataSource.currentForm
      this.schedulers.scheduler_name = form.scheduler_name
      this.schedulers.repeat = form.repeat
      this.currentHour = form.scheduler_time.split(':')[0]
      this.currentMinute = form.scheduler_time.split(':')[1]
      if (form.repeat && form.period.split('$').length >= 2) {
        let period = form.period.split('$')[1].split('-')[0] // 把周期按照$符分割, 得到的是[‘’, ‘2-1’] 取[1]再按照 - 分割 再取 [0] 得到当前周期type
        let currentDate = form.period.split('$')[1].split('-').slice(1, form.period.split('$')[1].split('-').length)
        if (period === '0' || period === '2') {
          // 每n小时 / 每n天
          this.count = currentDate
        } else if (period === '3' || period === '4') {
          currentDate.forEach((date: any) => {
            this.countList.push(Number(date))
          })
        }
        this.schedulers.period = period
        console.log(currentDate)
      }
    }
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: Boolean) => {
      if (valid && this.validateMonthOrDay()) {
        that.saveData()
      }
    })
  }

  validateMonthOrDay() {
    let that = this
    if (that.schedulers.period !== '1' && that.schedulers.repeat === 1) {
      if ((that.schedulers.period === '2' || that.schedulers.period === '0') && !that.count) {
        that.$message({
          message: '请填写天数/小时数',
          type: 'error'
        })
        return false
      } else if ((that.schedulers.period === '3' || that.schedulers.period === '4') && !that.countList.length) {
        that.$message({
          message: '请选择日期',
          type: 'error'
        })
        return false
      }
    } else {
      console.log(moment(that.schedulers.scheduler_time).format('YYYY-MM-DD HH:mm:ss'))
    }
    return true
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let period = `$${that.schedulers.period}-`
      let flag = false
      if (that.schedulers.period !== '1') {
        if (that.schedulers.period === '2' || that.schedulers.period === '0') {
          period += that.count
        } else {
          // 日期排序
          that.countList.sort((first: any, second: any) => {
            return first - second
          })
          that.countList.map((item: any) => {
            period += item + '-'
          })
        }
      }
      that.schedulers.scheduler_time = that.currentHour + ':' + that.currentMinute
      if (that.schedulers.period !== '2' && that.schedulers.period !== '0') {
        // 每n天和每n小时不需要分割
        period = period.slice(0, period.length - 1)
      }
      that.schedulers.period = period
      let url = that.dataSource.isEdit ? `/rds/scheduler/${that.$route.params.uuid}` : '/rds/scheduler'
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PUT' : 'POST',
        url: url,
        data: that.schedulers
      })
      that.loading = false
      that.$message({
        message: '操作成功',
        type: 'success'
      })
      that.dataSource.isShow = false
      if (that.dataSource.isEdit) {
        that.$router.push({ path: '/ops/schedulers' })
      } else {
        (that as any).$parent.getList()
      }
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default UserOperationComponent
</script>

<style lang="scss">
  .schedulers-create-modal {
    .tip {
      padding: 0 !important;
      display: block;
      color: #939ea9;
      padding: 9px 0;
      font-size: 12px;
    }
  }
</style>

