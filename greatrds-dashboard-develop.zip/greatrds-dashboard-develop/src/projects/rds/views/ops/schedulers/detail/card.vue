
<template>
  <div class="schedulers-detail-card">
    <el-card
      class="box-card"
    >
      <div
        slot="header"
        class="clearfix"
      >
        <span>基本属性</span>
        <el-dropdown
          @command="handleCommand"
          class="ml"
          size="small"
          style="float: right; padding: 3px 0"
        >
          <i
            class="el-icon-s-operation cursor"
          />
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="edit">
              <i class="el-icon-edit-outline" />修改
            </el-dropdown-item>
            <el-dropdown-item command="delete">
              <i class="el-icon-delete" />删除
            </el-dropdown-item>
            <el-dropdown-item command="add">
              <i class="el-icon-folder-add" />添加到项目
            </el-dropdown-item>
            <el-dropdown-item command="remove">
              <i class="el-icon-folder-remove" />从项目中移除
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
      <dl class="card-horizontal">
        <dt class="card-dt">ID</dt>
        <dd class="card-dd">{{ UUID }}</dd>
        <dt class="card-dt">名称</dt>
        <dd class="card-dd">{{ schedulerName }}</dd>
        <dt class="card-dt">类型</dt>
        <dd class="card-dd">{{ repeat }}</dd>
        <dt class="card-dt">周期</dt>
        <dd class="card-dd">{{ period }}</dd>
        <dt class="card-dt">时间</dt>
        <dd class="card-dd">{{ schedulerTime }}</dd>
        <dt class="card-dt">创建时间</dt>
        <dd class="card-dd">{{ createdTime }}</dd>
      </dl>
    </el-card>
    <Operation
      :data-source="templateData"
      v-if="templateData.isShow"
    />
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import moment from 'moment'
import Operation from '../operation.vue'
@Component({
  components: {
    Operation
  }
})
class SchedulersDetailCardComponent extends Vue {
  private UUID: String;
  private repeat: String;
  private period: String;
  private schedulerTime: Number;
  private createdTime: any;
  private schedulerName: String = '';
  private templateData: any = {
    isShow: false
  };
  public currentForm: object; // 当前定时器form 修改使用
  created() {
    this.UUID = this.$route.params.uuid
    this.period = this.$route.params.period
    this.getDetail()
  }

  /**
   * @description 获取当前定时器详情
   */
  async getDetail() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: `/rds/scheduler/${this.UUID}`
      })
      this.schedulerName = json.scheduler_name || ''
      this.repeat = json.repeat === 1 ? '重复执行' : '仅执行一次'
      this.schedulerTime = json.scheduler_time
      this.createdTime = moment(json.created_at * 1000).format('YYYY-MM-DD HH:mm')
      this.currentForm = json
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @param command 当前操作类型 修改/删除/添加/移除
   * @description 卡片右上角操作更多
   */
  handleCommand(command: string) {
    let that = this
    if (command === 'edit') {
      that.templateData.currentForm = this.currentForm
      that.templateData.isEdit = true
      that.templateData.isShow = true
    }
  }
}
export default SchedulersDetailCardComponent
</script>
<style lang="scss">
  .schedulers-detail-card {
    .card-horizontal {
      padding: 10px 20px 20px 20px;
      margin: 0;
      .card-dt {
        width: 50px;
        text-align: right;
        float: left;
        color: #324558;
      }
      .card-dd {
        padding: 1px 0 20px 60px;
        border-bottom: 0 none;
      }
    }
  }
</style>

