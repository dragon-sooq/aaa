
<template>
  <div class="schedulers-detail">
    <el-row>
      <el-col
        :span="6"
        class="pd-10"
      >
        <Card />
      </el-col>

      <el-col
        :span="18"
        class="vLine"
      >
        <Tab />
      </el-col>
    </el-row>
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import {Drawer} from '@/compkg/components'
import Tab from './tab.vue'
import Card from './card.vue'
interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Card,
    Tab,
    Table
  }
})
class SchedulersDetailComponent extends Vue {

  private templateData: any = {
    isShow: false
  };

  private like: string = '' // 搜索字段
  private isAdmin: Boolean = true; // 系统默认true / 自定义 false
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  public tableDataSource: object = {
    btnConfig: {
      list: [
        {
          type: 'danger',
          name: '创建定时器'
        }
      ],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    // tabsConfig: {
    //   activeName: '系统默认',
    //   list: [{
    //     id: 1,
    //     label: '系统默认',
    //     name: '系统默认'
    //   }, {
    //     id: 2,
    //     label: '自定义',
    //     name: '自定义'
    //   }],
    //   change: (name: string) => {
    //     this.changeTab(name)
    //   }
    // },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: 'UUID',
          prop: 'uuid',
          sortable: 'custom',
          click: (row) => {
            this.viewDetail(row)
          }
        },
        {
          label: '名称',
          prop: 'scheduler_name'
        },
        {
          label: '类型',
          prop: 'repeat'
        },
        {
          label: '周期',
          prop: 'period',
          filter: 'dbNullFilter'
        },
        {
          label: '所属项目',
          prop: 'description',
          filter: 'dbNullFilter'
        },
        {
          label: '时间',
          prop: 'scheduler_time',
          filter: 'dbNullFilter'
        },
        {
          label: '创建时间',
          prop: 'created_at',
          filter: [
            {
              name: 'dateStrFilter',
              arg: ['YYYY-MM-DD HH:mm']
            },
            'dbNullFilter'
          ]
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  changeTab(name: String) {
    this.isAdmin = name === '系统默认'
    console.log(this.isAdmin)
    this.getList()
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.tableDataSource['btnConfig'].list[0].disabled = !(list && list.length)
    this.choosedIds = list.map((chooseItem: any) => chooseItem.id)
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    console.log(name)
    this.templateData.isShow = true
  }

  /**
   * @param val 1/2/3
   * @description 格式化日期
   * @return val所符合的星期
   */
  formatDate(val: any) {
    let date = {
      0: '周一',
      1: '周二',
      2: '周三',
      3: '周四',
      4: '周五',
      5: '周六',
      6: '周日'
    }
    return date[Number(val)]
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/scheduler',
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      this.tableDataSource['tableConfig'].data = json.scheduler || []
      this.tableDataSource['tableConfig'].data.forEach((item: any) => {
        if (item.repeat && item.period.split('$').length >= 2) {
          let currentStr = item.period.split('$')[1].split('-')[0] // 把周期按照$符分割, 得到的是[‘’, ‘2-1’] 取[1]再按照 - 分割 再取 [0] 得到当前周期type
          let currentDate = item.period.split('$')[1].split('-').slice(1, item.period.split('$')[1].split('-').length)
          console.log(currentDate)
          // console.log(currentDate)
          if ((currentStr === '2' || currentStr === '0') && currentDate.length) {
            item.period = `每${currentDate[0]}` + (currentStr === '2' ? '天' : '小时')
          } else if (currentStr === '1') {
            item.period = '每天'
          } else if ((currentStr === '3' || currentStr === '4') && currentDate.length) {
            let str = ''
            currentDate.forEach((val: any) => {
              if (currentStr === '3') {
                str += (this.formatDate(val)) + '、'
              } else {
                str += (Number(val) === 31 ? '月末' : (Number(val) + 1)) + (Number(val) === 31 ? '' : '号') + '、'
              }
            })
            str = str.substr(0, str.length - 1)
            item.period = (currentStr === '3' ? '每周: ' : '每月: ') + str
          }
        } else {
          item.period = ''
        }
        item.repeat = item.repeat ? '重复执行' : '仅执行一次'
      })
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 删除角色
  * @param items 选中行
  */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteRole(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
   * @param id 要删除的id
   * @description 删除角色
   */
  async deleteRole(id: String) {
    try {
      let json = await this.$axios({
        method: 'DELETE',
        url: `/auth/roles/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 查看模板详情
   * @param item 当前行
   */
  viewDetail(item: Object) {
    // this.$router.push(`/ops/detail/${item['uuid']}`)
    this.$router.push({ path: `/ops/detail/${item['uuid']}` })
    // this.$router.push({ path: '/authorization/role' })
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default SchedulersDetailComponent
</script>

<style lang="scss">
  .schedulers-detail {
    .box-card {
      width: 95%;
    }
  }
</style>

