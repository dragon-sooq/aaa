
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <Operation
      :data-source="taskData"
      v-if="taskData.isShow"
    />
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import Operation from './operation.vue'
interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Operation,
    Table
  }
})
class SchedulersDetailComponent extends Vue {

  private taskData: any = {
    isShow: false
  };

  private like: string = '' // 搜索字段
  private isAdmin: Boolean = true; // 系统默认true / 自定义 false
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  public tableDataSource: object = {
    tabsConfig: {
      activeName: '任务',
      list: [{
        id: 1,
        label: '任务',
        name: '任务',
        icon: 'el-icon-s-claim'
      }, {
        id: 2,
        label: '历史记录',
        name: '历史记录',
        icon: 'el-icon-time'
      }],
      change: (name: string) => {
        this.changeTab(name)
      }
    },
    btnConfig: {
      dropdownList: [{
        titleName: '更多操作',
        list: [
          {
            name: '修改',
            disabled: true
          },
          {
            name: '启用',
            disabled: true
          },
          {
            name: '禁用',
            disabled: true
          },
          {
            name: '删除',
            disabled: true
          }
        ]
      }],
      list: [
        {
          name: '创建'
        }
      ],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: 'UUID',
          prop: 'uuid',
          sortable: 'custom',
          click: (row) => {
            this.viewDetail(row)
          }
        },
        {
          label: '名称',
          prop: 'task_name'
        },
        {
          label: '类型',
          prop: 'type'
        },
        {
          label: '状态',
          prop: 'status',
          filter: 'TaskStatusFilter'
        },
        {
          label: '资源',
          prop: 'resource', // TODO
          filter: 'dbNullFilter'
        },
        {
          label: '时间',
          prop: 'scheduler_time',
          filter: 'dbNullFilter'
        },
        {
          label: '创建时间',
          prop: 'created_at',
          filter: [
            {
              name: 'dateStrFilter',
              arg: ['YYYY-MM-DD HH:mm']
            },
            'dbNullFilter'
          ]
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  changeTab(name: String) {
    console.log(name)
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (list.length) {
        this.choosedIds.push(list[0]['uuid'])
        if (list.length === 1) {
          // 只选中一个,把所有按钮置为可用状态
          item['disabled'] = false
          // 如果选中行状态是启用 把
          if (list[0]['status'] === 1 && item['name'] === '启用') {
            item['disabled'] = true
          } else if (list[0]['status'] === 0 && item['name'] === '禁用') {
            item['disabled'] = true
          }
        } else {
          item['disabled'] = true
          if (item['name'] === '删除') {
            item['disabled'] = false
          }
          this.choosedIds = list.map((chooseItem: any) => chooseItem.uuid)
        }
        this.choosedIds = Array.from(new Set(this.choosedIds))
      } else {
        item['disabled'] = true
        this.choosedIds = []
      }
    })
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    console.log(name)
    if (name !== '修改' && name !== '创建') {
      this.changeTaskStatus(name)
    } else if (name === '创建') {
      this.taskData.isShow = true
    } else {
      this.editTask()
    }
  }

  /**
   * @description 编辑任务
   */
  editTask() {
    let task = this.tableDataSource['tableConfig'].data.filter((data) => data.uuid === this.choosedIds[0])[0]
    this.taskData.isEdit = true
    this.taskData.uuid = this.choosedIds[0]
    this.taskData.resource = task.resource
    this.taskData.type = task.type
    this.taskData.task_name = task.task_name
    this.taskData.isShow = true
  }

  /**
   * @description 删除定时器任务
   */
  async deleteTask() {
    let that = this
    try {
      await (that as any).$confirm(`确定要${name}定时器任务吗？`)
      let flag = name === '启用' ? 'start' : 'stop'
      let json = await this.$axios({
        method: 'GET',
        url: `/rds/scheduler/task/${that.choosedIds[0]}/` + flag
      })
      that.getList()
    } catch (error) {
      console.error(error)
    }
  }

  /**
   * @description 定时任务操作 删除 启用 / 禁用
   */
  async changeTaskStatus(name: string) {
    let that = this
    try {
      await (that as any).$confirm(`确定要${name}定时器任务吗？`)
      let url = `/rds/scheduler/task/${that.choosedIds[0]}`
      if (name !== '删除') {
        let flag = name === '启用' ? 'start' : 'stop'
        url += '/' + flag
      }
      let json = await this.$axios({
        method: name !== '删除' ? 'GET' : 'DELETE',
        url: url
      })
      that.getList()
    } catch (error) {
      console.error(error)
    }
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/rds/scheduler/task',
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order,
          scheduler_uuid: this.$route.params.uuid
        }
      })
      this.tableDataSource['tableConfig'].data = json.task || []
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 删除角色
  * @param items 选中行
  */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteRole(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
   * @param id 要删除的id
   * @description 删除角色
   */
  async deleteRole(id: String) {
    try {
      let json = await this.$axios({
        method: 'DELETE',
        url: `/auth/roles/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * @description 查看模板详情
   * @param item 当前行
   */
  viewDetail(item: Object) {
    // this.$router.push(`/ops/detail/${item['uuid']}`)
    this.$router.push({ path: `/ops/detail/${item['uuid']}` })
    // this.$router.push({ path: '/authorization/role' })
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default SchedulersDetailComponent
</script>

<style lang="scss">
  .schedulers-detail {
    .box-card {
      width: 95%;
    }
  }
</style>

