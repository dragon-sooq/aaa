<template>
  <div class="login">
    <div class="login-header">
      <div
        class="widthLimit"
        style="height: 100%"
      >
        <!-- <img
          src="../../assets/images/logo_03.png"
          class="logo mr-5"
          style="height: 100%;"
          title="万里开源"
        > -->
      </div>
    </div>
    <div class="login-body">
      <div class="login-body-box">
        <div class="login-banner">
          <a 
            href="#" 
            class="login-body-txt-box"
          >
            <h1 class="box-title">数据库平台</h1> 
            <ul class="box-banner">
              <li>构建涵盖IaaS、PaaS、SaaS的多云服务管理体系</li>
              <li>多云资源状态的全局视图</li>
              <li>资源的统一管理、申请和供应，支持多数据中心</li>
              <li>面向异构混合云环境的运维管理、监控和告警</li>
            </ul>  
          </a>
        </div>
        <div
          class="login-common"
          style="margin-left: 75%;"
        >
          <div class="loginTypeDiv">
            <span class="loginTypeNoSelected">
              账号登录
            </span>
          </div>

          <div class="errorTip loginFormDiv" />

          <div class="loginFormDiv">
            <div class="inputField">
              <span class="tiny-textbox-container">
                <input
                  type="text"
                  style="-webkit-box-shadow: 0 0 0px 1000px white inset;"
                  autocomplete="off"
                  v-model="loginForm.name"
                  placeholder="账号名/邮箱"
                  class="tiny-input-text"
                >
              </span>
            </div>

            <div class="inputField">
              <span class="tiny-textbox-container">
                <input
                  style="-webkit-box-shadow: 0 0 0px 1000px white inset;"
                  autocomplete="off"
                  type="password"
                  placeholder="密码"
                  v-model="loginForm.password"
                  class="tiny-input-text"
                >
              </span>
            </div>
          </div>
          <div class="buttonAreaDiv">
            <div class="buttonArea">
              <el-button 
                style="width: 100%;"
                type="primary" 
                @click="submitLogin()"
              >
                登录
              </el-button>
            </div>
          </div>
          <!-- <el-form
            ref="loginForm"
            label-align="left"
            label-width="80px"
            layout="horizontal"
            v-bind="formItemLayout"
            :model="loginForm"
            :rules="loginRules"
          >
            <el-form-item
              has-feedback
              label="账号"
              prop="name"
            >
              <el-input
                style="width: 80%"
                v-model="loginForm.name"
                autocomplete="off"
              />
            </el-form-item>
            <el-form-item
              has-feedback
              label="密码"
              prop="password"
            >
              <el-input
                v-model="loginForm.password"
                style="width: 80%"
                type="password"
                autocomplete="off"
              />
            </el-form-item>
            <el-form-item>
              <el-button 
                type="primary" 
                @click="submitLogin('loginForm')"
              >
                登录
              </el-button>
            </el-form-item>
          </el-form> -->
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator'
import { Getter, Mutation, Action, namespace } from 'vuex-class'
import MD5 from 'crypto-js/md5'
import CACHE from '@/utils/cache'
const userModule = namespace('user')

@Component
class LoginComponent extends Vue {
  @Getter loading;
  @userModule.Action('SaveUser') updateUserInfo;

  @userModule.Action('Login') saveTokenInfo;

  private loginList: Array<object> = [
    {
      name: '',
      password: ''
    }
  ];
  private loginChoose: number = 0;
  private loginForm: any = {
    name: '',
    password: ''
  };
  private loginRules: Object = {
    name: [{ required: true, message: '请输入账号', trigger: 'change' }],
    password: [{ required: true, message: '请输入密码', trigger: 'change' }]
  };
  private userInfo: any;
  private companyIndex: number;
  private companyList: Array<object> = [];
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }

  created() {
    this.loginChange()
  }

  /**
   * 选择框
   */
  loginChange() {
    let that = this
    let { name, password }: any = that.loginList[that.loginChoose]
    that.loginForm = {
      name,
      password
    }
  }

  /**
   * 提交表单
   */
  submitLogin() {
    let that = this
    that.doLogin()
    // (that.$refs[formName] as any).validate((valid: boolean) => {
    //   if (valid) {
    //     // that.doLogin();
    //   }
    // });
  }

  /**
   * 根据用户名密码获取token
   */
  async doLogin() {
    let that = this
    let { name, password } = that.loginForm
    let token = await (that as any).$axios.post('/auth/login', {
      name,
      // password: MD5(password).toString(),
      password,
      skipAuth: true
    })
    await (that as any).saveTokenInfo(token.token)
    that.getUserInfo(token)
  }

  /**
   * 根据token获取用户信息
   */
  async getUserInfo(token: string) {
    let that = this
    that.userInfo = await this.$axios({
      url: '/auth/identity_info',
      method: 'get',
      data: token
    })
    let permissions = that.userInfo.roleTypes === 'admin' ? that.userInfo.permissions.management_background : that.userInfo.permissions.member
    // 缓存用户信息
    await (that as any).updateUserInfo(that.userInfo)
    CACHE.localStorage.put('permission', permissions)
    location.reload()
    setTimeout(() => {
      this.$router.push({ path: '/dashboard' })
    }, 300)
  }
}

export default LoginComponent
</script>

<style lang="scss" scoped>
  @import './index.scss';
</style>
