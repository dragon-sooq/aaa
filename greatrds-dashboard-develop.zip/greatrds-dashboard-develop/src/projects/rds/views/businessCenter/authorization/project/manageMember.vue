<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    title="管理成员"
    :width="'720px'"
  >
    <el-form
      ref="memberForm"
      label-align="right"
      layout="horizontal"
      style="padding: 35px 35px 0 35px;"
      label-width="120px"
      v-bind="formItemLayout"
      :model="memberForm"
    >
      <el-form-item
        has-feedback
        label="角色"
      >
        <el-select
          v-model="memberForm.roleId"
          placeholder="请选择"
          style="width: 60%;"
        >
          <el-option
            v-for="item in roleList"
            :key="item.id"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="未关联用户"
      >
        <el-select
          v-model="memberForm.userId"
          placeholder="请选择"
          style="width: 60%;"
        >
          <el-option
            v-for="item in userList"
            :key="item.user_id"
            :label="item.name"
            :value="item.user_id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label=""
      >
        <el-button
          type="primary"
          :loading="loading"
          :disabled="!memberForm.userId || !memberForm.roleId"
          style="margin-left: 70%;"
          :size="$root.commonSize"
          @click="addData()"
        >
          添加
        </el-button>
      </el-form-item>
    </el-form>

    <el-table
      :data="tableData"
      border
      style="width: 100%"
    >
      <el-table-column
        prop="user_name"
        label="已关联用户"
      />
      <el-table-column
        prop="role_name"
        label="角色"
      />
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            size="mini"
            type="danger"
            @click="handleDelete(scope.$index, scope.row)"
          >
            删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm()"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'

@Component({
  components: {
    DialogLayer
  }
})
class ProjectManageMemberComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  private loading: Boolean = false;
  private isEdit: Boolean = false; // 获取列表接口后决定t/f t的话保存时先调解绑接口 再去绑定 f直接绑定列表已有数据
  private userList: Array<Object> = [];
  private roleList: Array<Object> = [];
  private tableData: Array<Object> = [];
  private deleteData: Array<Object> = []; // 临时缓存删除的数据, 点击提交时发给server
  private memberForm: Object = {
    userId: '',
    roleId: ''
  };
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private defaultProps: Object = {
    children: 'children',
    label: 'label'
  }
  created() {
    this.getRelatedMember()
    this.getRelatedRoles()
    this.getRelatedList()
  }

  /**
   * @description 查询已关联列表
   */
  async getRelatedList() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${that.dataSource.id}/role_user`
      })
      console.log(json)
      if (json && json.assignments && json.assignments.length) {
        that.isEdit = true
        json.assignments.forEach((item: Object) => {
          item['isAdded'] = true
        })
        that.tableData = json.assignments
      }
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 查询可关联用户
   */
  async getRelatedMember() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${that.dataSource.id}/non_member`
      })
      console.log(json)
      that.userList = json.users
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 查询可关联角色
   */
  async getRelatedRoles() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: '/auth/roles/type/member'
      })
      console.log(json)
      that.roleList = json.roles || []
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 向表格添加已选数据
   */
  addData() {
    let chooseUser: any = this.userList.find((item: Object) => item['user_id'] === this.memberForm['userId'])
    let chooseRole: any = this.roleList.find((item: Object) => item['id'] === this.memberForm['roleId'])
    console.log(chooseRole)
    this.tableData.push(
      {
        role_id: chooseRole['id'],
        role_name: chooseRole['name'],
        user_id: chooseUser['user_id'],
        user_name: chooseUser['name']
      }
    )
    this.memberForm = {
      userId: '',
      roleId: ''
    }
  }

  /**
   * @description 保存
   */
  async submitForm() {
    if (this.deleteData.length) {
      // 先解绑
      await Promise.all(this.deleteData.map((item) => this.unassignProject(item)))
    }
    if (this.tableData.length) {
      await Promise.all(this.tableData.map((item) => this.relatedProject(item)))
    }
    this.$notify({
      title: '操作成功',
      message: '关联成功',
      type: 'success'
    })
    this.dataSource.isShow = false
  }

  /**
   * @description 解绑项目
   */
  async unassignProject(item: Object) {
    let that = this
    try {
      let json = await that.$axios({
        method: 'POST',
        url: `/auth/roles/${that.dataSource.id}/${item['user_id']}/${item['role_id']}/unassign`
      })
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 关联项目
   */
  async relatedProject(item: Object) {
    let that = this
    // 没有project_id说明是自己添加的
    if (!item['project_id']) {
      try {
        let json = await that.$axios({
          method: 'POST',
          url: `/auth/roles/${that.dataSource.id}/${item['user_id']}/${item['role_id']}/assignment`
        })
      } catch (error) {
        (that as any).$handleError(error)
      }
    }
  }

  /**
   * @description 删除表格一行
   */
  handleDelete(index: number, item: Object) {
    this.tableData.splice(index, 1)
    if (item['isAdded']) {
      this.deleteData.push(item)
    }
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PATCH' : 'POST',
        url: that.dataSource.isEdit ? `/auth/roles/${that.dataSource.id}` : '/auth/roles'
        // data: that.memberForm
      })
      that.loading = false
      that.$message({
        message: '操作成功',
        type: 'success'
      })
      that.dataSource.isShow = false;
      (that as any).$parent.getList()
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default ProjectManageMemberComponent
</script>

