
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <!-- 项目详情弹窗 -->
    <Drawer
      :title="currentProject.name"
      :visible.sync="isViewShow"
      :show-modal="false"
    >
      <Detail
        :data-source="currentProject"
      />
    </Drawer>
    <!-- 创建/编辑弹窗 -->
    <Operation
      :data-source="projectData"
      v-if="projectData.isShow"
    />
    <!-- 管理成员弹窗 -->
    <ManageMember
      :data-source="manageMemberData"
      v-if="manageMemberData.isShow"
    />
  </div>
</template>
<script lang='ts'>

import { Vue, Component, Prop } from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import Detail from './detail.vue'
import ManageMember from './manageMember.vue'
import { Drawer } from '@/compkg/components/index'
import Utils from '@/utils'
import Operation from './operation.vue'

interface Sort {
  prop: null | string;
  order: null | string;
}

@Component({
  components: {
    Drawer,
    Detail,
    Operation,
    ManageMember,
    Table
  }
})
class ProjectComponent extends Vue {
  private isViewShow: Boolean = false
  private currentProject: Object = {}
  private manageMemberData: Object = {
    isShow: false
  };
  private projectData: any = {
    isShow: false,
    isEdit: false
  };

  private like: string = '' // 搜索字段
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = [];
  public tableDataSource: object = {
    btnConfig: {
      left: true,
      list: [{
        type: 'primary',
        name: '创建',
        icon: 'fa fa-biaodanguanli'
      }],
      dropdownList: [{
        titleName: '操作',
        list: [
          {
            name: '管理成员',
            disabled: true
          },
          {
            name: '启用',
            disabled: true
          },
          {
            name: '禁用',
            disabled: true
          },
          {
            name: '编辑',
            disabled: true
          },
          {
            name: '删除',
            disabled: true
          }
        ]
      }],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tabsConfig: {
      activeName: '项目',
      list: [{
        id: 1,
        label: '项目',
        name: '项目'
      }]
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '项目名称',
          prop: 'name',
          scopedSlots: { customRender: 'templateCode' },
          sortable: 'custom',
          click: (row) => {
            this.showDetail(row)
          }
        }, {
          label: '描述',
          prop: 'description',
          sortable: 'custom',
          filter: 'dbNullFilter'
        }, {
          label: '项目id',
          prop: 'id'
        }, {
          label: '管理状态',
          prop: 'enabled',
          sortable: 'custom',
          filter: 'dbStatusFilter'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  /**
   * 表格的排序条件发生变化时触发
   * @param item - 当前表格对象项及order
   */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  showDetail(item: Object) {
    this.isViewShow = true
    this.currentProject = item
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (list.length) {
        this.choosedIds.push(list[0]['id'])
        if (list.length === 1) {
          // 只选中一个,把所有按钮置为可用状态
          item['disabled'] = false
          // 如果选中行状态是启用
          console.log(list['enabled'])
          if (list[0]['enabled'] && item['name'] === '启用') {
            item['disabled'] = true
          } else if (!list[0]['enabled'] && item['name'] === '禁用') {
            item['disabled'] = true
          }
        } else {
          item['disabled'] = true
          if (item['name'] === '删除') {
            item['disabled'] = false
          }
          this.choosedIds = list.map((chooseItem: any) => chooseItem.id)
        }
        this.choosedIds = Array.from(new Set(this.choosedIds))
      } else {
        item['disabled'] = true
        this.choosedIds = []
      }
    })
  }

  /**
   * @description 头部按钮操作
   */
  btnOperation(name: string) {
    if (name === '创建') {
      this.projectData.isShow = true
    } else if (name === '删除') {
      this.$confirm('此操作将永久删除项目, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async() => {
        await Promise.all(this.choosedIds.map((item) => this.deleteProject(item)))
        await this.getList()
      })
    } else if (name === '编辑' && this.choosedIds.length) {
      this.editProject()
    } else if (name === '启用' || name === '禁用') {
      let chooseItem = this.tableDataSource['tableConfig'].data.find((item: Object) => item['id'] === this.choosedIds[0])
      this.changeStatus(chooseItem)
    } else if (name === '管理成员') {
      let project = this.tableDataSource['tableConfig'].data.filter((data) => data.id === this.choosedIds[0])[0]
      if (project.name === 'admin') {
        this.$notify({
          title: '操作成功',
          message: 'admin项目不可编辑',
          type: 'error'
        })
        return
      }
      this.manageMemberData['isShow'] = true
      this.manageMemberData['id'] = this.choosedIds[0]
    }
  }

  /**
   * @description 改变项目状态 启用/禁用
   * @params item 选中行
   */
  async changeStatus(item: Object) {
    let that = this
    try {
      let json = await that.$axios({
        method: 'PATCH',
        url: `/auth/projects/${item['id']}`,
        data: {
          name: item['name'],
          enabled: !item['enabled']
        }
      })
      that.$notify({
        title: '操作成功',
        message: `${item['id']}状态变更成功`,
        type: 'success'
      })
      that.getList()
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 编辑项目
   */
  editProject() {
    let project = this.tableDataSource['tableConfig'].data.filter((data) => data.id === this.choosedIds[0])[0]
    if (project.name === 'admin') {
      this.$notify({
        title: '操作失败',
        message: 'admin项目不可编辑',
        type: 'error'
      })
      return
    }
    this.projectData.isShow = true
    this.projectData.isEdit = true
    this.projectData.id = this.choosedIds[0]
  }

  /**
   * @param id 要删除的id
   * @description 删除项目
   */
  async deleteProject(id: String) {
    let that = this
    try {
      let json = await that.$axios({
        method: 'DELETE',
        url: `/auth/projects/${id}`
      })
      that.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      this.tableDataSource['tableConfig'].loading = true
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/projects',
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      this.tableDataSource['tableConfig'].data = json.projects || []
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

  editTemplate(item: object) {
    console.log(item)
    const that: any = this
    that.$router.push({
      name: 'AlarmEdit',
      query: {
        id: item['id']
      }
    })
  }
}
export default ProjectComponent
</script>

