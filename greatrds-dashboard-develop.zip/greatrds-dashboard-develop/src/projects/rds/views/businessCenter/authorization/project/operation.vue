<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.isEdit ? '编辑项目' : '创建项目'"
    :width="'720px'"
  >
    <el-form
      ref="projectForm"
      label-align="right"
      layout="horizontal"
      label-width="80px"
      style="padding: 35px;"
      v-bind="formItemLayout"
      :model="projectForm"
      :rules="projectRules"
    >
      <el-form-item
        has-feedback
        label="项目名称"
        prop="name"
      >
        <el-input
          v-model="projectForm.name"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="描述"
      >
        <el-input
          v-model="projectForm.description"
          type="textarea"
          autocomplete="off"
        />
      </el-form-item>

      <!-- <a-form-model-item 
        slot="footer"
        :wrapper-col="{ span: 14, offset: 4 }"
      >
        
      </a-form-model-item> -->
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm('projectForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
const worktableModule = namespace('worktable')

@Component({
  components: {
    DialogLayer
  }
})
class ProjectOperationComponent extends Vue {
  @Prop({required: true}) dataSource: any;

  private template: any = null;
  private loading: boolean = false;
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private projectForm: any = {
    name: '',
    description: ''
  };
  private projectRules: Object = {
    name: [{ required: true, message: '请输入项目名称', trigger: 'change' }]
  };

  created() {
    if (this.dataSource.id) {
      this.getProjectDetail()
    }
  }

  async getProjectDetail() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${that.dataSource.id}`
      })
      that.projectForm.name = json.name
      that.projectForm.description = json.description
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PATCH' : 'POST',
        url: that.dataSource.isEdit ? `/auth/projects/${that.dataSource.id}` : '/auth/projects',
        data: that.projectForm
      })
      that.loading = false
      that.$notify({
        title: '操作成功',
        message: that.dataSource.isEdit ? '修改项目成功' : '创建项目成功',
        type: 'success'
      })
      that.dataSource.isShow = false;
      (that as any).$parent.getList()
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default ProjectOperationComponent
</script>

