<template>
  <div class="common-detail">
    <el-row>
      <el-col :span="24">
        <h4>
          基本属性
        </h4>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="2">
        <span>
          项目名称：
        </span>
      </el-col>
      <el-col :span="12">
        <div>
          {{ projectInfo.name }}
        </div>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="2">
        <span>
          项目ID：
        </span>
      </el-col>
      <el-col :span="12">
        <div>
          {{ projectInfo.id }}
        </div>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="2">
        <span>
          管理状态：
        </span>
      </el-col>
      <el-col :span="12">
        <div>
          {{ projectInfo.enabled ? '启用' : '禁用' }}
        </div>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="2">
        <span>
          描述：
        </span>
      </el-col>
      <el-col :span="12">
        <div>
          {{ projectInfo.description | dbNullFilter }}
        </div>
      </el-col>
    </el-row>

    <Table
      :data-source="tableDataSource"
      style="height: calc(100vh - 320px);"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import { Drawer } from '@/compkg/components'
@Component({
  components: {
    Drawer,
    Table
  }
})
class ProjectDetailComponent extends Vue {
  @Prop({required: true}) dataSource: any
  private projectInfo: Object = {
  };
  public tableDataSource: Object = {
    tabsConfig: {
      activeName: '项目成员',
      list: [{
        id: 1,
        label: '项目成员',
        name: '项目成员'
      }]
    },
    tableConfig: {
      columns: [
        {
          label: '用户ID',
          prop: 'user_id'
        }, {
          label: '姓名',
          prop: 'name',
          filter: 'dbNullFilter'
        }, {
          label: '角色',
          prop: 'role',
          filter: 'dbNullFilter'
        }, {
          label: '创建时间',
          prop: 'created_at',
          filter: 'dbDateFilter'
        }
      ],
      data: []
    }
  }

  created() {
    this.getList()
    this.getMember()
  }

  /**
   * @description 获取当前项目所属成员
   */
  async getMember() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${this.dataSource.id}/member`
      })
      console.log(json)
      that.tableDataSource['tableConfig'].data = json.users || []
    } catch (error) {
      (that as any).$handleError(error)
    }
  }

  /**
   * @description 获取列表
   */
  async getList() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/projects/${this.dataSource.id}`
      })
      that.projectInfo = json
    } catch (error) {
      (that as any).$handleError(error)
    }
  }
}
export default ProjectDetailComponent
</script>

<style lang="scss">
</style>

