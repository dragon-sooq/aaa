<template>
  <div class="common-detail">
    <Table
      :data-source="tableDataSource"
      style="height: calc(100vh - 320px);"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import { Drawer } from '@/compkg/components'
@Component({
  components: {
    Drawer,
    Table
  }
})
class RoleDetailComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  public tableDataSource: Object = {
    tabsConfig: {
      activeName: '角色信息',
      list: [{
        id: 1,
        label: '角色信息',
        name: '角色信息'
      }]
    },
    tableConfig: {
      columns: [
        {
          label: '用户ID',
          prop: 'user_id'
        }, {
          label: '用户名称',
          prop: 'user_name',
          filter: 'dbNullFilter'
        }, {
          label: '项目id',
          prop: 'project_id',
          filter: 'dbNullFilter'
        }, {
          label: '项目名称',
          prop: 'project_name',
          filter: 'dbNullFilter'
        }
      ],
      data: []
    }
  }

  created() {
    this.getList()
  }

  /**
   * @description 获取列表
   */
  async getList() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/roles/${this.dataSource.id}`
      })
      that.tableDataSource['tableConfig'].data = json.user_role_project
    } catch (error) {
      (that as any).$handleError(error)
    }
  }
}
export default RoleDetailComponent
</script>

<style lang="scss">
</style>

