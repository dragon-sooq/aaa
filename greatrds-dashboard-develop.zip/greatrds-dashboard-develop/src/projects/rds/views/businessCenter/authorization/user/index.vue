
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <!-- 用户信息修改弹窗 -->
    <Password
      :data-source="userDataInfo"
      @get-list="getList"
    />

    <!-- 用户信息修改弹窗 -->
    <Role
      :data-source="userRoleInfo"
      @get-list="getList"
    />

    <!-- 用户详情侧拉 -->
    <Drawer
      :title="currentUser.name"
      :visible.sync="currentUser.isShow"
      :show-modal="false"
    >
      <Detail
        :data-source="currentUser"
      />
    </Drawer>

    <!-- 创建用户 -->
    <Operation
      :data-source="userData"
      v-if="userData.isShow"
      @get-list="getList"
    />
  </div>
</template>
<script lang='ts'>

import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import {Drawer} from '@/compkg/components'
import Operation from './operation.vue'
import Password from './passwd.vue'
import Role from './role.vue'
import Detail from './detail.vue'

interface Sort {
  prop: null | string;
  order: null | string;
}

interface CurrentUser {
    id?:string,
    name?:string,
    isShow?:boolean
}

@Component({
  components: {
    Drawer,
    Operation,
    Password,
    Role,
    Table,
    Detail
  }
})

class UserComponent extends Vue {

  private currentUser: CurrentUser = {
    id: '',
    name: '',
    isShow: false
  }

  private userRoleInfo: any = {
    isShow: false,
    isEdit: false,
    userId: '',
    userType: 'admin'
  }

  private userDataInfo: any = {
    isShow: false,
    isEdit: false,
    userId: ''
  }
  private userData: any = {
    isShow: false,
    isEdit: false,
    type: 'admin'
  }

  private like: string = '' // 搜索字段
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private selectIds: string[] = []
  private activeTab: string = 'admin'
  public tableDataSource: object = {
    btnConfig: {
      left: true,
      list: [{
        type: 'primary',
        name: '创建',
        icon: 'fa fa-biaodanguanli'
      }],
      dropdownList: [
        {
          titleName: '操作',
          list: [
            {
              name: '修改密码',
              disabled: true,
              icon: 'fa fa-delete'
            },
            {
              name: '修改角色',
              disabled: true,
              icon: 'fa fa-delete'
            },
            {
              name: '启用',
              disabled: true,
              icon: 'fa fa-delete'
            },
            {
              name: '禁用',
              disabled: true
            },
            {
              name: '删除',
              disabled: true
            }
          ]
        }],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tabsConfig: {
      activeName: 'admin',
      list: [{
        id: 1,
        label: '管理后台用户',
        name: 'admin'
      }, {
        id: 2,
        label: '控制台用户',
        name: 'member'
      }],
      change: (label) => this.handleTabChange(label)
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '用户名',
          prop: 'name',
          sortable: 'custom',
          click: (row:object) => {
            this.showDetail(row)
          }
        },
        {
          label: '启用状态',
          prop: 'enabled',
          filter: 'dbStatusFilter'
        },
        {
          label: '用户类型',
          prop: 'type',
          filter: 'dbUserFilter'
        },
        {
          label: '用户id',
          prop: 'user_id'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * 当选择项发生变化时会触发该事件
   * @param list 已选数据
   */
  handleSelectionChange(list: object[]) {
    this.selectIds = list.map((chooseItem: any) => chooseItem.user_id)
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (item['name'] === '修改密码') {
        item['disabled'] = list.length !== 1
      } else if (item['name'] === '修改角色') {
        item['disabled'] = (list.length !== 1 || list[0]['name'] === 'admin')
      } else if (item['name'] === '启用') {
        item['disabled'] = list.length === 0
      } else if (item['name'] === '禁用') {
        item['disabled'] = list.length === 0
      } else if (item['name'] === '删除') {
        item['disabled'] = list.length === 0
      }
    })
  }

  /**
   * tab切换触发事件
   * @param label 已选数据
   */
  handleTabChange(label) {
    this.activeTab = label === '管理后台用户' ? 'admin' : 'member'
    this.getList()
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    if (name === '创建') {
      this.userData.isShow = true
      this.userData.isEdit = false
      this.userData.type = this.activeTab
    } else if (name === '修改密码' && this.selectIds.length === 1) {
      let row = this.tableDataSource['tableConfig'].data.filter((data) => data.user_id === this.selectIds[0])
      this.changePassword(row[0])
    } else if (name === '修改角色' && this.selectIds.length === 1) {
      let row = this.tableDataSource['tableConfig'].data.filter((data) => data.user_id === this.selectIds[0])
      this.changeRole(row[0])
    } else if (name === '删除' && this.selectIds.length) {
      if (this.validSelect()) {
        this.handleDelete(this.selectIds)
      }
    } else if (name === '启用' && this.selectIds.length) {
      if (this.validSelect()) {
        this.handleChangeStatus('true')
      }
    } else if (name === '禁用' && this.selectIds.length) {
      if (this.validSelect()) {
        this.handleChangeStatus('false')
      }
    }
  }

  validSelect() {
    let row = this.tableDataSource['tableConfig'].data.filter((data) => data.name === 'admin')
    if (row.length > 0) {
      this.$notify({
        title: '操作错误',
        message: '不可以修改admin项目',
        type: 'error'
      })
    }
    return row.length === 0
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      this.tableDataSource['tableConfig'].loading = true
      let json = await this.$axios({
        method: 'GET',
        url: `/auth/users/type/${this.activeTab}`,
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      this.tableDataSource['tableConfig'].data = json.users || []
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 修改密码
  * * @param row 当前行
  */
  changePassword(row:any) {
    this.userDataInfo.isShow = true
    this.userDataInfo.isEdit = true
    this.userDataInfo.userId = row.user_id
  }

  /**
  * 修改角色
  * * @param row 当前行
  */
  changeRole(row:any) {
    this.userRoleInfo.isShow = true
    this.userRoleInfo.isEdit = true
    this.userRoleInfo.userId = row.user_id
    this.userRoleInfo.userType = this.activeTab
  }

  /**
  * 用户详情
  * * @param item 当前行
  */
  showDetail(item: any) {
    this.currentUser.isShow = true
    this.currentUser.id = item.user_id
    this.currentUser.name = item.name
  }

  /**
   * 删除用户
   * @param items 选中行
   */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteUser(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
  * 删除用户
  * @param id 用户id
  */
  async deleteUser(id: string) {
    try {
      await this.$axios({
        method: 'delete',
        url: `/auth/users/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      (this as any).$handleError(error)
    }
  }

  /**
   * 修改启用状态
   * @param status
   */
  handleChangeStatus(status: string) {
    let items = this.selectIds
    this.$confirm('是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.changeStatus(item, status)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
  * 修改启用状态
  */
  async changeStatus(id, status) {
    try {
      await this.$axios({
        method: 'patch',
        url: `/auth/users/${id}`,
        data: {
          'enabled': status
        }
      })
      this.$notify({
        title: '操作成功',
        message: `${id}状态变更成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }
}
export default UserComponent
</script>

