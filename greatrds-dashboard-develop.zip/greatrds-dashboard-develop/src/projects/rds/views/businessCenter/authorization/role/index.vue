
<template>
  <div class="table-containers">
    <Table
      :data-source="tableDataSource"
    />
    <!--用户详情-->
    <Drawer
      :title="currentRole.name"
      :visible.sync="currentRole.isShow"
      :show-modal="false"
    >
      <Detail
        :data-source="currentRole"
      />
    </Drawer>

    <!--编辑角色-->
    <Operation
      :data-source="userData"
      v-if="userData.isShow"
    />
  </div>
</template>
<script lang='ts'>
import {Component, Vue} from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import {Drawer} from '@/compkg/components'
import Operation from './operation.vue'
import Detail from './detail.vue'

interface Sort {
  prop: null | string;
  order: null | string;
}

interface CurrentRole {
    id?:string,
    name?:string,
    isShow?:boolean
}

@Component({
  components: {
    Drawer,
    Operation,
    Table,
    Detail
  }
})
class RoleListComponent extends Vue {

  private currentRole: CurrentRole = {
    id: '',
    name: '',
    isShow: false
  }

  private userData: any = {
    isShow: false,
    isEdit: false,
    type: 'admin'
  };

  private like: string = '' // 搜索字段
  private sort: Sort = { // 排序字段
    prop: null,
    order: null
  }
  private choosedIds: string[] = []
  private activeTab: string = 'admin'
  public tableDataSource: object = {
    btnConfig: {
      left: true,
      list: [{
        type: 'primary',
        name: '创建',
        icon: 'fa fa-biaodanguanli'
      }],
      dropdownList: [
        {
          titleName: '操作',
          list: [
            {
              name: '编辑',
              disabled: true,
              icon: 'fa fa-delete'
            },
            {
              name: '删除',
              disabled: true
            }
          ]
        }],
      clickBtn: (btnName: string) => {
        this.btnOperation(btnName)
      }
    },
    tabsConfig: {
      activeName: '管理后台角色',
      list: [{
        id: 1,
        label: '管理后台角色',
        name: '管理后台角色'
      }, {
        id: 2,
        label: '控制台角色',
        name: '控制台角色'
      }],
      change: (label) => this.handleTabChange(label)
    },
    tableConfig: {
      isMultiple: 1,
      isSerialNumber: 1,
      loading: false,
      selectionChange: (val) => this.handleSelectionChange(val),
      columns: [
        {
          label: '角色名称',
          prop: 'name',
          sortable: 'custom',
          click: (row) => {
            this.showDetail(row)
          }
        },
        {
          label: '角色id',
          prop: 'id'
        },
        {
          label: '描述',
          prop: 'description',
          filter: 'dbNullFilter'
        },
        {
          label: '角色类型',
          prop: 'type',
          filter: 'dbRoleFilter'
        }
      ],
      data: [],
      sortChange: (item) => this.handleSortChange(item)
    },
    searchConfig: {
      placeholder: '请输入搜索内容',
      remote: true,
      change: (val: string) => this.handleSearchChange(val)
    },
    pageConfig: {
      currentPage: 1,
      pageSize: 20,
      totalCount: 3,
      change: (currentPage: number) => {
        this.tableDataSource['pageConfig'].currentPage = currentPage
        this.getList()
      },
      pageSizeChange: (currentPageSize: number) => {
        this.tableDataSource['pageConfig'].currentPage = 1
        this.tableDataSource['pageConfig'].pageSize = currentPageSize
        this.getList()
      }
    }
  }

  created() {
    this.getList()
  }

  /**
  * 表格的排序条件发生变化时触发
  * @param item - 当前表格对象项及order
  */
  handleSortChange(item: any) {
    const { prop, order } = item
    if (order) {
      this.sort.prop = prop
      this.sort.order = order === 'descending' ? 'desc' : 'asc'
    } else {
      this.sort.prop = null
      this.sort.order = null
    }
    this.getList()
  }

  /**
   * 当表格中选择项发生变化时会触发该事件
   * @param list - 已选表格数据
   */
  handleSelectionChange(list: object[]) {
    this.choosedIds = list.map((chooseItem: any) => chooseItem.id)
    this.tableDataSource['btnConfig'].dropdownList[0].list.forEach((item: object) => {
      if (item['name'] === '编辑') {
        item['disabled'] = (list.length !== 1 || list[0]['name'] === 'admin')
      } else if (item['name'] === '删除') {
        item['disabled'] = list.length === 0
      }
    })
  }

  /**
   * tab切换触发事件
   * @param label 已选数据
   */
  handleTabChange(label) {
    this.activeTab = label === '管理后台角色' ? 'admin' : 'member'
    this.getList()
  }

  /**
   * @description 头部按钮操作
   * @param name 点击的按钮名字
   */
  btnOperation(name: string) {
    if (name === '创建') {
      this.userData.isShow = true
      this.userData.isEdit = false
      this.userData.type = this.activeTab
    } else if (name === '编辑' && this.choosedIds.length === 1) {
      let row = this.tableDataSource['tableConfig'].data.filter((data) => data.id === this.choosedIds[0])
      this.editRole(row[0])
    } else if (name === '删除' && this.choosedIds.length) {
      if (!this.validSelect()) {
        return
      }
      this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async() => {
        await Promise.all(this.choosedIds.map((item) => this.deleteRole(item)))
        await this.getList()
      })
    }
  }

  validSelect() {
    let row = this.tableDataSource['tableConfig'].data.filter((data) => data.name === 'admin')
    if (row.length > 0) {
      this.$notify({
        title: '操作失败',
        message: '不可以修改admin角色',
        type: 'error'
      })
    }
    return row.length === 0
  }

  /**
   * @description 获取列表
   */
  async getList() {
    this.tableDataSource['tableConfig'].loading = true
    try {
      this.tableDataSource['tableConfig'].loading = true
      let json = await this.$axios({
        method: 'GET',
        url: `/auth/roles/type/${this.activeTab}`,
        params: {
          limit: this.tableDataSource['pageConfig'].pageSize,
          offset: this.tableDataSource['pageConfig'].currentPage,
          filters: this.like,
          sort_key: this.sort.prop,
          sort_dir: this.sort.order
        }
      })
      this.tableDataSource['tableConfig'].data = json.roles || []
      this.tableDataSource['pageConfig'].totalCount = json.total
      this.tableDataSource['tableConfig'].loading = false
    } catch (error) {
      this.tableDataSource['tableConfig'].loading = false
      this.$handleError(error)
    }
  }

  /**
  * 删除角色
  * @param items 选中行
  */
  handleDelete(items: string[]) {
    this.$confirm('此操作将永久删除用户, 是否继续?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(async() => {
      await Promise.all(items.map((item) => this.deleteRole(item)))
      await this.getList()
    }).catch(
      (error) => {
        this.$handleError(error)
      }
    )
  }

  /**
   * @param id 要删除的id
   * @description 删除角色
   */
  async deleteRole(id: String) {
    try {
      let json = await this.$axios({
        method: 'DELETE',
        url: `/auth/roles/${id}`
      })
      this.$notify({
        title: '操作成功',
        message: `${id}删除成功`,
        type: 'success'
      })
    } catch (error) {
      this.$handleError(error)
    }
  }

  /**
   * 编辑角色
   * @param item 当前行
   */
  editRole(item: Object) {
    this.userData.isShow = true
    this.userData.isEdit = true
    this.userData.role = {
      name: item['name'],
      type: item['type'],
      description: item['description'],
      functions_ids: item['functions_ids']
    }
    this.userData.id = item['id']
  }

  /**
  * 角色详情
  * * @param item 当前行
  */
  showDetail(item: any) {
    this.currentRole.isShow = true
    this.currentRole.id = item.id
    this.currentRole.name = item.name
  }

  /**
  * 搜索框事件
  * @param val 搜索
  */
  handleSearchChange(val:string) {
    this.like = val
    this.getList()
  }

}
export default RoleListComponent
</script>

