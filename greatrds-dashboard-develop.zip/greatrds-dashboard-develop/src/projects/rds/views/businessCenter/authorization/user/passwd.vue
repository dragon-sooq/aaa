<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.isEdit ? '修改密码' : '修改密码'"
    :width="'600px'"
  >
    <el-form
      style="padding: 35px;"
      v-bind="formItemLayout"
      label-position="right"
      label-width="100px"
      :model="userData"
      :rules="userRules"
      ref="userEditForm"
    >
      <el-form-item
        label="密码"
        prop="password"
      >
        <el-input
          v-model="userData.password"
          show-password
        />
      </el-form-item>

      <el-form-item
        label="确认密码"
        prop="password2"
      >
        <el-input
          v-model="userData.password2"
          show-password
        />
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        @click="submitForm('userEditForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'

@Component({
  components: {
    DialogLayer
  }
})
class UserEditComponent extends Vue {
  @Prop({required: true}) dataSource: any;

  private userData: any ={
    password: '',
    password2: ''
  }
  private loading: boolean = false;

  private get formItemLayout() {
    return {
      labelCol: {span: 4},
      wrapperCol: {span: 14}
    }
  }

  private userRules: object = {
    password: [{required: true, message: '请输入新密码', trigger: 'change'}],
    password2: [
      { required: true, message: '请输入密码', trigger: 'change' },
      { validator: this.validatePass2, trigger: 'blur' }
    ]
  }

  validatePass2(rule, value, callback) {
    if (value !== this.userData.password) {
      callback(new Error('两次输入密码不一致!'))
    } else {
      callback()
    }
  }

  created() {
  }

  /**
  * 验证表单
  */
  submitForm(formName) {
    (this.$refs[formName] as any).validate((valid: Boolean) => {
      if (valid) {
        this.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    this.loading = true
    try {
      let json = await this.$axios({
        method: 'patch',
        url: `/auth/users/${this.dataSource.userId}`,
        data: {
          'password': this.userData.password
        }
      })
      this.$notify({
        title: '操作成功',
        message: '修改密码成功',
        type: 'success'
      })
      this.loading = false
      this.dataSource.isShow = false
    } catch (error) {
      this.loading = false
      this.$handleError(error)
    }
  }

}

export default UserEditComponent
</script>


