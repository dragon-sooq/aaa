<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.userType === 'admin' ? '修改管理员角色' : '修改控制台角色'"
    :width="'600px'"
  >
    <el-form
      style="padding: 35px;"
      v-bind="formItemLayout"
      label-position="right"
      label-width="100px"
      :model="userForm"
      :rules="userRules"
      ref="userRoleForm"
    >
      <el-form-item
        label="管理员角色"
        prop="adminRole"
        v-if="dataSource.userType === 'admin'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.adminRole"
          placeholder="请选择"
          :disabled="formOption.adminRoleOption.length === 0"
        >
          <el-option
            v-for="(item, index) in formOption.adminRoleOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="关联项目"
        prop="project"
        v-if="dataSource.userType !== 'admin'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.project"
          :disabled="formOption.projectOption.length === 0"
          placeholder="请选择"
        >
          <el-option
            v-for="(item, index) in formOption.projectOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="项目角色"
        prop="memberRole"
        v-if="dataSource.userType !== 'admin'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.memberRole"
          :disabled="formOption.memberRoleOption.length === 0"
          placeholder="请选择"
        >
          <el-option
            v-for="(item, index) in formOption.memberRoleOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        @click="submitForm('userRoleForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import {Vue, Component, Prop} from 'vue-property-decorator'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'

@Component({
  components: {
    DialogLayer
  }
})
class UserRoleComponent extends Vue {
  @Prop({required: true}) dataSource: any;

  private userForm: any ={
    adminRole: '',
    project: '',
    memberRole: ''
  }
  private loading: boolean = false;

  private get formItemLayout() {
    return {
      labelCol: {span: 4},
      wrapperCol: {span: 14}
    }
  }

  private formOption: any = {
    adminRoleOption: [],
    projectOption: [],
    memberRoleOption: []
  }

  private userRules: Object = {
    project: [{ required: true, message: '请选择一个项目', trigger: 'change' }],
    adminRole: [{ required: true, message: '请选择一个管理员角色', trigger: 'change' }],
    memberRole: [{ required: true, message: '请选择一个角色', trigger: 'change' }]
  }
  created() {
    this.getAdminRoles()
    this.getProjects()
    this.getMemberRoles()
  }

  async getAdminRoles() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/roles/type/admin'
      })
      this.formOption.adminRoleOption = json.roles
    } catch (error) {
      this.$handleError(error)
    }
  }

  async getProjects() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/projects'
      })
      this.formOption.projectOption = json.projects.filter((item) => item.name !== 'admin')
    } catch (error) {
      this.$handleError(error)
    }
  }

  async getMemberRoles() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/roles/type/member'
      })
      this.formOption.memberRoleOption = json.roles
    } catch (error) {
      this.$handleError(error)
    }
  }


  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    this.loading = true
    let data = this.validateUserForm(this.userForm)
    try {
      await this.$axios({
        method: 'PATCH',
        url: `/auth/users/${this.dataSource.userId}`,
        data: data
      })
      this.loading = false
      this.dataSource.isShow = false
      ;(this as any).$refs['userRoleForm'].resetFields()
      this.$emit('get-list')
      this.$notify({
        title: '操作成功',
        message: `${this.dataSource.userId}修改角色成功`,
        type: 'success'
      })
    } catch (error) {
      this.loading = false
      this.$handleError(error)
    }
  }

  validateUserForm(userForm) {
    let user = JSON.parse(JSON.stringify(userForm))
    if (this.dataSource.userType === 'admin') {
      user.role = user.adminRole
      user.project = null
    } else {
      user.role = user.memberRole
    }
    return {
      type: this.dataSource.userType,
      role: user.role,
      project: user.project
    }
  }

}

export default UserRoleComponent
</script>


