<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="userForm.type === 'admin' ? '创建管理员' : '创建控制台用户'"
    :width="'600px'"
  >
    <el-form
      ref="userForm"
      style="padding: 35px;"
      v-bind="formItemLayout"
      :model="userForm"
      :rules="userRules"
      label-width="100px"
    >
      <el-form-item
        label="用户名称"
        prop="name"
      >
        <el-input
          v-model="userForm.name"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="用户密码"
        prop="password"
      >
        <el-input
          v-model="userForm.password"
          autocomplete="off"
          show-password
        />
      </el-form-item>

      <el-form-item
        label="确认密码"
        prop="password2"
      >
        <el-input
          v-model="userForm.password2"
          autocomplete="off"
          show-password
        />
      </el-form-item>

      <el-form-item
        label="管理员角色"
        prop="adminRole"
        v-if="userForm.type === 'admin'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.adminRole"
          placeholder="请选择"
          :disabled="formOption.adminRoleOption.length === 0"
        >
          <el-option
            v-for="(item, index) in formOption.adminRoleOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="关联项目"
        prop="project"
        v-if="userForm.type === 'member'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.project"
          :disabled="formOption.projectOption.length === 0"
          placeholder="请选择"
        >
          <el-option
            v-for="(item, index) in formOption.projectOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="项目角色"
        prop="memberRole"
        v-if="userForm.type === 'member'"
      >
        <el-select
          style="width:100%"
          v-model="userForm.memberRole"
          :disabled="formOption.memberRoleOption.length === 0"
          placeholder="请选择"
        >
          <el-option
            v-for="(item, index) in formOption.memberRoleOption"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>


      <el-form-item
        label="用户状态"
        prop="enabled"
      >
        <el-radio-group v-model="userForm.enabled">
          <el-radio label="1">启用</el-radio>
          <el-radio label="0">禁用</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        @click="submitForm('userForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'

@Component({
  components: {
    DialogLayer
  }
})
class UserOperationComponent extends Vue {
  @Prop({required: true}) dataSource: any

  private loading: boolean = false
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }

  private userForm: any = {
    name: '',
    password: '',
    password2: '',
    type: this.dataSource.type,
    adminRole: '',
    project: '',
    memberRole: '',
    enabled: '1'
  }

  private formOption: any = {
    adminRoleOption: [],
    projectOption: [],
    memberRoleOption: []
  }

  private userRules: Object = {
    name: [{ required: true, message: '请输入用户名', trigger: 'change' }],
    password: [{ required: true, message: '请输入密码', trigger: 'change' }],
    password2: [
      { required: true, message: '请输入密码', trigger: 'change' },
      { validator: this.validatePass2, trigger: 'blur' }
    ],
    enabled: [{ required: true, message: '请选择一项', trigger: 'change' }],
    project: [{ required: true, message: '请选择一项', trigger: 'change' }],
    adminRole: [{ required: true, message: '请选择一项', trigger: 'change' }],
    memberRole: [{ required: true, message: '请选择一项', trigger: 'change' }]
  }
  created() {
    this.getAdminRoles()
    this.getProjects()
    this.getMemberRoles()
  }

  async getAdminRoles() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/roles/type/admin'
      })
      this.formOption.adminRoleOption = json.roles
    } catch (error) {
      this.$handleError(error)
    }
  }

  async getProjects() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/projects'
      })
      this.formOption.projectOption = this.formOption.projectOption = json.projects.filter((item) => item.name !== 'admin')
    } catch (error) {
      this.$handleError(error)
    }
  }

  async getMemberRoles() {
    try {
      let json = await this.$axios({
        method: 'GET',
        url: '/auth/roles/type/member'
      })
      this.formOption.memberRoleOption = json.roles
    } catch (error) {
      this.$handleError(error)
    }
  }

  validatePass2(rule, value, callback) {
    if (value !== this.userForm.password) {
      callback(new Error('两次输入密码不一致!'))
    } else {
      callback()
    }
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 提交表单
   */
  async saveData() {
    this.loading = true
    let data = this.validateUserForm(this.userForm)
    try {
      await this.$axios({
        method: 'POST',
        url: '/auth/users',
        data: data
      })
      this.loading = false
      this.dataSource.isShow = false
      this.$emit('get-list')
      this.$notify({
        title: '操作成功',
        message: `${data.name}创建成功`,
        type: 'success'
      })
    } catch (error) {
      this.loading = false
      this.$handleError(error)
    }
  }

  validateUserForm(userForm) {
    let user = JSON.parse(JSON.stringify(userForm))
    if (user.type === 'admin') {
      user.role = user.adminRole
      user.project = null
    } else {
      user.role = user.memberRole
    }
    return {
      name: user.name,
      password: user.password,
      type: user.type,
      role: user.role,
      project: user.project,
      enabled: user.enabled
    }
  }

}

export default UserOperationComponent
</script>

