<template>
  <div class="common-detail">
    <Table
      :data-source="tableDataSource"
      style="height: calc(100vh - 320px);"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import Table from '@/compkg/components/Table/index.vue'
import { Drawer } from '@/compkg/components'
@Component({
  components: {
    Drawer,
    Table
  }
})
class UserDetailComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  private userData: any = {
    isShow: false,
    isEdit: false
  };
  public tableDataSource: Object = {
    tabsConfig: {
      activeName: '用户信息',
      list: [{
        id: 1,
        label: '用户信息',
        name: '用户信息'
      }]
    },
    tableConfig: {
      columns: [
        {
          label: '项目id',
          prop: 'project_id',
          filter: 'dbNullFilter'
        }, {
          label: '项目名称',
          prop: 'project_name',
          filter: 'dbNullFilter'
        }, {
          label: '角色id',
          prop: 'role_id',
          filter: 'dbNullFilter'
        }, {
          label: '角色名称',
          prop: 'role_name',
          filter: 'dbNullFilter'
        }
      ],
      data: []
    }
  }

  created() {
    this.getList()
  }

  /**
   * @description 获取列表
   */
  async getList() {
    let that = this
    try {
      let json = await that.$axios({
        method: 'GET',
        url: `/auth/users/${this.dataSource.id}`
      })
      that.tableDataSource['tableConfig'].data = json.user_role_project
    } catch (error) {
      (that as any).$handleError(error)
    }
  }
}
export default UserDetailComponent
</script>

<style lang="scss">
</style>

