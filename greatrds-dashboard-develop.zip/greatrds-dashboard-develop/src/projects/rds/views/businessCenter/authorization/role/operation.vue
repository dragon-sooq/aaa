<template>
  <DialogLayer
    :visible.sync="dataSource.isShow"
    :title="dataSource.isEdit ? '编辑角色' : '创建角色'"
    :width="'720px'"
  >
    <el-form
      ref="roleForm"
      label-align="right"
      layout="horizontal"
      style="padding: 35px;"
      label-width="80px"
      v-bind="formItemLayout"
      :model="roleForm"
      :rules="userRules"
    >
      <el-form-item
        has-feedback
        label="角色名称"
        prop="name"
      >
        <el-input
          v-model="roleForm.name"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="描述"
      >
        <el-input
          v-model="roleForm.description"
          :rows="4"
          type="textarea"
          autocomplete="off"
        />
      </el-form-item>

      <el-form-item
        label="授予权限"
      >
        <el-tree
          :data="treeData"
          show-checkbox
          node-key="id"
          :props="defaultProps"
          :default-checked-keys="dataSource.isEdit ? roleForm.functions_ids : []"
          @check-change="checkChange"
        />
      </el-form-item>
    </el-form>

    <span
      slot="footer"
      class="dialog-footer"
    >

      <el-button
        type="primary"
        :loading="loading"
        :size="$root.commonSize"
        @click="submitForm('roleForm')"
      >
        提交
      </el-button>

    </span>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { namespace, Getter } from 'vuex-class'
import Utils from '@/utils'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
import { handleTreeV2 } from '@/utils/tree'
const worktableModule = namespace('worktable')

@Component({
  components: {
    DialogLayer
  }
})
class UserOperationComponent extends Vue {
  @Prop({required: true}) dataSource: any;
  private treeData: Array<Object> = []
  private loading: Boolean = false;
  private chooseIds: Array<String> = [];
  private get formItemLayout() {
    return {
      labelCol: { span: 4 },
      wrapperCol: { span: 14 }
    }
  }
  private defaultProps: Object = {
    children: 'children',
    label: 'label'
  }
  private roleForm: any = {
    name: '',
    description: '',
    functions_ids: [],
    type: this.dataSource.type
  }
  private userRules: Object = {
    name: [{ required: true, message: '请输入角色名称名', trigger: 'change' }],
    passwd: [{ required: true, message: '请输入密码', trigger: 'change' }]
  }
  created() {
    if (this.dataSource.isEdit) {
      this.roleForm = this.dataSource.role
    }
    this.getPermissionTree()
  }

  /**
   * 验证表单
   */
  submitForm(formName) {
    let that = this;
    (that.$refs[formName] as any).validate((valid: Boolean) => {
      if (valid) {
        that.saveData()
      }
    })
  }

  /**
   * 选中权限树某一项
   */
  checkChange(item: Object, node: Boolean) {
    console.log(item, node)
    if (node) {
      this.roleForm.functions_ids.push(item['id'])
      item['children'].forEach((childNode: Array<Object>) => {
        this.roleForm.functions_ids.push(childNode['id'])
      })
    } else {
      this.roleForm.functions_ids = []
    }
    console.log(this.roleForm.functions_ids)
  }

  /**
   * 获取权限树
   */
  async getPermissionTree() {
    let that = this
    let result = await (that as any).$axios.get(`/auth/permissions/${that.roleForm.type}/collect`)
    console.log(result)
    if (result && result.permissions) {
      this.treeData = handleTreeV2(result.permissions, 'id', 'parent_id', 'display_name')
    }
  }

  /**
   * 提交表单
   */
  async saveData() {
    let that = this
    that.loading = true
    try {
      let json = await that.$axios({
        method: that.dataSource.isEdit ? 'PATCH' : 'POST',
        url: that.dataSource.isEdit ? `/auth/roles/${that.dataSource.id}` : '/auth/roles',
        data: that.roleForm
      })
      that.loading = false
      that.$notify({
        title: '操作成功',
        message: that.dataSource.isEdit ? '修改角色成功' : '创建角色成功',
        type: 'success'
      })
      that.dataSource.isShow = false;
      (that as any).$parent.getList()
    } catch (error) {
      that.loading = false;
      (that as any).$handleError(error)
    }
  }

}

export default UserOperationComponent
</script>

