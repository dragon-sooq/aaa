import Vue from '@/compkg/configs/main'
import i18n from '@/compkg/configs/i18n'
import App from './App.vue'
import DICT from '@/utils/dict'
import router from '@/routers/index'
import store from './stores/index'
import '@/permission'
import './axios'


const initVue = async() => {
  new Vue({
    router,
    store,
    i18n,
    data: () => {
      return {
        DICT: DICT,
        isDark: false, // 是否深色主题
        commonSize: 'small', // 通用尺寸
        reloadFn: null
      }
    },
    render: (handler) => handler(App)
  }).$mount('#app')
}

initVue()
