<template>
  <div
    id="app"
    :class="{'iframe': $root.isIframe}"
  >
    <!-- iconfont -->
    <link
      type="text/css"
      rel="stylesheet"
      href="https://at.alicdn.com/t/font_1486590_ze9ju8xl0l.css"
    >
    <!-- :aside-collapse="asideCollapse" -->
    <Container
      v-if="$route.name !== 'Login'"
      :layout-hidden="layoutHidden"
    >
      <Header
        v-if="$route.meta.keepAlive"
        slot="header"
      />
      <Aside
        style="height: 100%;"
        v-if="$route.meta.keepAlive"
        slot="aside"
      />
      <Main
        v-if="$route.meta.keepAlive"
        slot="main"
      />
      <!-- <Footer slot="footer" /> -->
    </Container>
    <router-view v-else />
    <SocketIO />
  </div>
</template>

<script lang='ts'>
import { Component, Vue } from 'vue-property-decorator'
import { Getter } from 'vuex-class'
import { Container } from '@/compkg/layout'
import { Header, Main, Aside } from './views/main/index'
import Utils from '@/utils'
import SocketIO from '@/compkg/components/SocketIO/index.vue'

@Component({
  components: {
    Container,
    Header,
    Main,
    Aside,
    SocketIO
    // Footer
  }
})
export default class App extends Vue {
  // @Getter asideCollapse;
  @Getter layoutHidden;

  mounted() {
    let that = this
    that.watchWindow()
    window.onresize = that.watchWindow
  }

  /**
   * 基于屏幕检测尺寸
   */
  watchWindow = Utils.Lodash.debounce(() => {
    let commonSize = 'small'
    if (commonSize !== (this as any).$root.commonSize) {
      (this as any).$root.commonSize = commonSize
    }
  }, 300);
}
</script>

<style lang="scss">
@import './assets/css/common.scss';
</style>
