import Vue from '@/compkg/configs/main'
import router from '../../routers/index'
import store from './stores/index'
import { Loading } from 'element-ui'
import jstz from 'jstz'
import { getApiPrefix } from '@/utils/api'
import { goLoginConfirm } from '@/utils/token'
import Utils from '@/utils'
let { $axios, $vars, $api, $safeApi, $handleError } = Vue.prototype

// axios 配置
$axios.defaults.baseURL = $api // '/v1'
$axios.defaults.timeout = 25000
$axios.defaults.headers.post['Content-Type'] = 'application/json'

// 是否正在刷新的标记
let isRefreshing = false
let isAskLogin = false
// 重试队列，每一项将是一个待执行的函数形式
let retryRequests = []
let loading = {} // 定义loading变量

// 缓存请求使用token端
let ajaxCacheTokens = {}
// 不显示错误消息的白名单code
const whiteCodeList = ['1011', '1051']

const startLoading = () => { // 使用Element loading-start 方法
  loading = Loading.service({
    lock: true,
    text: '加载中……',
    background: 'rgba(0, 0, 0, 0.7)'
  })
}
function endLoading() { // 使用Element loading-close 方法
  (loading as any).close()
}

let needLoadingRequestCount = 0
const showFullScreenLoading = () => {
  if (needLoadingRequestCount === 0) {
    startLoading()
  }
  needLoadingRequestCount++
}

const tryHideFullScreenLoading = () => {
  if (needLoadingRequestCount <= 0) {
    return
  }
  needLoadingRequestCount--
  if (needLoadingRequestCount === 0) {
    endLoading()
  }
}

// Add a request interceptor
$axios.interceptors.request.use((config: any) => {
  let params = config.data || config.params || {}

  /**
   * 对参数中所有字符串内容进行Trim处理（去除首位空格）
   */
  Utils.Format.trim(params)

  // skipLoading 跳过loading状态
  if (!params.skipLoading) {
    // showFullScreenLoading()
  }
  // skipAuth 跳过token
  if (!params.skipAuth) {
    // 判断当前页面是否为iframe 检测页面类型确定是否更换api前缀
    let iframePageType = store.getters['user/iframePageType']
    if (parent !== window && iframePageType) {
      // system and 排除oss
      if (iframePageType === 'system' && config.url.indexOf('osscenter/') < 0) {
        params.useSystemToken = true
      } else if (iframePageType === 'admin') {
        params.useAdminToken = true
      } else {
        params.useWebToken = true
      }
    }
    // 获取accessToken
    let token = store.getters['user/token']
    // 无Token直接返回
    if (!token) {
      return config
    }
    config.headers['X-Auth-Token'] = params.token || token
    return config
  }
  Reflect.deleteProperty(params, 'skipAuth')
  return config
}, (error: any) => {
  // loading
  store.commit('toggleLoading', false)
  // message
  $handleError($vars.msg.error.api)
  return Promise.reject(error)
})

/**
 * 跳转登录页
 */
const goLogin = () => {
  if (!isAskLogin) {
    isAskLogin = true
    goLoginConfirm().then(() => {
      // 移除用户缓存 跳转登录页
      store.dispatch('user/LogOut').then(() => {
        router.push({
          name: 'Login'
        })
        isAskLogin = false
      })
    })
  }
}

// Add a response interceptor
$axios.interceptors.response.use((response: any) => {
  // loading
  // tryHideFullScreenLoading()
  const { data, config, status } = response
  const { responseType } = response && response.request
  if (responseType === 'arraybuffer') { // 导出文件流
    return Promise.resolve(data)
  }
  // if (data.code === $vars.ajax.code.success) { // 0000
  if (data || status === 204) {
    let configUrl = config.url.split('/rest/')[1]
    Reflect.deleteProperty(ajaxCacheTokens, configUrl)
    return Promise.resolve(data)
  }
  // 处理errMsg改用服务器返回，前端不维护
  const { code, result: errMsg } = data
  // const errMsg = $vars.code[code] || $vars.msg.error.api;
  if (status === 401) {
    goLogin()
  } else if (whiteCodeList.indexOf(code) < 0) {
    // [临时]不在白名单中就错误消息提示
    $handleError(errMsg)
  }
  return Promise.reject(errMsg)
}, (error: any) => {
  // loading
  let msg = '服务器错误'
  if (error.response && error.response.status === 401) {
    goLogin()
  }
  if (error.response && error.response.data && error.response.data.errors.length) {
    error.response.data.errors.forEach((val: any) => {
      // message
      $handleError(val.detail || val.message)
    })
  }
  store.commit('toggleLoading', false)
  
  return Promise.reject(error.response)
})

export default $axios
