declare module 'vuedraggable' {
  interface vuedraggable {
  }
}