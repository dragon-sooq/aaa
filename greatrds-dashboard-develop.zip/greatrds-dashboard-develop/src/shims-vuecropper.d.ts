// declare module 'vue-cropper' {
//   interface VueCropper {
//   }

//   const VueCropper: VueCropper

//   export = VueCropper
// }