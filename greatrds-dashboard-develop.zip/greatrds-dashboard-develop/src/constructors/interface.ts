/**
 * 构造器数据结构中常用数据的类型接口
 * @author Arley
 * @description 该文件定义了所有构造器的几种常见复合结构的数据类型，请严格依照该文件执行
 */

/**
 * DefaultValue 默认值数据类型接口
 */
namespace ConstructorsInterface {
  export interface DefaultValue {
    value?: string | Date | number
    label?: string
  }

  /**
   * 图片类型接口
   */
  export interface Images {
    label: string,
    size: number,
    type: string, // 'jpg'\'png'\'bmp'\'gif'
    value: string,
    filterval?: string // ossfilter后的仅供展示，保存时自动删除
  }

  /**
   * @单元格接口
   */
  export interface UserRange {
    id: string,
    name: string
  }

  /**
   * widget字段的数据类型
   * @description - 该自定类型为所有设计器控件的属性超集
   */
  export interface Widget {
  }
}

export default ConstructorsInterface
