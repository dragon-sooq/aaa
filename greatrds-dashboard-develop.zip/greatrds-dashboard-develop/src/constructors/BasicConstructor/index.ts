/**
 * 基础构造器
 * @author Nan
 * @description
 */

// import * as _ from 'lodash';
// import DICT from '@/utils/dict';
// import ConstructorsInterface from '../interface';

class BasicConstructor {

  /**
   * 公共属性demo
   */
  // 名称
  protected name: string = '';
  // 名称 - 入库使用
  public fieldName: string = '';
  // 描述 -
  public fieldDesc: string = '';
  // 排序
  public fieldOrder: number = 0;
  // 工作项类型值
  protected fieldType: string = '';
  // 工作项的唯一标识(资源定位符)
  // 默认值
  // public defaultValue: DefaultValue | Options[] = {
  //   value: ''
  // };
  public defaultValue: any = {
    value: ''
  };

}

export default BasicConstructor
