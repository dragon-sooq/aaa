import Vue from 'vue'
import Vuex from 'vuex' // vuex
import user from './modules/user'
import permission from './modules/permission'

Vue.use(Vuex)

// 导出
export default new Vuex.Store({
  state: {
    loading: false,
    isOverflowHide: false, // 是否锁定页面不可滚动
    iframedata: null // iframe通信回传数据
  },
  getters: {
  },
  mutations: {
  },
  modules: {
    user,
    permission
  }
})
