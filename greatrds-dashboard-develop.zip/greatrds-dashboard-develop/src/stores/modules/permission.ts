import { VuexModule, Module, Mutation, Action, getModule } from 'vuex-module-decorators'
import axios from 'axios'
import { RouteConfig } from 'vue-router'
import router, { asyncRoutes, constantRoutes, resetRouter } from '@/routers'


export interface IPermissionState {
  routes: RouteConfig[]
  dynamicRoutes: RouteConfig[]
}

const hasPermission = (roles: string, route: RouteConfig) => {
  if (route.meta && route.meta.role) {
    return route.meta.role.includes(roles)
  }
  return true
}

export const filterAsyncRoutes = (routes: RouteConfig[], roles: string) => {
  const res: RouteConfig[] = []
  routes.forEach((route) => {
    const childRoute = { ...route }
    // debugger
    if (hasPermission(roles, childRoute)) {
      if (childRoute.children) {
        console.log(childRoute.children)
        childRoute.children = filterAsyncRoutes(childRoute.children, roles)
      }
      res.push(childRoute)
    }
  })
  return res
}

const state = {
  routes: [],
  dynamicRoutes: []
}

const actions = {
  GenerateRoutes({ commit }, roles: string) {
    let accessedRoutes = asyncRoutes
    // if (roles.includes('admin')) {
    //   accessedRoutes = asyncRoutes
    // } else {
    //   accessedRoutes = filterAsyncRoutes(asyncRoutes, roles)
    // }
    accessedRoutes = filterAsyncRoutes(asyncRoutes, roles)
    commit('SET_ROUTES', accessedRoutes)
    return accessedRoutes
  }
}

const mutations = {
  SET_ROUTES(state: any, routes: RouteConfig[]) {
    state.routes = constantRoutes.concat(routes)
    state.dynamicRoutes = routes
  }
}

const getters = {
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
