/**
 * 用户和token
 */
import CACHE from '@/utils/cache'
import axios from 'axios'
import router, { resetRouter } from '@/routers'
import permission from './permission'


const state = {
  role: '', // 用户角色 admin/member
  permissions: '', // 用户权限
  token: CACHE.localStorage.get('token') || '', // Web端用户信息+token,
  wsInfo: CACHE.localStorage.get('ws_info') || ''
}

const actions = {
  GetUserInfo({ commit }) {
    let token = CACHE.localStorage.get('token')
    if (!token) {
      throw Error('GetUserInfo: token is undefined!')
    }
    const { data } = this.GetIdentityInfo()
    if (!data) {
      throw Error('Verification failed, please Login again.')
    }
    // roles must be a non-empty array
    // if (!roles) {
    //   throw Error('GetUserInfo: roles must be a non-null array!')
    // }
    commit('SET_ROLES', 'admin')
    return data
  },

  async GetIdentityInfo() {
    const result: any = await axios({
      url: 'identity_info',
      method: 'GET'
    })
    return Promise.resolve(result)
  },

  ResetToken({ commit }) {
    CACHE.localStorage.remove('Token')
    commit('SET_TOKEN', '')
    commit('SET_ROLES', '')
    return Promise.resolve()
  },

  Login({ commit }, token: string) {
    CACHE.localStorage.put('token', token)
    commit('SET_TOKEN', token)
    return Promise.resolve()
  },

  SaveUser({ commit }, data: object) {
    commit('SAVE_USER_INFO', data)
    return Promise.resolve()
  },

  UpdateWsInfo({ commit }) {
    const { wsInfo } = this.GetIdentityInfo()
    CACHE.localStorage.remove('ws_info')
    commit('SET_WS_INFO ', wsInfo)
    return Promise.resolve()
  },

  LogOut() {
    CACHE.localStorage.remove('token')
    CACHE.cookies.remove('user_id')
    CACHE.localStorage.remove('ws_info')
    resetRouter()
    // commit('SET_TOKEN', '')
    // commit('SET_ROLES', '')
  }
}

const mutations = {
  SAVE_USER_INFO(state: any, userData: any) {
    let { roleTypes, user, regions, projects, wsInfo } = userData
    CACHE.localStorage.put('role', roleTypes || 'admin')
    state.role = roleTypes
    user.role = roleTypes
    user.projects = projects
    user.regions = regions
    CACHE.cookies.put('user_id', user.id, 7)
    CACHE.localStorage.put('user', user)
    CACHE.localStorage.put('ws_info', wsInfo)
  },

  SET_TOKEN(state: any, token: string) {
    state.token = token
  },

  SET_ROLES(state: any, roles: string) {
    state.role = roles
  },

  SET_WS_INFO(state: any, wsInfo: any) {
    CACHE.localStorage.put('ws_info', wsInfo)
    state.wsInfo = wsInfo.wsInfo
  }
}

const getUserAndToken = () => {
  return CACHE.localStorage.get('user')
}

const getUser = () => {
  return CACHE.localStorage.get('user')
}

const getToken = () => {
  return CACHE.localStorage.get('token')
}

const getRole = () => {
  return CACHE.localStorage.get('role')
}

const getWsToken = () => {
  return (state.wsInfo as any).wsToken || ''
}

const getWsPath = () => {
  return (state.wsInfo as any).wsPath || ''
}

const getters = {
  userAndToken() { // 根据页面类型获取当前用户信息和token
    return getUserAndToken()
  },
  userAndTokenWeb(state: any) {
    return state.userAndTokenWeb || CACHE.localStorage.get('user_info')
  },
  userInfo() {
    const userInfo = getUser()
    return userInfo
  },
  token() {
    const token = getToken()
    return token
  },
  role() {
    const role = getRole()
    return role
  },
  userId() {
    return CACHE.cookies.get('user_id')
  },
  wsToken() {
    const wsToken = getWsToken()
    console.log('wsInfo:', wsToken)
    return wsToken
  },
  wsPath() {
    const wsPath = getWsPath()
    console.log('wsPath:', wsPath)
    return wsPath
  }
}

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}
