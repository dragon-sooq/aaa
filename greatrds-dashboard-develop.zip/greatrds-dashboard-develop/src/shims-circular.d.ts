// declare module 'circular-json-es6' {
//   interface CircularJSON {
//   }

//   const CircularJSON: CircularJSON

//   export = CircularJSON
// }