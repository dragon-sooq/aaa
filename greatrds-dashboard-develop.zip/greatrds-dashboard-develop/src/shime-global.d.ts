// 声明全局的 window ，不然使用 window.XX 时会报错
declare var window: Window;
declare var document: Document;
// declare var THREE: any;
// interface THREE extends Window {}
declare module '*.png';
declare module '*.jpg';
declare module '*jpeg';
declare module '*.svg';
declare module '*.gif';
declare module '*.webp';
declare module '*.bmp';
