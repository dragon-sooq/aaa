// 运维路由
import { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'

const opsRouter: RouteConfig = {
  path: '/ops',
  component: RouteView,
  redirect: 'noredirect',
  name: 'Ops',
  meta: {
    title: 'ops',
    keepAlive: true,
    icon: 'ops',
    role: ['admin', 'member'],
    breadcrumb: '运维管理',
    categoryKey: 'rds',
    iconName: 'el-icon-s-flag'
  },
  children: [
    {
      path: 'template',
      component: () => import('@/projects/rds/views/ops/template/index.vue'),
      name: 'Template',
      meta: {
        title: '模板管理',
        noCache: true,
        keepAlive: true,
        breadcrumb: '模板管理',
        role: ['admin', 'member']
      }
    },
    {
      path: 'detail/:templateId',
      component: () => import('@/projects/rds/views/ops/template/detail.vue'),
      name: 'templateView',
      meta: {
        title: '模板详情',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '模板详情',
        role: ['admin', 'member']
      }
    },
    {
      path: 'schedulers',
      component: () => import('@/projects/rds/views/ops/schedulers/index.vue'),
      name: 'Schedulers',
      meta: {
        title: '定时器',
        noCache: true,
        keepAlive: true,
        breadcrumb: '定时器',
        role: ['admin', 'member']
      }
    },
    {
      path: 'schedulersDetail/:uuid/:period',
      component: () => import('@/projects/rds/views/ops/schedulers/detail/index.vue'),
      name: 'SchedulersView',
      meta: {
        title: '定时器详情',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '定时器详情',
        role: ['admin', 'member']
      }
    }
  ]
}

export default opsRouter
