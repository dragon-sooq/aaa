// 集群路由
import { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'

const clusterRouter: RouteConfig = {
  path: '/cluster',
  component: RouteView,
  redirect: 'noredirect',
  name: 'Cluster',
  meta: {
    title: 'cluster',
    keepAlive: true,
    icon: 'cluster',
    role: ['member'],
    breadcrumb: 'RDS',
    categoryKey: 'rds',
    iconName: 'el-icon-s-opportunity'
  },
  children: [
    {
      path: 'clusterManage',
      component: () => import('@/projects/rds/views/cluster/index.vue'),
      name: 'ClusterManage',
      meta: {
        title: 'clusterManage',
        noCache: true,
        keepAlive: true,
        breadcrumb: '分布式数据库', // mgr mysql主从
        role: ['member']
      }
    },
    {
      path: 'paramTab',
      component: () => import('@/projects/rds/views/cluster/detail/paramTab/index.vue'),
      name: 'ParamTab',
      meta: {
        title: 'paramTab',
        noCache: true,
        isAsideHide: true,
        keepAlive: true,
        breadcrumb: '参数修改',
        role: ['member']
      }
    },
    {
      path: 'createCluster',
      component: () => import('@/projects/rds/views/cluster/create.vue'),
      name: 'CreateCluster',
      meta: {
        title: 'createCluster',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '创建集群',
        role: ['member'],
        banner: {
          showBack: true,
          title: '创建集群' 
        }
      }
    }
  ]
}

export default clusterRouter
