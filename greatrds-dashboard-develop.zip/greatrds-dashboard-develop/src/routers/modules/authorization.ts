// 权限路由
import { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'

const authorizationRouter: RouteConfig = {
  path: '/authorization',
  component: RouteView,
  redirect: 'noredirect',
  name: 'Authorization',
  meta: {
    title: 'authorization',
    breadcrumb: '权限管理',
    keepAlive: true,
    role: ['admin'],
    icon: 'authorization'
  },
  children: [
    {
      path: 'project',
      component: () => import('@/projects/rds/views/businessCenter/authorization/project/index.vue'),
      name: 'Project',
      meta: {
        keepAlive: true,
        title: 'project',
        breadcrumb: '项目',
        noCache: true,
        role: ['admin']
      }
    },
    {
      path: 'user',
      component: () => import('@/projects/rds/views/businessCenter/authorization/user/index.vue'),
      name: 'User',
      meta: {
        title: 'user',
        breadcrumb: '用户',
        keepAlive: true,
        noCache: true,
        role: ['admin']
      }
    },
    {
      path: 'role',
      component: () => import('@/projects/rds/views/businessCenter/authorization/role/index.vue'),
      name: 'Role',
      meta: {
        title: 'role',
        breadcrumb: '角色',
        noCache: true,
        keepAlive: true,
        role: ['admin']
      }
    }
  ]
}

export default authorizationRouter
