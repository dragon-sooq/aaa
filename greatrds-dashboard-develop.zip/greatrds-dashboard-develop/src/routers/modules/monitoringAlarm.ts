// 监控告警路由
import { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'

const MonitoringAlarmRouter: RouteConfig = {
  path: '/monitoringAlarm',
  component: RouteView,
  redirect: 'noredirect',
  name: 'MonitoringAlarm',
  meta: {
    title: 'monitoringAlarm',
    keepAlive: true,
    icon: 'ops',
    role: ['admin', 'member'],
    breadcrumb: '监控告警',
    categoryKey: 'rds',
    iconName: 'el-icon-s-data'
  },
  children: [
    {
      path: 'monitoring',
      component: () => import('@/projects/rds/views/monitoringAlarm/monitoring/index.vue'),
      name: 'Monitoring',
      meta: {
        title: '监控列表',
        noCache: true,
        keepAlive: true,
        breadcrumb: '监控',
        role: ['admin', 'member']
      }
    },
    {
      path: 'detail/:uuid/:clusterUUid/:role',
      component: () => import('@/projects/rds/views/monitoringAlarm/monitoring/detail/index.vue'),
      name: 'MonitoringDetail',
      meta: {
        title: '监控详情',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '监控',
        role: ['admin', 'member']
      }
    },
    {
      path: 'alarm',
      component: () => import('@/projects/rds/views/monitoringAlarm/alarm/index.vue'),
      name: 'Alarm',
      meta: {
        title: '告警列表',
        noCache: true,
        keepAlive: true,
        breadcrumb: '告警',
        role: ['admin', 'member']
      }
    },
    {
      path: 'alarmOperation',
      component: () => import('@/projects/rds/views/monitoringAlarm/alarm/operation.vue'),
      name: 'AlarmOperation',
      meta: {
        title: '告警操作',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '告警操作',
        role: ['admin', 'member'],
        banner: {
          showBack: true,
          title: '创建告警规则' 
        }
      }
    },
    {
      path: 'alarmDetail/:id',
      component: () => import('@/projects/rds/views/monitoringAlarm/alarm/detail/index.vue'),
      name: 'alarmDetail',
      meta: {
        title: '告警规则详情',
        noCache: true,
        keepAlive: true,
        isAsideHide: true,
        breadcrumb: '告警规则',
        role: ['admin', 'member'],
        banner: {
          showBack: true,
          title: '告警详情' 
        }
      }
    }
  ]
}

export default MonitoringAlarmRouter
