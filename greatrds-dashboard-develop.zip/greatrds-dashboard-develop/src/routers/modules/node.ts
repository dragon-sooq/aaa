// 集群路由
import { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'

const nodeRouter: RouteConfig = {
  path: '/node',
  component: RouteView,
  redirect: 'noredirect',
  name: 'Node',
  meta: {
    title: 'node',
    keepAlive: true,
    icon: 'node',
    role: ['admin'],
    breadcrumb: '节点管理',
    categoryKey: 'database',
    iconName: 'el-icon-share'
  },
  children: [
    {
      path: 'compute',
      component: () => import('@/projects/rds/views/cluster/computeNode/index.vue'),
      name: 'ComputeNode',
      meta: {
        title: 'computeNode',
        noCache: true,
        keepAlive: true,
        breadcrumb: '计算节点',
        role: ['admin']
      }
    }
  ]
}

export default nodeRouter
