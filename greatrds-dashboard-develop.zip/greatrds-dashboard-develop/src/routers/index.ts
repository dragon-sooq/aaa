import Vue from 'vue'
import Router, { RouteConfig } from 'vue-router'
import RouteView from '@/projects/rds/views/main/RouteView/index.vue'
import routerAuthorization from './modules/authorization'
import routerCluster from './modules/cluster'
import routerOps from './modules/ops'
import routerNode from './modules/node'
import routerMonitoringAlarm from './modules/monitoringAlarm'
// import CACHE from '@/utils/cache'

Vue.use(Router)

export const asyncRoutes: RouteConfig[] = [
  routerAuthorization,
  // routerCluster,
  routerCluster,
  routerMonitoringAlarm,
  routerOps,
  routerNode
]

export const constantRoutes: RouteConfig[] = [
  {
    path: '/redirect',
    component: RouteView,
    meta: { isAsideHide: true, keepAlive: true },
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import(/* webpackChunkName: "redirect" */ '@/projects/rds/views/redirect/index.vue')
      }
    ]
  },
  {
    path: '/404',
    component: () => import(/* webpackChunkName: "404" */ '@/projects/rds/views/errorPage/404.vue'),
    meta: { isAsideHide: true, keepAlive: true }
  },
  {
    path: '/401',
    component: () => import(/* webpackChunkName: "401" */ '@/projects/rds/views/errorPage/401.vue'),
    meta: { isAsideHide: true, keepAlive: true }
  },
  {
    path: '/',
    component: RouteView,
    redirect: '/dashboard',
    name: 'Dashboard',
    meta: {
      breadcrumb: '概览',
      keepAlive: true
    },
    children: [
      {
        path: 'dashboard',
        component: () => import(/* webpackChunkName: "dashboard" */ '@/projects/rds/views/dashboard/index.vue'),
        name: 'Dashboard',
        meta: {
          breadcrumb: '概览',
          title: 'dashboard',
          icon: 'dashboard',
          keepAlive: true,
          affix: true
        }
      }
    ]
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/projects/rds/views/user/Login.vue'),
    meta: {
      breadcrumb: '登录页',
      isAsideHide: true
    }
  }
]

const createRouter = () => new Router({
  // mode: 'history',  // Disabled due to Github Pages doesn't support this, enable this if you need.
  scrollBehavior: (to, from, savedPosition) => {
    // eslint-disable-next-line id-length
    return savedPosition || { x: 0, y: 0 }
  },
  base: process.env.BASE_URL,
  routes: constantRoutes
})

const router = createRouter()

/**
 * 全局后置钩子
 */
// router.beforeEach((to, from, next) => {
//   // 切换路由取消ajax请求
//   // const CancelToken = axios.CancelToken;
//   // if (store.state.ajax.cancel){
//   //   store.state.ajax.cancel();
//   // }
//   // store.state.ajax = CancelToken.source();
//   let userId = CACHE.cookies.get('user_id')
//   if (to.name === 'Login' || to.name === 'NotFound') {
//     next()
//   } else if (!userId && to.name !== 'Login' && to.name !== 'NotFound') {
//     next({
//       name: 'Login',
//       query: {
//         redirect: to.fullPath
//       }
//     })
//   } else if (userId && to.name === 'Login') {
//     next({
//       path: '/'
//     })
//   } else if (to.meta && to.meta.hide) {
//     Vue.prototype.$notification['error']({
//       message: '系统提示',
//       description: '无权访问'
//     })
//     next(false)
//   } else {
//     next()
//   }
// })

export function resetRouter() {
  const newRouter = createRouter();
  (router as any).matcher = (newRouter as any).matcher // reset router
}
router.afterEach(() => {
  setTimeout(() => {
    window.scrollTo(0, 0)
  }, 100)
})

export default router
