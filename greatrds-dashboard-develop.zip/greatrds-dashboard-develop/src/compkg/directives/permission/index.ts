import { DirectiveOptions } from 'vue'
import user from '@/stores/modules/user'
import CACHE from '@/utils/cache'
export const permission: DirectiveOptions = {
  inserted(el, binding) {
    const { value } = binding
    const roles = CACHE.localStorage.get('role') || ''
    if (value && value instanceof Array && value.length > 0) {
      const permissionRoles = value
      const hasPermission = permissionRoles.includes(CACHE.localStorage.get('role'))
      if (!hasPermission) {
        el.style.display = 'none'
      }
    } else {
      throw new Error('need roles! Like v-permission="[\'admin\',\'editor\']"')
    }
  }
}
