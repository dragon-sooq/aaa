<template>
  <div class="header-banner">
    <div class="header">
      <span
        v-show="headerConfig.showBack"
        @click="$router.back()"
        class="mr-30 font-16 cursor-p"
      >
        <i class="el-icon-arrow-left" />
      </span>
      <span class="font-16">
        {{ headerConfig.title }}
      </span>
    </div>
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class HeaderBanner extends Vue {
  @Prop() headerConfig: any;
}
</script>
<style lang="scss">
  .header-banner {
    .header {
      padding: 0 30px;
      background-color: #464d6e;
      color: #fff;
      box-shadow: 1px 1px 4px 0 #e2e2e2;
      height: 40px;
      line-height: 40px;
      border-bottom: 1px solid #ddd;
      position: relative;
    }
  }
</style>
