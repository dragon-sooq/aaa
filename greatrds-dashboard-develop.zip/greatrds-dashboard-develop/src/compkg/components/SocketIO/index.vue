<template>
  <div />
</template>

<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { Socket } from 'vue-socket.io-extended'
import { namespace } from 'vuex-class'

const userModule = namespace('user')

@Component
export default class SocketIO extends Vue {
  @userModule.Getter('wsToken') wsToken
  @userModule.Getter('wsPath') wsPath
  @Socket() // --> listens to the event by method name, e.g. `connect`
  connect() {
    console.log('connection established')
    this.$socket.client.emit('my_event', 'I\'m connected!')
  }

  @Socket('my_response') // --> listens to the event with given name, e.g. `tweet`
  response(data) {
    console.log('receive:', data)
    this.$notify({
      title: 'SocketIOResponse',
      message: `${data}`,
      type: 'success'
    })
  }

  @Socket('STATES') // --> listens to the event with given name, e.g. `tweet`
  states(data) {
    console.log('STATES:', data)
    if (data instanceof Object) {
      data = JSON.stringify(data)
    }
    this.$notify({
      title: 'SocketIO_STATES',
      message: `${data}`,
      type: 'info'
    })
  }

  @Socket('ASYNC_RESPONSE') // --> listens to the event with given name, e.g. `tweet`
  asyncResponse(data) {
    console.log('ASYNC_RESPONSE:', data)
    if (data instanceof Object) {
      data = JSON.stringify(data)
    }
    this.$notify({
      title: 'SocketIO_ASYNC_RESPONSE',
      message: `${data}`,
      type: 'info'
    })
  }

  @Socket('NOTIFY_EVENT') // --> listens to the event with given name, e.g. `tweet`
  notifyEvent(data) {
    console.log('NOTIFY_EVENT:', data)
    if (data instanceof Object) {
      data = JSON.stringify(data)
    }
    this.$notify({
      title: 'SocketIO_NOTIFY_EVENT',
      message: `${data}`,
      type: 'info'
    })
  }

  @Socket() // --> listens to the event by method name, e.g. `connect`
  disconnect() {
    console.log('disconnect established')
  }

  // --> listens to the connect_error, close connect
  @Socket('connect_error')
  connectError() {
    console.log('connect_error  disconnect')
    this.$socket.client.disconnect()
  }

  mounted() {
    if (this.wsToken && this.$route.name !== 'Login') {
      this.$socket.client.io.opts.query = {token: this.wsToken}
      this.$socket.client.io.opts.path = this.wsPath
      if (!this.$socket.connected) {
        this.$socket.client.connect()
      }
    }
  }

}
</script>

<style scoped>

</style>
