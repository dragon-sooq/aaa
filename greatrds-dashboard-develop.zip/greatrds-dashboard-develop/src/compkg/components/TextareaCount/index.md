# 多行文本输入 区分汉字与字符

### 参数：
参数|说明|类型
-|:-|-
maxLen | 最大可输入字符个数	| number
inputVal | 输入框内容 | string
||

```
<textarea-count
  :max-len="300"
  :input-val="setNotesForm.comment"
/>

```