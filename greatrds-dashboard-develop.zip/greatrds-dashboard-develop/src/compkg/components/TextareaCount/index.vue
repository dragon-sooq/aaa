<template>
  <div class="textarea-num-box">
    <el-input
      type="textarea"
      resize="none"
      :rows="4"
      :maxlength="maxLen"
      v-model="inputData"
    />
    <span class="textarea-num">
      <i>{{ curLen }}</i>
      <i> / </i>
      <i>{{ maxLen / 2 }}</i>
    </span>
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import Utils from '@/utils'
import { judgeTextInput, getStrLength } from '@/utils/judge'

@Component
export default class TextareaCount extends Vue {
  @Prop() inputVal: string;
  @Prop() maxLen: number;

  private inputData: string = '';
  private curLen: number = 0;
  private tim: any = {};

  @Watch('inputData')
  inputDataChange(newVal: any, oldVal: any) {
    if (newVal !== oldVal) {
      clearTimeout(this.tim)// 取消倒计时
      this.tim = setTimeout(() => {
        // 开启自动截取功能 this.inputData =
        judgeTextInput({
          val: newVal || '',
          limit: this.maxLen,
          title: '附件描述'
        }).then((opts: any) => {
          console.log(opts)
          // this.inputData = opts.value;
        })
        if (this.inputData !== newVal) {
          clearTimeout(this.tim)// 取消倒计时
        }
        this.curLen = (Math.floor(getStrLength(this.inputData) / 2) || 0)
      }, 300)
    }
  }
  created() {
    let that = this
    that.inputData = Utils.Lodash.cloneDeep(that.inputVal)
    console.log(that.inputData)
    let strVal = Math.floor(getStrLength(that.inputData) / 2) || 0

  }
}
</script>
<style lang="scss" scoped>
  .textarea-num-box{
    position: relative;
    font-size: 12px;
    .el-textarea{
      textarea {
        padding-bottom: 15px;
      }
    }
    .textarea-num {
      position: absolute;
      right: 3px;
      bottom: 0;
      line-height: 22px;
      i{
        font-style: normal;
      }
    }
  }
</style>
