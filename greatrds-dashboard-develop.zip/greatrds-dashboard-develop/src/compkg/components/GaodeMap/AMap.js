export default function MapLoader() {
  if (window.AMap) {
    return window.AMap
  }
  let script = document.createElement('script')
  script.type = 'text/javascript'
  script.async = true
  script.src = 'https://webapi.amap.com/maps?v=1.4.15&key=3f413a63e542be694090abc7f48cdd98&plugin=AMap.Geocoder'
  document.head.appendChild(script)
  return window.AMap
}
