# 高德地图  选择地理位置

### 参数：
参数|说明|类型
-|:-|-
dialogData | 弹窗需要的参数	| object
show | 弹窗是否展示 | boolean
||

### dialogData参数：
参数|说明|类型
-|:-|-
choosed | 已选中的位置信息	| object
submitChange | 成功后的回调 | function
closeChange | 关闭后的回调 | function
||
```
dialogData: {
  choosed: {
    name: "北京市东城区东华门街道正义路酒店北京东交民巷饭店写字楼",
    province: "北京市",
    city: "北京市",
    area: "东城区",
    location: {
      lat: 39.903173,
      lng: 116.407384,
    }
  },
  submitChange: () => {},
  closeChange: () => {}
}
```
