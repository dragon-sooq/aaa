/**
 * 获取地图定位
 */
import MapLoader from './AMap.js'

/**
 * 获取高德地图定位
 */
export const getGaodeLocation = () => {
  return new Promise((resolve, reject) => {
    const AMap = MapLoader()
    AMap.plugin('AMap.Geolocation', () => {
      new AMap.Geolocation({
        enableHighAccuracy: true, // 是否使用高精度定位，默认:true
        timeout: 10000, // 超过10秒后停止定位，默认：5s
        buttonPosition: 'RB', // 定位按钮的停靠位置
        buttonOffset: new AMap.Pixel(10, 20), // 定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
        zoomToAccuracy: false // 定位成功后是否自动调整地图视野到定位点
      }).getCurrentPosition((status, res) => {
        if (status === 'complete' && res.position) {
          // 暴露参数formattedAddress, position.lng, position.lat
          resolve(res)
        } else {
          let resMsg = JSON.stringify(res.message)
          let errMsg = ''
          if (resMsg.indexOf('Browser not Support html5 geolocation') > -1) {
            errMsg = '浏览器版本不支持定位'
          } else if (resMsg.indexOf('Geolocation permission denied') > -1) {
            errMsg = '浏览器已禁用定位权限'
          } else if (resMsg.indexOf('Get geolocation time out') > -1) {
            errMsg = '浏览器定位超时'
          } else if (resMsg.indexOf('Get geolocation failed') > -1) {
            errMsg = '浏览器定位失败'
          }
          reject('定位失败：' + (errMsg || res.message))
        }
      })
    })
  })
}
