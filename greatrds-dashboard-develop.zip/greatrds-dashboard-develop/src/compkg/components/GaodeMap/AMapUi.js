export default function AMapUILoader() {
  if (window.AMapUI) {
    return window.AMapUI
  }
  let script = document.createElement('script')
  script.type = 'text/javascript'
  script.async = true
  script.src = 'https://webapi.amap.com/ui/1.0/main.js?v=1.0.11'
  document.head.appendChild(script)
  return window.AMapUI
}
