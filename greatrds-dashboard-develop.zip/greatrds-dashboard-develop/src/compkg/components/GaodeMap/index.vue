<template>
  <DialogLayer
    width="70%"
    title="选择位置"
    class="es-work-table-choose-containers"
    :before-close="handleClose"
    :visible.sync="isThisDialog"
    @close="$emit('update:show', false);"
  >
    <div
      class="map-containers"
    >
      <div class="map-choose-text">
        <span v-if="!position">请在地图中选择位置</span>
        <span v-if="position">已选位置：{{ position }}</span>
      </div>
      <div class="amap-search-containers">
        <!-- <el-amap-search-box
          id="searchInput"
          class="search-box"
          :search-option="searchOption"
          :on-search-result="onSearchResult"
        /> -->
      </div>
      <i
        class="fa fa-close close-icon"
        v-if="position"
        @click="handleClear()"
      />
      <!-- <el-amap
        ref="map"
        vid="map-box"
        :amap-manager="amapManager"
        :center="center"
        :zoom="zoom"
        :events="events"
        class="map-box"
      >
        <el-amap-info-window
          v-if="currentWindow.visible"
          :position="currentWindow.position"
          :content="currentWindow.content"
          :visible="currentWindow.visible"
          :events="currentWindow.events"
          :close="() => currentWindow = {
            position: [0, 0],
            content: '',
            visible: false
          }"
        />
      </el-amap> -->
      <div id="searchResults" />
    </div>
    <div
      slot="footer"
      class="dialog-footer"
    >
      <!-- <el-button
        @click="handleClose()"
        size="medium"
      >
        关 闭
      </el-button>
      <el-button
        @click="handleClear()"
        size="medium"
        v-if="position"
      >
        清除选择
      </el-button>
      <el-button
        type="primary"
        size="medium"
        @click="submitForm()"
      >
        确 定
      </el-button> -->
    </div>
  </DialogLayer>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DialogLayer from '@/compkg/components/DialogLayer/index.vue'
import VueAMap from 'vue-amap'
import MapLoader from './AMap.js'
import AMapUILoader from './AMapUi.js'

Vue.use(VueAMap)

const defaultChoosed = {
  name: '',
  province: '北京',
  city: '',
  area: '',
  location: {}
}

let amapManager = new VueAMap.AMapManager({})

VueAMap.initAMapApiLoader({
  key: '3f413a63e542be694090abc7f48cdd98',
  v: '1.4.15',
  plugin: [
    // 'AMap.Autocomplete', // 输入提示插件
    // 'AMap.PlaceSearch', // POI搜索插件
    // 'AMap.Scale', // 右下角缩略图插件 比例尺
    // 'AMap.OverView', // 地图鹰眼插件
    // 'AMap.ToolBar', // 地图工具条
    // 'AMap.MapType', // 类别切换控件，实现默认图层与卫星图、实施交通图层之间切换的控制
    // 'AMap.PolyEditor', // 编辑 折线多，边形
    // 'AMap.CircleEditor', // 圆形编辑器插件
    // 'AMap.Geolocation', // 定位控件，用来获取和展示用户主机所在的经纬度位置
    'AMap.Geocoder'
  ],
  uiVersion: '1.0'
})

@Component({
  components: {
    DialogLayer
  }
})
export default class GaodeMap extends Vue {
  @Prop(Boolean) show: boolean;
  @Prop() dialogData: any;

  private dataSource: any = this.dialogData || {};
  currentWindow:any = {
    position: [0, 0],
    content: '',
    events: {},
    visible: false
  }

  private map: any = null;
  private isThisDialog:boolean = this.show;
  private chooseData:any = this.dataSource.choosed || defaultChoosed;
  private position: any = ((this.dataSource.choosed || defaultChoosed) as any).name;
  private searchOption: any = {
    city: ((this.dataSource.choosed || defaultChoosed) as any).city || '北京',
    citylimit: true
  }
  private zoom:number = 12;
  private center:any = [116.397428, 39.90923];
  private amapManager:any = amapManager;
  private lng:any;
  private lat: any;

  private events: any = {
    init(map) {
      // o是指地图实例
      this.map = map
      if (this.position) {
        this.upDateInputValue(this.position)
        this.getPOISearch(this.position)
      }
    },
    click: (e) => {
      let { lng, lat } = e.lnglat
      this.lng = lng
      this.lat = lat
      this.getAddress(lng, lat, 'click')
    }
  }
  created() {
    MapLoader()
    AMapUILoader()
  }
  mounted() {
    /*
     * mounted 不会承诺所有的子组件也都一起被挂载。希望等到整个视图都渲染完毕，
     * 可以用that.$nextTick 替换掉 mounted
     */
    this.$nextTick(() => {
      const ele = (document.getElementsByClassName('search-box-wrapper') as any)[0]
      if (ele && ele.children && ele.children[0]) {
        ele.children[0].placeholder = '请输入地点的关键字'
      }
    })
  }

  onSearchResult(pois) {
    if (pois.length > 0) {
      const { location, name } = pois[0]
      this.position = name
      this.getAddress(location.lng, location.lat, 'search')
      this.getPOISearch(name)
    }
  }

  /**
   * 获取具体地址
   */
  getAddress(lng, lat, type) {
    const that = this
    // 这里通过高德 SDK 完成。
    let geocoder = new (window as any).AMap.Geocoder({
      radius: 1000,
      extensions: 'all'
    })
    geocoder.getAddress([lng, lat], (status, result) => {
      if (status === 'complete' && result.info === 'OK') {
        if (result && result.regeocode) {
          // 当前选中的值
          that.chooseData = {
            /* result.regeocode.formattedAddress: 在点击事件时取值是正确的 */
            name: type === 'click' ? result.regeocode.formattedAddress : that.position, // 地址造型
            province: result.regeocode.addressComponent.province, // 省
            city: result.regeocode.addressComponent.city || result.regeocode.addressComponent.province, // 市 直辖市存在city为空 直接用省来补
            area: result.regeocode.addressComponent.district, // 区
            location: {
              lng: lng, // 经度
              lat: lat // 经度
            }
          }
          if (type === 'click') {
            const closeCurrentWindowFun = () => {
              that.currentWindow = {
                position: [0, 0],
                content: '',
                visible: false,
                events: {
                  close() {
                    console.log('close infowindow1')
                  }
                }
              }
            }
            that.currentWindow = {
              position: [lng, lat],
              content: result.regeocode.formattedAddress,
              visible: true,
              events: {
                close: closeCurrentWindowFun
              }
            }
            that.position = result.regeocode.formattedAddress
          }
          that.upDateInputValue(that.position)
          that.$nextTick()
        }
      }
    })
    that.$nextTick()
  }

  /**
   * 更新input选中的值
   */
  upDateInputValue(val) {
    const ele = (document.getElementsByClassName('search-box-wrapper') as any)[0]
    if (ele && ele.children && ele.children[0]) {
      ele.children[0].value = val
    }
  }

  /**
   * POI搜索
   */
  getPOISearch(keyWord) {
    const that = this;
    (window as any).AMapUI.loadUI(['misc/PoiPicker'], (PoiPicker: any) => {
      let poiPicker = new PoiPicker({
        input: 'searchInput',
        placeSearchOptions: {
          map: that.map,
          pageSize: 5
        },
        searchResultsContainer: 'searchResults'
      })
      poiPicker.onCityReady(() => poiPicker.searchByKeyword(keyWord))
    })
  }

  /**
   * 提交确定
   */
  submitForm() {
    if (typeof this.dataSource.submitChange === 'function') {
      console.log(this.chooseData)
      this.dataSource.submitChange && this.dataSource.submitChange(this.chooseData)
    }
    this.handleClose()
  }

  /**
   * 处理关闭
   */
  handleClose() {
    this.dataSource.closeChange && this.dataSource.closeChange()
    // (this.$parent as any).actionModal = null;
    // 关闭当前
    this.isThisDialog = false
  }

  /**
   * 处理清空
   */
  handleClear() {
    this.position = ''
    this.upDateInputValue('')
    this.getPOISearch(this.position)
    // 信息窗体
    this.currentWindow = {
      'position': [0, 0],
      'content': '',
      'events': {},
      'visible': false
    }
    // this.map.clear();
    this.chooseData = {
      'name': '',
      'province': '',
      'city': '',
      'area': '',
      'location': {}
    };
    (document.getElementById('searchResults') as any).innerHTML = ''
  }
}
</script>

<style lang="scss" scoped>
  .el-dialog__body{
    padding: 0px;
    background: #f5f6f7;
  }
  #searchResults{
    max-height: 180px;
    overflow-y: scroll;
    overflow-x: hidden;
  }
  .map-containers{
    position: relative;
    .map-choose-text{
      color: #3c763d;
      background-color: #dff0d8;
      border-color: #d6e9c6;
      padding: 15px;
    }
  }
  .map-box{
    height: 300px !important;
  }
  .amap-search-containers{
    position: absolute;
    top: 60px;
    right: 10px;
    .search-btn{
      visibility: hidden;
      width: 32px;
    }
  }
  .close-icon{
    position: absolute;
    right: 20px;
    z-index: 100;
    top: 74px;
    font-size: 16px;
    cursor: pointer;
  }
  .search-containers {
    top: 66px;
    right: 20px;
    position: absolute;
    z-index: 100;
    width: 260px;
    border: none;
    height: 30px;
    line-height: 30px;
    padding-left: 20px;
    background: #fff;
    &:focus{
      outline: none;
    }
  }
  .amap-page-container {
    position: relative;
  }
</style>
