<template>
  <div class="site-map-view">
    <div class="menu">
      <p style="text-align: right">
        <i 
          class="el-icon-close menu-close-btn"
          @click="closeMenu"
        />
      </p>
      <div class="wrap">
        <div
          class="product-view"
        >
          <div class="class-view">
            <div
              style="margin-bottom: 40px;"
            >
              <h3 class="class-title">RDS</h3>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "主从" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MGR" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink('分布式数据库', 'qwe', true)"
                    >
                      {{ "分布式数据库" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MySQL" }}
                    </a>
                  </div>
                </div>  
              </div>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink('监控', '监控', true)"
                    >
                      {{ "监控" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "告警" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "集群拓扑" }}
                    </a>
                  </div>
                </div>  
              </div>

              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "操作日志" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "备份" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "定时任务" }}
                    </a>
                  </div>
                </div>  
              </div>
            </div>

            <div
              style="margin-bottom: 40px;"
            >
              <h3 class="class-title">缓存</h3>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MongoDB" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "Redis" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MemCached" }}
                    </a>
                  </div>
                </div>  
              </div>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "监控" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "告警" }}
                    </a>
                  </div>
                </div>  
              </div>
            </div>

            <!-- <div
              style="margin-bottom: 40px;"
            >
              <h3 class="class-title">PaaS服务</h3>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MySQL" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MongoDB" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "Redis" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MemCached" }}
                    </a>
                  </div>
                </div>  
              </div>
            </div> -->

            <div
              style="margin-bottom: 40px;"
            >
              <h3 class="class-title">数据库纳管</h3>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MySQL" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "Redis" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "MongoDB" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "主从" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "分布式数据库" }}
                    </a>
                  </div>
                </div>  
              </div>
              <div class="group-view">
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "监控" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "告警" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "集群拓扑" }}
                    </a>
                  </div>
                </div>
                <div
                  class="group-view-item"
                >
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "操作日志" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "备份" }}
                    </a>
                  </div>
                  <div
                    class="item-view"
                  >
                    <a 
                      href="javascript:;" 
                      @click="appLink(providerViewItem.name, item.link)"
                    >
                      {{ "定时任务" }}
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { Mutation, Getter } from 'vuex-class'

@Component
class MenuComponent extends Vue {
  @Mutation('toggleMenuHidden') toggleMenuHidden;

  private menuList: Array<object> = [
    {
      sub: [
        {
          name: 'RDS'
        }
      ]
    },
    {
      title: 'PASS数据容器数据库',
      childItem: [
        {
          name: '全局概览'
        }
      ]
    },
    {
      title: '数据库纳管',
      childItem: [
        {
          name: '全局概览'
        }
      ]
    }
  ]

  @Prop(Boolean)
  layoutHidden: boolean


  created() {
  }

  closeMenu() {
    this.toggleMenuHidden(false)
  }

  appLink(name: String, link: String) {
    console.log(name, link)
  }

}

export default MenuComponent
</script>
<style lang="scss" scoped>
  .site-map-view {
    height: 100%;
    display: flex;
    overflow: hidden;
    flex-direction: row;
    .menu {
      flex: 1;
      background-color: #fff;
      position: relative;
      .menu-close-btn {
        padding: 10px;
        font-size: 24px;
        cursor: pointer;
      }
      .wrap { 
        padding: 0 35px;
      }
      .class-title {
        display: block;
        clear: both;
        margin-bottom: 15px;
        font-size: 16px;
      }
      .group-view {
        &:after {
          content: ' ';
          display: block;
          clear: both;
        }
        .group-view-item {
          margin-bottom: 15px;
          border-left: solid 3px #526ECC;
          padding-left: 30px;
          &:after {
            content: ' ';
            display: block;
            clear: both;
          }
        }
        .item-view {
          float: left;
          width: 20%;
          padding: 4px 0px;
          a {
            color: #515a6e;
            font-size: 13px;
            &:hover {
              color: #526ECC;
            }
          }
        }
      }
    }
}
</style>
