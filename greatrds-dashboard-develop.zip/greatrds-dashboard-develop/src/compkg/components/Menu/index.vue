<template>
  <div class="site-map-view">
    <div class="menu">
      <p style="text-align: right">
        <i 
          class="el-icon-close menu-close-btn"
          @click="closeMenu"
        />
      </p>
      <div class="wrap">
        <div
          class="product-view"
        >
          <div class="class-view">
            <div
              style="margin-bottom: 40px;"
            >
              <div class="group-item">
                <h3 class="class-title">{{ menuList['rds'] }}</h3>
                <div class="group-view">
                  <template
                    v-for="(val, ind) in $router.options.routes"
                    class="group-view-item"
                  >
                    <template v-if="val.meta && (val.meta.categoryKey === 'rds')">
                      <template
                        v-for="(v, index) in val.children"
                      >
                        <a 
                          :key="ind + '-' + index"
                          href="javascript:;" 
                          @click="appLink(v.name, val.meta.categoryKey)"
                        >
                          {{ v.meta.breadcrumb }}
                        </a>
                      </template>
                    </template>
                  </template>  
                </div>
              </div>
              <div class="group-item">
                <h3 class="class-title">{{ menuList['database'] }}</h3>
                <div class="group-view">
                  <template
                    v-for="(val, ind) in $router.options.routes"
                    class="group-view-item"
                  >
                    <template
                      v-if="val.meta && (val.meta.categoryKey === 'database')"
                    >
                      <template
                        v-for="(v, index) in val.children"
                      >
                        <a 
                          :key="ind + '-' + index"
                          href="javascript:;" 
                          @click="appLink(v.name, val.meta.categoryKey)"
                        >
                          {{ v.meta.breadcrumb }}
                        </a>
                      </template>
                    </template>
                  </template>  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { Mutation, Getter } from 'vuex-class'

@Component
class MenuComponent extends Vue {
  @Mutation('toggleMenuHidden') toggleMenuHidden;
  @Mutation('toggleRouterKey') toggleRouterKey;
  
  private menuList: Object = {
    'rds': 'RDS',
    'database': '数据库纳管'
  }

  @Prop(Boolean)
  layoutHidden: boolean


  created() {
  }

  closeMenu() {
    this.toggleMenuHidden(false)
  }

  appLink(routeName: String, key: String) {
    console.log(routeName, key)
    if (routeName) {
      const that: any = this
      that.$router.push({
        name: routeName
      })
    }
    this.toggleRouterKey(key)
  }

}

export default MenuComponent
</script>
<style lang="scss" scoped>
  .site-map-view {
    height: 100%;
    display: flex;
    overflow: hidden;
    flex-direction: row;
    .menu {
      flex: 1;
      background-color: #fff;
      position: relative;
      .menu-close-btn {
        padding: 10px;
        font-size: 24px;
        cursor: pointer;
      }
      .wrap {
        position: absolute;
        padding: 0px 50px;
        left: 0;
        top: 30px;
        right: 0;
        bottom: 50px;
        overflow-y: auto;
      }
      .class-title {
        display: block;
        clear: both;
        margin-bottom: 10px;
        font-size: 16px;
      }
      .group-item{
        margin-bottom: 30px;
      }
      .group-view {
        width: 380px;
        padding-left: 10px;;
        &:after {
          content: ' ';
          display: block;
          clear: both;
        }
        .group-view-item {
          margin-bottom: 15px;
          border-left: solid 3px;
          padding-left: 30px;
          &:after {
            content: ' ';
            display: block;
            clear: both;
          }
        }
        a {
          display: inline-block;
          width: 31%;
          color: #515a6e;
          font-size: 16px;
          margin-top: 25px;
          // &:hover {
          //   color: @stress-color;
          // }
        }
      }
    }
}
</style>
