<template>
  <el-dialog
    class="dialog-layer"
    custom-class="ethings-dialog"
    :title="title || ''"
    :visible="visible"
    :close-on-click-modal="false"
    :close-on-press-escap="false"
    :append-to-body="true"
    :destroy-on-close="true"
    :width="width || '70%'"
    :fullscreen="fullscreen"
    v-drag-directive
    v-bind="this.mergedProps()"
    v-on="this.listeners()"
  >
    <el-button
      class="full-screen"
      @click="setFullscreen"
      icon="fa fa-full"
    />
    <slot />
    <slot
      v-if="useFooter"
      name="footer"
      slot="footer"
      class="dialog-footer"
    >
      <el-button
        size="small"
        @click="cancel"
      >
        {{ $t('取消') }}
      </el-button>
      <el-button
        size="small"
        type="primary"
        @click="confirm"
      >
        {{ $t('确定') }}
      </el-button>
    </slot>
  </el-dialog>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import DragDirective from './DragDirective'

const VDrag: DragDirective = new DragDirective()

@Component({
  name: 'DialogLayer',
  directives: {
    'drag-directive': VDrag.dragDirective
    // 'drag-resize': VDrag.dragSizeDirective
  }
})
class DialogLayerComponent extends Vue {

  @Prop({type: Boolean, required: true}) visible: boolean;
  @Prop(String) width: string;
  @Prop(String) title: string;
  @Prop({
    type: Boolean,
    default: true
  }) useFooter; // 是否使用footer

  /**
   * 成功的回调事件
   * 注意：该字段的传入请使用参数传递的方式传入，类型为 Function.
   */
  @Prop(Function) success: Function;

  // 是否开启全屏按钮
  @Prop(Boolean) needFullscreen: boolean;

  dragDirective: DragDirective;
  constructor() {
    super()
    this.dragDirective = VDrag
  }

  listeners() {
    return {
      ...this.$listeners
    }
  }

  mergedProps() {
    return {
      ...this.$attrs,
      ...this.$props,
      ...this.$slots,
      ...this.$vnode,
      ...this.$scopedSlots,
      ...this.$mount,
      ...this.$refs
    }
  }

  // 全屏控制字段
  fullscreen: boolean = false;

  // 取消按钮的点击事件
  cancel() {
    this.$emit('update:visible', false)
  }

  // 确定按钮的点击事件
  confirm() {
    if (!this.success) {
      this.$emit('update:visible', false)
    } else {
      const res: boolean | undefined = this.success()
      // 执行完后关闭弹出层
      if (res !== false && this.visible) {
        this.$nextTick(() => {
          this.$emit('update:visible', false)
        })
      }
    }
  }

  setFullscreen() {
    this.fullscreen = !this.fullscreen
    // 该部分为修复Element-UI中对dialog的fullscreen处理问题
    if (this.fullscreen === true) {
      let dialogContent = document.querySelector('.ethings-dialog') as any
      dialogContent.style.top = '0px'
      dialogContent.style.left = '0px'
    }
  }

}

export default DialogLayerComponent
</script>
<style lang="scss">
  .dialog-layer{
    .el-dialog__body{
      max-height: 60vh;
      overflow: hidden auto;
      padding-top: 0;
      padding-bottom: 0;
      &:after{
        content: '';
        display: block;
        clear: both;
      }
    }
    .el-dialog.is-fullscreen{
      .el-dialog__body{
        max-height: 90vh;
      }
    }
  }
</style>
<style lang="scss" scoped>
  .dialog-layer{
    overflow: hidden;
    .full-screen{
      position: absolute;
      top: 14px;
      right: 50px;
      padding: 0;
      background: none;
      border: none;
      color: #909399;
      &:hover{
        color: #f00;
      }
    }
  }
</style>
