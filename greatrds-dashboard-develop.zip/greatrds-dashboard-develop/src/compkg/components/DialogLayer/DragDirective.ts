/**
 * DialogLayer组件的拖拽功能
 */

import { DirectiveOptions } from 'vue'
import { DirectiveBinding } from 'vue/types/options'

class DragDirective {
  /**
   * 弹窗拖动指令
   */
  dragDirective: DirectiveOptions = {
    bind(el: HTMLElement) {
      // 获取拖拽内容头部
      const headerElement: HTMLElement = el.querySelector('.el-dialog__header') as any
      // 获取拖拽内容整体
      const dialogContentEle: HTMLElement = el.querySelector('.ethings-dialog') as any
      headerElement.style.cursor = 'move'
   
      // 获取原有属性 ie dom元素.currentStyle 火狐谷歌 window.getComputedStyle(dom元素, null);
      const dialogContentStyle = (dialogContentEle as any).currentStyle || window.getComputedStyle(dialogContentEle, null)
   
      // 鼠标按下事件
      headerElement.onmousedown = (e: any) => {
        // 鼠标按下，计算当前元素距离可视区的距离 (鼠标点击位置距离可视窗口的距离)
        const disX: number = e.clientX - headerElement.offsetLeft
        const disY: number = e.clientY - headerElement.offsetTop

        const screenWidth: number = document.documentElement.clientWidth // 可见区域宽度
        const screenHeight: number = document.documentElement.clientHeight // 可见区域高度

        const dialogContentEleWidth: number = dialogContentEle.offsetWidth // 对话框宽度
        const dialogContentEleHeight: number = dialogContentEle.offsetHeight // 对话框高度

        const minMovableLeft: number = dialogContentEle.offsetLeft
        const maxMovableLeft: number = screenWidth - dialogContentEle.offsetLeft - dialogContentEleWidth

        const minMovableTop: number = dialogContentEle.offsetTop
        const maxMovableTop: number = screenHeight - dialogContentEle.offsetTop - dialogContentEleHeight
  
        // 获取到的值带px 正则匹配替换
        let styLeft: number = 0, styTop: number = 0
   
        // 注意在ie中 第一次获取到的值为组件自带50% 移动之后赋值为px
        if (dialogContentStyle.left.includes('%')) {
          styLeft = +document.body.clientWidth * (+dialogContentStyle.left.replace(/\%/g, '') / 100)
          styTop = +document.body.clientHeight * (+dialogContentStyle.top.replace(/\%/g, '') / 100)
        } else {
          styLeft = +dialogContentStyle.left.replace(/\px/g, '')
          styTop = +dialogContentStyle.top.replace(/\px/g, '')
        }
   
        // 鼠标拖拽事件
        document.onmousemove = (ev) => {
          // 通过事件委托，计算移动的距离 （开始拖拽至结束拖拽的距离）
          let finishLeft: number = ev.clientX - disX
          let finishTop: number = ev.clientY - disY
  
          if (-(finishLeft) > minMovableLeft) {
            finishLeft = -(minMovableLeft)
          } else if (finishLeft > maxMovableLeft) {
            finishLeft = maxMovableLeft
          }
          
          if (-(finishTop) > minMovableTop) {
            finishTop = -(minMovableTop)
          } else if (finishTop > maxMovableTop) {
            finishTop = maxMovableTop
          }
   
          // 移动当前元素位置
          dialogContentEle.style.left = `${finishLeft + styLeft}px`
          dialogContentEle.style.top = `${finishTop + styTop}px`
   
          // 将此时的位置传出去
          // binding.value({x:e.pageX,y:e.pageY})
        }
   
        // 重置解除事件
        document.onmouseup = () => {
          document.onmousemove = null
          document.onmouseup = null
        }
      }
    }
  }

  /**
   * 弹窗拖动大小指令
   * 注意：目前并不好用
   */
  // dragSizeDirective: DirectiveOptions = {
  //   bind(el: HTMLElement) {
  //     const dragDom = el.querySelector('.ethings-dialog') as any;

  //     el.onmousedown = (evDown: any) => {
          
  //       // 鼠标按下，计算当前元素距离可视区的距离
  //       const disX = evDown.clientX - el.offsetLeft;
        
  //       document.onmousemove = (evMove: any) => {
  //         evMove.preventDefault(); // 移动时禁用默认事件

  //         // 通过事件委托，计算移动的距离 
  //         const left = evMove.clientX - disX;
  //         dragDom.style.width = `${left}px`;
  //       };

  //       document.onmouseup = () => {
  //         document.onmousemove = null;
  //         document.onmouseup = null;
  //       };
  //     }; 
  //   }
  // }
}

export default DragDirective
