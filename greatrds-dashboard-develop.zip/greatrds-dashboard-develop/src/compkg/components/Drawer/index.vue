<template>
  <el-drawer
    :size="width || '50%'"
    :direction="direction || 'rtl'"
    :title="title || ''"
    :modal="showModal ? true : false"
    :visible="visible"
    :destroy-on-close="true"
    :with-header="title ? true : false"
    :wrapper-closable="true"
    :modal-append-to-body="true"
    :append-to-body="true"
    @close="close"
    v-bind="this.mergedProps()"
    v-on="this.listeners()"
  >
    <template v-slot:title>
      <span>
        {{ title || '' }}
      </span>
      <slot name="titlectrl" />
    </template>
    <slot />
  </el-drawer>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
class DrawerComponent extends Vue {

  // 控制抽屉显隐的参数
  @Prop({type: Boolean, required: true}) visible: boolean;
  // 宽度 - 默认：50%
  @Prop(String) width: string;
  // 标题 - 默认：空
  @Prop(String) title: string;
  // 标题 - 默认：空
  @Prop({default: true}) showModal: Boolean;
  // 进入方向 - 默认： 右到左滑动
  @Prop(String) direction: string;

  close() {
    this.$emit('update:visible', false)
  }

  listeners() {
    return {
      ...this.$listeners
    }
  }

  mergedProps() {
    return {
      ...this.$attrs,
      ...this.$props,
      ...this.$slots,
      ...this.$vnode,
      ...this.$scopedSlots,
      ...this.$mount,
      ...this.$refs
    }
  }

}

export default DrawerComponent
</script>
<style lang="scss">

</style>
