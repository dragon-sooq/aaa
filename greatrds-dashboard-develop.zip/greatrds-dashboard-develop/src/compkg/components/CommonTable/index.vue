<template>
  <div class="common-table-containers">
    <el-table
      data-test="table"
      :data="tableAtr.data"
      :border="tableAtr.border"
      :size="tableAtr.size"
      :height=" tableAtr.height || tableHeight"
      :style="tableAtr.style"
      :stripe="tableAtr.stripe"
      :row-class-name="tableAtr.rowClassName"
      :default-sort="tableAtr.defaultSort"
      :max-height="tableAtr.maxHeight"
      @sort-change="handleSortChange"
      @selection-change="handleSelectionChange"
    >
      <template v-for="(column, index) in columns">
        <!-- 展开行  -->
        <el-table-column
          v-if="column.type && column.type === 'expand'"
          :align="column.align || 'center'"
          :key="index"
          :width="column.width"
          :fixed="column.fixed"
          :type="column.type"
        >
          <template slot-scope="scope">
            <slot
              :name="column.prop"
              :row="scope.row || {}"
              :index="scope.$index"
              :column="scope.column || {}"
            />
          </template>
        </el-table-column>
        <!--
          添加多选框 自定义索引
          type的值：
             selection 多选
             index 索引 搭配index字段 可以自定义索引
         -->
        <el-table-column
          v-else-if="column.type && column.type !== 'expand'"
          :align="column.align || 'center'"
          :key="index"
          :label="$t('序号')"
          :width="column.width"
          :fixed="column.fixed"
          :type="column.type"
          :index="column.index"
        />
        <!-- 多级表头 -->
        <el-table-column
          v-else-if="column.children && column.children.length"
          :align="column.align || 'center'"
          :key="index"
          :label="$t(column.label)"
          :index="column.index"
        >
          <template v-for="(childrenItem, childrenIndex) in column.children">
            <el-table-column
              :align="childrenItem.align || 'center'"
              :label="$t(childrenItem.label)"
              :key="childrenIndex"
              :prop="childrenItem.prop"
              :width="childrenItem.width"
              :fixed="childrenItem.fixed"
              :sortable="childrenItem.sortable"
            >
              <template slot-scope="scope">
                <!-- 自定义列模板 template设置为true 由父元素处理展示效果 -->
                <slot
                  v-if="childrenItem.template"
                  :name="childrenItem.prop"
                  :row="scope['row'] || {}"
                  :index="scope.$index"
                  :column="scope['column'] || {}"
                />
                <!-- 默认数据 -->
                <span v-else-if="!scope.row[childrenItem.prop] && column.defaultValue!== undefined">
                  {{ scope.row[childrenItem.prop] || (childrenItem.defaultValue === '暂无' ? $t('暂无') : childrenItem.defaultValue) }}
                </span>
                <!-- 处理过滤器过滤器情况 -->
                <span v-else-if="childrenItem.filterName">
                  {{ filterValue(scope.row[childrenItem.prop], childrenItem.filterName) }}
                </span>
                <!-- 正常渲染 -->
                <span v-else>{{ scope.row[childrenItem.prop] }}</span>
              </template>
            </el-table-column>
          </template>
        </el-table-column>
        <!--
            1. 自定义摸版
            2. 数据进行过滤器
            3. 正常展示数据
          -->

        <el-table-column
          :align="column.align || 'center'"
          :label="$t(column.label)"
          :key="index"
          :prop="column.prop"
          :width="column.width"
          :fixed="column.fixed"
          :sortable="column.sortable"
          v-else
        >
          <template slot-scope="scope">
            <!-- 自定义列模板 template设置为true 由父元素处理展示效果 -->
            <slot
              v-if="column.template"
              :name="column.prop"
              :row="scope['row'] || {}"
              :index="scope.$index"
              :column="scope['column'] || {}"
            />
            <!-- 默认数据 -->
            <span v-else-if="!scope.row[column.prop] && column.defaultValue!== undefined">
              {{ scope.row[column.prop] || (column.defaultValue == '暂无' ? $t('暂无') : column.defaultValue) }}
            </span>
            <!-- 处理过滤器过滤器情况 -->
            <span v-else-if="column.filterName">
              {{ filterValue(scope.row[column.prop], column.filterName) }}
            </span>
            <!-- 正常渲染 -->
            <span v-else>{{ scope.row[column.prop] }}</span>
          </template>
        </el-table-column>
      </template>
    </el-table>
    <!-- 若需要分页 就传递paginationAtr参数 -->
    <Pagination
      v-if="paginationAtr && tableAtr && tableAtr.data && tableAtr.data.length"
      :class="paginationAtr.className || 'page mt-10 mb-10'"
      @pageChange="handleCurrentChange"
      :current-page="paginationAtr.currentPage"
      :layout="paginationAtr.layout || 'prev, pager, next, jumper'"
      :total="paginationAtr.total"
      :pager-count="paginationAtr.pagerCount || 11"
      :page-size="paginationAtr.pageSize"
    />
  </div>
</template>
<script lang='ts' scoped>
import { Vue, Component, Prop } from 'vue-property-decorator'
import Pagination from '../Pagination/index.vue'

@Component({
  components: { Pagination }
})
export default class CommonTable extends Vue {
  @Prop() tableAtr: any;
  @Prop() columns: any;
  @Prop() paginationAtr: any;
  tableHeight: number = document.documentElement.clientHeight - 50;

  mounted() {
    if (this.tableAtr && !this.tableAtr.height) {
      this.getClientHeight()
    }
  }

  /* 获取屏幕宽度 */
  getClientHeight() {
    // 减掉50：分页高度
    const clientHeight = document.documentElement.clientHeight
    this.tableHeight = clientHeight - 50
  }
  // 分页-fun： 翻页
  handleCurrentChange(page: number) {
    if (typeof this.paginationAtr.currentChange === 'function') {
      this.paginationAtr.currentChange(page)
    }
  }
  // 过滤器
  filterValue(value: string, filter: any) {
    // // console.log(esNullFilter, 'esNullFilter');
    // return Vue.filter('esNullFilter')(value);
    /*
        filter: string or array
        参考：filter: 'esNullFilter' or
          [
            {
              name: 'dateStrFilter',
              arg: ['YYYY-MM-DD HH:mm']
            },
            'esNullFilter'
          ]
      */
    let val = value
    // eslint-disable-next-line prefer-reflect
    if (Object.prototype.toString.call(filter) === '[object Array]') {
      filter.forEach((item: any) => {
        if (typeof item === 'string' && Vue.filter(item)) {
          val = Vue.filter(item)(val)
        }
        if (typeof item === 'object' && Vue.filter(item.name)) {
          const { name, arg } = item
          val = Reflect.apply(Vue.filter(name), null, [val, ...arg])
        }
      })
    }
    if (Vue.filter(filter)) {
      val = Vue.filter(filter)(val)
    }
    return val === '暂无' ? this.$t('暂无') : val
  }
  // table-fun: 多选条件发生变化的时候会触发该事件
  handleSelectionChange(value: any) {
    if (typeof this.tableAtr.selectionChange === 'function') {
      this.tableAtr.selectionChange(value)
    }
  }
  // table-fun 排序条件发生变化的时候会触发该事件
  handleSortChange(prop: string, order: any) {
    if (typeof this.tableAtr.sortChange === 'function') {
      this.tableAtr.sortChange(prop, order)
    }
  }
}
</script>
<style lang="scss">
  .common-table-containers{
    height: 100%;
    display: flex;
  flex-direction: column;
    min-height: 350px;
    thead tr th {
      background-color: #f4f5f6;
    }
  }
</style>
