<template>
  <span>
    <span
      v-if="dataSource"
      class="toggle-box"
      ref="toggleBoxElememt"
      :style="{
        '-webkit-line-clamp': toggleOpen ? 1000 : (dataSource.lineClamp || 2),
        'max-height': toggleOpen ? '100%' : `${((dataSource.lineClamp || 2) * 23)}px`,
      }"
    >
      <slot name="toggleContent" />
      <span
        v-if="scrollHeight > ((dataSource.lineClamp || 2) * 23)"
        :class="['toggle-btn text-primary', {
          'toggle-btn-open': !toggleOpen,
        }, {
          'toggle-btn-close': toggleOpen
        }]"
        @click="changeOpen()"
      >
        {{ $t(toggleOpen ? '收起' : '展开') }}
      </span>
    </span>
    <slot
      v-else
      name="toggleContent"
    />
  </span>
</template>

<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'

@Component
export default class Toggle extends Vue {
  private scrollHeight: number = 0;
  private toggleOpen: boolean = false;

  @Prop() dataSource: any;

  // 更新内部状态
  @Watch('dataSource.updateStatus')
  updateToggleOpen() {
    if (this.toggleOpen !== this.dataSource.parentOpen) {
      this.toggleOpen = this.dataSource.parentOpen
    }
  }
  // dom元素发生变化 需要重新渲染高度
  @Watch('dataSource.updateHeight')
  updateHeightChange() {
    this.updateScrollHeight()
    this.toggleOpen = false
  }

  mounted() {
    if (this.dataSource) {
      this.updateScrollHeight()
    }
  }
  // 更新高度
  updateScrollHeight() {
    this.$nextTick(() => {
      this.scrollHeight = this.getScrollHeight()
    })
  }
  // 获取元素的高度
  getScrollHeight() {
    return (this.$refs.toggleBoxElememt as Element).scrollHeight
  }
  // 用户触发展开收起的change的回调
  changeOpen() {
    this.toggleOpen = !this.toggleOpen
    if (this.dataSource && typeof this.dataSource.change === 'function') {
      this.dataSource.change(this.toggleOpen)
    }
  }
}
</script>

<style lang="scss" scoped>
  .toggle-box{
    text-align: left;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    overflow: hidden;
    .toggle-btn{
      position: absolute;
      right: 0;
      bottom: -5px;
      cursor: pointer;
    }
  }
</style>
