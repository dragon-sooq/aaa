# 右下角 展开收起按钮

### 参数：
参数|说明|类型|是否必传 |
-|:-|-|-
dataSource | 需要传递的参数配置	| Object |  必传
||

### dataSource参数详情：
参数|说明|类型|是否必传 | 默认值
-|:-|-|-|-|
lineClamp | 最大行数（几行开始显示 展开收起）	| Number |  false | 2
updateStatus | 更新内部状态	| Boolean |  false | 
updateHeight | 内部dom 变更 重新渲染高度	| Boolean |  false | 
parentOpen | 外部作用此组件的展开收起	| Boolean |  false | 
|

> 详细说明一下：parentOpen对应内部状态：（true  收起）  （false 展开）

### event事件
事件名 | 说明 | 参数 
-|:-|-|
change | 点击内部展开收起触发的回调	| 当前状态 （true  收起）  （false 展开）

```
  <Toggle
    :data-source="{
      lineClamp: 3,
      updateStatus: toggleDataSource.updateStatus,
      updateHeight: toggleDataSource.updateHeight,
      parentOpen: toggleDataSource.parentOpen,
      change: (open) => changeOpen(open)
    }"
  >
    <span
      class="text-primary"
      slot="toggleContent"
    >
      自己要展示的内容
    </span>
  </Toggle>
```
