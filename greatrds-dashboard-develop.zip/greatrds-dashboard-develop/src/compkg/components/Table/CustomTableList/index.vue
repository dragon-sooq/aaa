<template>
  <div
    v-if="tableColumns && tableColumns.length"
    class="custom-list"
  >
    <el-table
      ref="customtable"
      v-loading="tableConfig.loading"
      :data="tableData"
      height="94%"
      size="small"
      style="width: 100%;"
      :highlight-current-row="true"
      :header-cell-style="getRowClass"
      @sort-change="handleSortChange"
      @selection-change="handleSelectionChange"
    >
      <template slot="empty">
        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAAAXNSR0IArs4c6QAAERtJREFUeAHtXQuMHVUZ/s99P3a3S1+7pW/IUmhpCkLZWoKIIhFMwWgMiQmRoCFqSNSg0cQQEySaiCEkRhJDbGJMLKIGAoiigICKigJZcWlti2232yfttvu673vH7597z71z587jzNzZ3RbmT2Zn5jz+c87/n/9x/jPnLlEIIQVCCoQUCCkQUiCkQEiBkAIhBUIKhBQIKRBSIKRASIGQAiEFQgqEFAgpcP5TQMzXEI68q22o1OgutLddI9qMhvs0TZu39v2Oc2a2QvlSlWo1qgHHf4Wg1zQhvjd8WWqvX5xO9eacICdOaAMFoh+jE586HxggiaVh1pw6W6JKpUqRiIlMQuQjGt2zdVN6pywf1N3UUlBo63jGj2vbKkRPEWnLgsU899gmIRksHbGodVuCRFlQdHjrpsSb1iX8pUb8VXOvNX5Su6Ii6PfnIzMgHDQ1U4Zk2I9TIy2uiepD9iX85Tg06Q8h14JqSlY0egwPi/xjWbiaGqwFbAa5qQ8wbjhoNTwnDDl8gu4FMzYsHEm7a7lWYxlRAE1LHzxISYWSykUCZwhmTBTD+aJqD3gWus1EVVxBlYtG6z1SYUssFmz3Y0ENQuIZO0nboF9Xy3eneyJOlGj0oFgmKsMD0Bk0zxwyCwRcW91+aJzRYI7TOILMC5whWFlcSSpTy2YUcfTIzrOxqdJ1cq7YiSIGV7fGvu88Q+AMERqtUh0GG88qLgY59hKkhK+FhmhMULU0/70InCGQkKqqhJSrUFO4zkWIwectYSiOIER1/yqCsg0OAjfqYMbZ4Lq3cJjYsLuorDMREl+5QYhA5TlwCYHqHTMbSTuyckRCLr7Y71etZ4cvyPR4PPJCLJ353PAGcSRIvG64AmcIiHrYrVGZD5exzcuqYa5FIbOSSbLcXN/ZuzNDNhVNb1w7v8zgPgTOEBB5rNKFVmWXk695AzsPRCMl1z3ofgY+dF4YYi1S5LtbZ43SUIX9VFVZhZJGh46VqFSuu2gCHFy8KEoXLsXCJiAAzsqa5ZTCvcOy53LaSgjVNfAMt6DpHlxTcGbe6E3S8yiP4LZ/CFxC0JUeXKdwDbh1i11e6fa6lTXm7zlYoNl8w19uZEzOVCmViNDiPtd5YERl+4wJFTs6IS5EAV0Fz5a0D0Dyb8P7jrKGtVYD2F2XLvtUnmam89qDPSn6gV/GBCYhkwVtSNToPvTzM1OzlKpU7XSBHIr/+9/+PWspTWtWJGj18uCkJJUUX00naQg9vRXeo7IKg8TsiQu6JZ0WB7yOsmsJwUyKT+fpfuyn3YuZolNDN8odgt7ZNV6Ry1U5G1ZVaYlh0VbCNDVDMuAwB1Tqw6prKmNfQIdL0b1Xp4vajb1JMWrMc3vuiiHQpauncvQEGrnK2JB5g82YZ3xmxkmGSPWlh05cVkdJTD8rhmTTgtIJYwvuz8zWgs2KnF1xvwC8g1qVnp7StK19QpxWxeObIQ2d+gwaWmFuTLgQ1Fze+K4bdxdCsIRYQRQzIciwC4d2ugKN1ms52gUcN6ni8cWQyZw2DAP3BzTSZ9UQe08qUIZ7XGmsAaRh1D2tTm3Uhi5uxxCoLFW114bQ5iUgM/ixqbx2V19a7LRppi1ZkXStOrOz2tXQq88hxZIZXFIVKdOdGcCXCw8YbROsGAJDSnGosiBB1Q13axOS9kOoriVu5ThflXY6rkJBuwi2+rd4cdya7UZl6Q25/ElYEN6KSS5oXLO7sSEm5BdQnr5pSrN8VWYIvKnFpRo9i5m83BKTIZGNOr7KMKRYP/LmVDZVv+Ielg9WxLdiknWr6qkYsyfJdcF8z4ymDbqUUQudoGMReFO/BDLlfXKWElejyIyTfGvck3Cc2dNyghI+wDFDJoklc9qc6v7OtmvWYW3NYwhC4tFOupqjL6FH33HqlcvQ61Wnc/QAnm50QmTOY8PuKvIghjTm8s5buXw5QbXaKdjsYc3knWr5y2MnIahgJybf5zG577cKx8jedY5M5jTuU7PardA+3zIlu76qrEXYReXZyRc+EFQGK+ONcLlyfS8FXaXcAzJMupWY3Lc4VXEcBTwqjuXsBKJOHeGEFXlNVeRSzk82LybNDJ8LG8J9a8Qv/XTTrs7ddhmcbssQiJaoCvo5tIqSu2ZuRGUtwkxjdcCXV44v6W9pW27rgl4PXoG5sw7vXiTXAU0rS9DNiHCsaiW0P7VG1Z5OiE9xbOojpmTlVxUJYeNt/gxI99AUuLNhbVJnQgmfSC4Dc9Iw6n7BaTEpbZtf3OZ6wBetROgOpH/fnMfvlqPI57X1CI6NorIPv6XeDBv0yVnIlwNYfZfF7m90bia7bU/sYln1CgKMt63qKwOT9R99GbHNqrKlhEBv/gik9M0MbkjFVWSmye1T6ZGdy1+iWBHQZ9o1WJMMYGfrhLl+B0PgVe0AMz5hLuj1nUUP7h3cWnspYf3sV0fvOVCgiam6axaBRG1cl6a+HhiTwEGD+y4Cc325eyCJqBV0Gu80d7djBNiKvM9cyO+7imH3i/s0mMGs5osjxJOzdeb4xedUj/EHDho2vSygjSEzee2jGOFWi3K+ktwMOzOMjTpfQS2+fHXUpRKO4gUOmEg3QnsgcNQObSoLevxr7dndvfEGntOim4239LI0FGQ7wmsMFcniusaZyyEXvvyAa2TAXuv6aa5eR6PsbJGuxwtHzpvQZAi4tRiu7k1BRtNUDHuzJ40HNjnSwJvzjO+bL07R2WmeuvAj4SsPLokr1TPi4GcnWrOEc3+CXK0b28c4b8C7NUOmC3wos74nbqzUzbObGuLNKUl8uRbgu4rKzqajxJcEfV9FpaKsYLqzE8LrIr6ifHGCviqAUXfimgmPx9frzeWbEoKp0rVnZUbu9s1Bt0Q0t+f3PYl9+BSuiKXRg4elM8cvdsd6V0EzZeGNzspSRoYMy8Sg7n5UVlBtq+Bh+nPIPmaYOawGj52uQB1W8fED9kMgHcmEoP5slJYviSIq0JJKlTacyrBGgh35IMo8L8vpDMHKfA02n1bIxKDu9ZnF08ta5lk9yK9OeIHod03ip7/ct54MOxD16X92pkZvHyjSxGSn3sshGn0GbvaBY0S9YMxl6xK0/IJgGAPHhNVWO0MQRLzEz6BU6vB47XQwz1DpUeEItQ4cTpFMUsHvpQzbKw6TcFNZSIZkxtjxCr31TtFxESvbmcZ657XRPF2yJqFfMt3vHTRosyO6hODrisClQ3aQDXutc9LJ7I57Ce6vDKd0ZHab0BDUFLx/qaYOMTP2QwQawFvPqwZitGJJDExD58G9fKFGJ85UaexYGV+11JHsHcNxHjCYpaVLuBp2JAY7Ah2BfvEfHEMbaPSVXwMF3dOyYQgTny8zsN6eK2CJTDXWK6ym/gPJkMAMuPKSFPX3opABcDSBlsJ2rBuM05t7C7p94ex3xkvU3xOlFUv9qy+MNZ3L0Rage51xypb9Y2QsDtBQ0Q4l5jervnis68e3/9dSUz1gxoeuzHQww9g7/jLy2i1pMEefx3oW2x07lWys6/QMQWs6VJIhNnPYCY1anttaRA1LcKXYRjGcmao1g5Ospq6AZEh7Vi9h/ZdZuWUo2VR5+WKNjp7UtY11BYVUxA+boXidIVBZc/B5QL0n5xJDYhgtR6AZ2LWVsHow5igZspy882bY0OqW7TDikmU83psSosseVPa4RwTN4hxPmoLnIY1dM6PxwJ5N0eJLdXO5+XjPpJgZdXXDbqyEQRhwrzC4NEa7D9btD9uiLmGIQ1eYLBN6TyJxOlS1MK4qjRw6XmyeZFIpv5BlEoav8YyThO2HV8iCuSxtICQV9QUkNjka0ucVF1AIxBEvRb1X9Z5k47QXuFoyrIiRjwTIY2WKVRa2mMF7kzE07pBftVpXfoyh+y8cwYi1el/4DzibA5dG+NkLyIWVlzoLWdZ4qiuNcIiEXMHAKZnocmepkOfYeU1jHQdzQWLIhtJbxa8tWRX0qiFf6ZH3JPyKqVIDARfiL1Qk9Bq2e09OeFYOdHKiZYP6g/kESUfYZAhcPj584xnihsCc58rzXIFndbmx/Te4uGXID2IF7kVKOObGK3UJgcS1BE0zviZDskl6Ee9nZCOqd7vTTKr157vcdK4+s5chOKiHRtABVmUj+1rhE7c+jWJBmUc0loHV1eoBn1uVxoZqdJxfmwyB6uH43q+MZVSeUxZnNVTqLVSZ05MVXfezQ7RxfbLZjdOI8r72dkH3mJqJpgeWjJH9RTp8ouWSbkCQkaPW3YLI0N8ZR5Mh+kucHvGKOJuZs6iL164oled10wSYwjCwOEoXrWwt8NiWvPRGjg4cLUMCWvaG423jJyr0MvIOH28xg+Nb61d2Lx2YHPt6hXiX+9TG256EGJnKaX+Gx3UdZ6pABj58Egf2iw0RVqmz0GVOna3gtG6EeDJtXJ/Q98wP4JchGMow/KyS+OLf62VJqlocNuS8PLwztku8gdUNgN67ZP0OTDigeB029V+RBVTu7L0cOlq0Xa2r4JjvMrz2WD2QwDfBdQk/gnjU7oMl7Jc4r7p58l0MqeCNrOOQqJ5MRP+2eN2FcZwG6yCn67DA8CqkYl0mI8a5sCUGSMmvwbVPu2IzFGCmnDxdxqGZutE0ZJ2zjzx4/lplUW9dUfD+xjgYw4Q+i9AKSwsDS0M/3OQVy2K0FgacmckR3n+OFuhdSBtDJhmh7YgEpzxKC/rws76suFNHgj+WDOHDnZgou8GUloKVNVzuvHpnD6Rsil/N5/asSxfbsjFGXeX0Yqabzy5yHv9krPyV0raKeBl9p4Rt3Zb7y9Jy7eYMTgObS9q+T0YztMH4ja8lQ7g6pORBdOjrtqjCDP0jiL+O5IlD8BJ4w4r3TNj2uAE+Arkb59cfNZaD8FlDb5oeAE5s64dgRwFWT9suT+tOjSyTA3NUtAFou9PMDMZhyxCsSybBwc+y0ZGNhfdOCvAu4vCmlK7u+OehtrPKavNdO+uApi/3ZujLnTk2NsRYEL//9G1ERh8wpoXPnRTIF+uftModyc4S9RQw40Vonx0c0LUq46rpEO8XOKP+LCp/3ApBmOaBAoIe70vTnWCG7Q6trcqSzaCyhmX9HeCs7ifL9PCuTgHQroLr3kUZcbsTMxijK0O4EH7v6RROKfH56gl+D0GdAmDEK5EYXY0zhQ+p1HJVWUYk/EtAWAa9gDTbXwIyln9fP+P3izHbv9GbEY97oYMnhjBirE+uxXrpOexaZr009L4pK+gQpOInvSl62E09WdHEM0MYCR99wwL2GSwcU1ZIFyxN0CwG9BbiDyP4Qc4RKORRXKdjNZoGkRI4H95TK9M6uPOb4Dlej7QPYwzq62qbgQEPx4afxCbfT7GvxD8V21op2tSxS/bFEEYGSdkOKXkCHXH9uSa7xgNKfxN4noHr/3QmQ697IQY8yEX4wZqbQb3bMJabgcfxd8CM/QUTjmDsL+H+J0zLJ738rqIRj/nZN0MYEY4xrMWZ9qfRsc1mxHP1DgKgOfoLPu7bhc26pxAlPRJEW2BOZKpIF2NuXw58Q2ilH18U9kHaomiLJWwGDY+DYPsjKdqHUzZzEsXoiiFMCAykFz8g/CgGcHsQhLHDgY6OgDi/wAblY/g93DG7cud7etcMkQTADw58Es+PYBYFd7RB0H4wehfcxl34/dvdsq338j0whjCRIC39kJbvAukX/Br8hiT8Dv9Z7DfZrPjXe5n4VmMLlCGygWlNW04Fuhue2A40sBXMsWwHerkACdgHXf0Wnv8YTdFzc6WbZd/O9bsloYLsNEsNDqQM4edC1uPizzwEjPFJSMAenGQa8+IVBdmvEFdIgZACIQVCCoQUCCkQUiCkQEiBkAIhBUIK1Cnwf4bWaWVqqB/FAAAAAElFTkSuQmCC">
        <p>
          <span style="color: #332f2f;">
            暂无数据
          </span>
        </p>
      </template>
      <el-table-column
        v-if="tableConfig.isMultiple"
        fixed="left"
        type="selection"
        width="55"
        align="center"
      />
      <el-table-column
        v-if="tableConfig.isSerialNumber"
        fixed="left"
        width="50"
        align="center"
        label="序号"
      >
        <template slot-scope="scope">
          <span>
            {{ ((pageConfig.currentPage - 1) * pageConfig.pageSize) + (scope.$index + 1) }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        v-for="(item, index) in tableColumns"
        :key="index"
        :show-overflow-tooltip="item.prop !== 'templateName'"
        :prop="item.prop"
        :label="$t(item.label)"
        :sortable="item.sortable || false"
        :fixed="item.fixed"
        :width="item.width"
        :align="item.align"
        :resizable="false"
        max-width="200"
      >
        <template slot-scope="scope">
          <!-- 自定义列模板 template设置为true 由父元素处理展示效果 -->
          <slot
            v-if="item.template"
            :name="item.prop"
            :scope="scope"
          />
          <!-- 正常展示数据 -->
          <template v-else>
            <span
              v-if="!Array.isArray(scope.row[item.prop])"
              :class="{
                'text-primary cursor-p': scope.row[item.prop] && item.click
              }"
              @click="scope.row[item.prop] && item.click && item.click(scope.row)"
            >
              <!-- 通用状态 -->
              <template v-if="item.prop === 'status'">
                <i 
                  class="fa fa-yuandian font-12"
                  :class="{
                    'text-warning': scope.row.status === 0 || scope.row.status === '0' || scope.row.status === 'down',
                    'text-success': scope.row.status === 1 || scope.row.status === '1' || scope.row.status === 'up'
                  }"
                />
                {{ scope.row.status === 0 || scope.row.status === '0' || scope.row.status === 'down' ? '已停用' : '已启用' }}
              </template>
              <!-- 正常显示 -->
              <template v-else>
                {{ filterValue(scope.row[item.prop], item.filter) }}
              </template>
              <!-- 预警标识 -->
              <el-tag
                v-if="item.prop === 'severity'"
                :type="scope.row[item.prop] === 'critical' ? 'warning' : (scope.row[item.prop] === 'major' ? 'danger' : scope.row[item.prop] === 'minor' ? 'info' : 'success') "
                size="mini"
              >
                <i class="fa fa-notice font-12" />
              </el-tag>
            </span>
            <template
              v-else-if="Array.isArray(scope.row[item.prop])"
            >
              <el-popover
                v-if="scope.row[item.prop].length"
                placement="right"
                width="200"
                trigger="hover"
              >
                <ul
                  class="popover-list"
                >
                  <li
                    v-for="(val, key) in scope.row[item.prop]"
                    :key="key"
                    :class="{'text-primary cursor-p': item.click}"
                    @click="item.click && item.click(val)"
                  >
                    {{ val[item.aliasName] }}
                  </li>
                </ul>
                <span
                  slot="reference"
                  class="text-primary"
                >
                  {{ filterValue(scope.row[item.prop][0][item.aliasName], item.filter) }}
                </span>
              </el-popover>
              <span v-else>
                {{ $t('暂无') }}
              </span>
            </template>
          </template>
        </template>
      </el-table-column>
      <!-- 自定义操作 -->
      <el-table-column
        v-if="tableConfig.operate"
        fixed="right"
        :label="$t((tableConfig.operate.label || '操作'))"
        width="160"
        :align="(tableConfig.operate.align || 'left')"
      >
        <template slot-scope="scope">
          <el-tooltip
            v-for="(item, index) in tableConfig.operate.list"
            :key="index"
            effect="dark"
            :disabled="!item.tooltip"
            :content="item.tooltip"
            placement="top"
          >
            <!-- {{ item }} -->
            <el-button
              type="text"
              :size="item.size || $root.commonSize"
              @click="item.click && item.click(scope.row)"
            >
              <i
                class="fa"
                v-if="item.icon"
                :class="item.icon"
              />
              <el-link
                v-else
                :underline="false"
                :type="item.type"
              >
                {{ item.name }}
              </el-link>
            </el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <slot
      name="footer"
      class="footer"
    >
      <!-- 分页 -->
      <el-pagination
        v-if="pageConfig"
        :page-size="pageConfig.pageSize"
        :page-sizes="[20, 50, 100, 200]"
        :pager-count="5"
        layout="total, sizes, prev, pager, next, jumper"
        :current-page.sync="pageConfig.currentPage"
        :total="pageConfig.totalCount"
        @current-change="handleCurrentChange"
        @size-change="handleSizeChange"
      />
    </slot>
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { Getter } from 'vuex-class'

@Component
class CustomTableListComponent extends Vue {
  @Prop() tableConfig: any;
  @Prop() pageConfig: any;
  // @Prop() category: any; // 没有分类显示情况下表格最大高度加高

  @Watch('tableConfig.data', { immediate: true, deep: true })
  onTableData(data: any) {
    this.tableData = data
  }

  @Watch('tableConfig.columns', { immediate: true, deep: true })
  onTableColumns(columns: any) {
    this.tableColumns = columns
    this.$nextTick(() => {
      this.$refs.customtable && (this.$refs.customtable as any).doLayout()
    })
  }
  // @Getter asideCollapse;

  // @Watch('asideCollapse')
  // onAsideCollapse() {
  // 修复：侧边栏菜单收起、展开，table自适应
  //   setTimeout(() => {
  //     if (this.$refs.customtable) {
  //       (this.$refs.customtable as any).doLayout()
  //     }
  //   }, 350)
  // }

  private tableData: Array<object> = this.tableConfig.data;
  private tableColumns: Array<object> = this.tableConfig.columns;
  // private tableMaxHeight: string = (window.innerHeight - (this.category ? 320 : 170)) + 'px';

  mounted() {
    this.bindWindowResizeEvent()
  }

  /**
   * 绑定window缩放事件绑定
   */
  bindWindowResizeEvent() {
    // 解决左侧收起，在F12下会导致表格显示异常
    window.onresize = () => {
      if (this.$refs.customtable) {
        (this.$refs.customtable as any).doLayout()
      }
    }
  }

  getRowClass() {
    return 'background:#f0f3fb;color:#4c5360;font-size:9px;font-weight:500;height: 30px;'
  }    

  /**
   * 过滤器
   * @param value 展示数据
   * @param filter 过滤器名称
   * @returns 过滤后的展示数据
   */
  filterValue(value: string, filter: any) {
    /**
     * filter: string or array
        参考：filter: 'esNullFilter' or
        [
          {
            name: 'dateStrFilter',
            arg: ['YYYY-MM-DD HH:mm']
          },
          'esNullFilter'
        ]
    */
    let val = value
    if (filter) {
      if (Vue.filter(filter)) {
        val = Vue.filter(filter)(val)
      } else if (Array.isArray(filter)) {
        filter.forEach((item: any) => {
          if (typeof item === 'string' && Vue.filter(item)) {
            val = Vue.filter(item)(val)
          }
          if (typeof item === 'object' && Vue.filter(item.name)) {
            const { name, arg } = item
            val = Reflect.apply(Vue.filter(name), null, [val, ...arg])
          }
        })
      }
    }
    return val
  }

  /**
   * 排序条件发生变化的时候会触发该事件
   * @param sort 排序对象
   */
  handleSortChange(sort: object) {
    if (typeof this.tableConfig.sortChange === 'function') {
      this.tableConfig.sortChange(sort)
    }
  }

  /**
   * 当选择项发生变化时会触发该事件
   * @param val 已选数据
   */
  handleSelectionChange(val: Array<Object>) {
    if (typeof this.tableConfig.selectionChange === 'function') {
      this.tableConfig.selectionChange(val)
    }
  }

  /**
   * currentPage 改变时会触发
   * @param currentPage 当前页数
   */
  handleCurrentChange(currentPage: number) {
    if (typeof this.pageConfig.change === 'function') {
      this.pageConfig.change(currentPage)
    }
    // table滚动到顶部
    this.$nextTick(() => {
      this.$refs.customtable && ((this.$refs.customtable as any).bodyWrapper.scrollTop = 0)
    })
  }

  /**
   * currentPageSize 改变时会触发
   * @param currentPageSize 当前显示条数
   */
  handleSizeChange(currentPageSize: number) {
    if (typeof this.pageConfig.change === 'function') {
      this.pageConfig.pageSizeChange(currentPageSize)
    }
    // table滚动到顶部
    this.$nextTick(() => {
      this.$refs.customtable && ((this.$refs.customtable as any).bodyWrapper.scrollTop = 0)
    })
  }
}
export default CustomTableListComponent
</script>
<style lang="scss" scoped>
.custom-list {
  display: flex;
  flex-direction: column;
  padding: 15px !important;
  .el-table__empty-text {
    line-height: 30px;
  }
  .el-pagination{
    padding: 10px 5px;
    box-sizing: border-box;
    text-align: right;
    background: #fff;
  }
}
// 供关联表、字典使用
.popover-list{
  max-height: 200px;
  overflow-y: auto;
  & > li{
    width: 100%;
    padding: 5px 0;
    box-sizing: border-box;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
}
</style>
