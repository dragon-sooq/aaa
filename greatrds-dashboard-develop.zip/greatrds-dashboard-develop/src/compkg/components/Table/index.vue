<template>
  <div
    class="table-list-container"
    :style="{height: height}"
  >
    <!-- 顶部Tab、Search -->
    <CustomHeader
      :tabs-config="dataSource.tabsConfig"
      :search-config="dataSource.searchConfig"
      :btn-config="dataSource.btnConfig"
      :table-data.sync="dataSource.tableConfig.data"
    />
    <!-- 自定义表格数据 -->
    <CustomTableList
      v-if="dataSource.tableConfig"
      :table-config="dataSource.tableConfig"
      :btn-config="dataSource.btnConfig"
      :page-config="dataSource.pageConfig"
    >
      <template
        v-for="(item) in tableSlot"
        v-slot:[item.prop]="{scope}"
      >
        <slot 
          :name="item.prop" 
          :scope="scope"
        />
      </template>
    </CustomTableList>
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import CustomHeader from './CustomHeader/index.vue'
import CustomTableList from './CustomTableList/index.vue'

@Component({
  components: {
    CustomHeader,
    CustomTableList
  }
})
export default class WorkTableChoose extends Vue {
  @Prop() dataSource: any;
  private height: any = this.dataSource.onlyHeader ? '10%' : '100%';
  handleChangeCategory(categoryId: number) {
    if (typeof this.dataSource.categoryConfig.change === 'function') {
      this.dataSource.categoryConfig.change(categoryId)
    }
  }

  get tableSlot() {
    return this.dataSource.tableConfig.columns.filter(
      (item) => item.template
    )
  }

}
</script>
<style lang="scss" scoped>
.table-list-container{
  height: 100%;
  display: flex;
  flex-direction: column;
  .custom-header, .custom-category{
    flex-shrink: 0;
  }
  .custom-list{
    flex: 1;
    height: 0;
  }
}
</style>
