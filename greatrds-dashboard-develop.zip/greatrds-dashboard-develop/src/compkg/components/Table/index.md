  # 通用列表组件

  ## 参数

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | data-source | 数据配置源 | object | - | 1 |  |

  ### data-source

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | tabsConfig | tab配置 | object | {} | 0 |  |
  | btnConfig | 列表上方按钮配置 | object | {} | 0 |  |
  | searchConfig | 搜索配置 | object | {} | 0 |  |
  | tableConfig | 表格配置 | object | {} | 1 |  |
  | pageConfig | 分页配置 | object | {} | 0 |  |

  #### tabsConfig - Object

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | activeName | 已选name | string | '' | 1 |  |
  | list | tab列表 | array | [] | 1 |  |
  | change | 切换tab回调 | function | - | 0 |  |

  #### btnConfig - Object

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | list | button数组，需要传递按钮type: 'primary'，图标icon: '' 名字name: '', 按钮大小size: '', 是否显示按钮背景色（朴素按钮）plain: true || false | array | [] | 1 |  |
  | dropdownList | dropdown类型按钮 | button数组，需要传递[{titleName: '操作', list: [{编辑, 删除}]}] | 无 | 非必传 |
  | left | 当同时传了list和dropdownList时传递该属性,作用是dropdown按钮显示在左侧还是右侧 | boolean | false
  | change | 点击按钮回调 | function | - | 0 |  |

  ##### searchConfig - Object

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | placeholder | 输入框提示性描述 | string | '' | 0 |  |
  | remote | 远程搜索 | boolean | false | 0 |  |
  | change | 远程搜索时必传 搜索回调 | function | 本地搜索 | 0 |  |

  ##### tableConfig - Object

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | isMultiple | 是否可多选 | number | 0 | 0 |  |
  | isSerialNumber | 序列号 | number | 0 | 0 |  |
  | columns | 列配置 | array | [] | 1 |  |
  | data | 表格数据 | array | [] | 1 |  |
  | operate | 操作配置 | array | [] | 0 |  |
  | sortChange | 排序回调 | function | - | 0 |  |
  | selectionChange | 多选回调 | function | - | 0 |  |

  ##### pageConfig - Object

  | 参数 | 说明 | 类型 | 默认值 | 必传 | 版本 |
  | --- | --- | --- | --- | --- | --- |
  | currentPage | 当前页 | number | - | 1 |  |
  | pageSize | 展示条数 | number | - | 1 |  |
  | totalCount | 总条数 | number | - | 1 |  |
  | change | currentPage 改变时会触发 | function | - | 1 |  |

  ## 调用示例

```html
<!-- 调用选择 -->
  <EsWorkTable
    :data-source="tableDataSource"
  />
<!-- ./调用选择 -->
```

```javascript
tableDataSource: Object = {
  tabsConfig: {
    activeName: '全部',
    list: [{
      id: 1,
      label: '全部',
      name: '全部'
    }, {
      id: 2,
      label: '固定格式表',
      name: '固定格式表'
    }, {
      id: 3,
      label: '单人工作表',
      name: '单人工作表'
    }],
    change: (tabName: string) => {
      console.log(tabName);
    }
  },
  searchConfig: {
    placeholder: '请输入工作表名称编码',
    remote: true,
    change: (search: string) => {
      console.log(search);
    }
  },
  tableConfig: {
    isSerialNumber: 0,
    columns: [
      {
        label: '编码',
        prop: 'code',
        fixed: 'left'
      }, {
        label: '名称',
        prop: 'name',
        sortable: 'custom',
        click: () => {
          console.log(888);
        }
      }, {
        label: '类型',
        prop: 'businessType'
      }, {
        label: '类别',
        prop: 'category1Name'
      }, {
        label: '状态',
        prop: 'name',
        sortable: 'custom'
      }, {
        label: '简介',
        prop: 'description',
        filter: 'esNullFilter'
      }, {
        label: '共关联工作表',
        prop: 'form',
        width: 150,
        menuChange: (item) => {
          console.log(item);
        }
      }, {
        label: '字典',
        prop: 'name'
      }, {
        label: '创建人',
        prop: 'create_user_name'
      }, {
        label: '创建时间',
        prop: 'create_time',
        sortable: 'custom',
        filter: [
          {
            name: 'dateStrFilter',
            arg: ['YYYY-MM-DD HH:mm']
          },
          'esNullFilter'
        ]
      }, {
        label: '更新人',
        prop: 'update_user_name'
      }, {
        label: '更新时间',
        prop: 'update_time',
        sortable: 'custom',
        filter: [
          {
            name: 'dateStrFilter',
            arg: ['YYYY-MM-DD HH:mm']
          },
          'esNullFilter'
        ]
      }
    ],
    data: [
      {
        businessType: '5',
        category1Id: '5aaf34515d332d30d888ea63',
        category1Name: '销售管理',
        category2Id: '5aaf34515d332d30d888ea63',
        category2Name: '销售管理',
        changeTime: 1575426481708,
        code: '1812131734',
        company_id: '406',
        create_time: '1544694789498',
        create_user_id: '7844',
        create_user_name: '卫欢乐',
        description: '',
        dic: null,
        fixed: false,
        form: [{
          id: 1,
          name: '销售部工作日志'
        }, {
          id: 2,
          name: '销售部工作日志1'
        }],
        form_type: '5',
        isRelationOrder: false,
        isSetAlarm: '0',
        layout: 1,
        name: '销售相关工作日报-模板',
        status: 0,
        template_status: 2,
        update_time: '1575426481708',
        update_user_id: '7844',
        update_user_name: '泯谚',
        version: '1.0.20',
        _id: '6a8f380af28f4a81bc1c051a0bdbdacc'
      }
    ],
    operate: [
      {
        icon: 'fa-bianji',
        click: (item) => {
          console.log(item);
        }
      },
      {
        icon: 'fa-yujingtixing',
        click: () => {}
      },
      {
        icon: 'fa-shanchu text-danger',
        click: () => {}
      }
    ],
    sortChange: (item) => {
      console.log(item);
    }
  },
  pageConfig: {
    currentPage: 1,
    pageSize: 10,
    totalCount: 100,
    change: (currentPage: number) => {
      console.log(currentPage);
    }
  }
}
```