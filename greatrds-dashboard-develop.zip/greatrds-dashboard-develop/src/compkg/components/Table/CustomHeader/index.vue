<template>
  <!-- 顶部Tab、Search -->
  <div 
    class="custom-header"
    v-if="tabsConfig || searchConfig || btnConfig"
  >
    <Tabs
      v-if="tabsConfig"
      :tab-list="tabsConfig.list"
      :default-active-name="tabsConfig.activeName"
      :change-tab="handleChangeTab"
    />

    <!-- <DatetimeSearch
      class="search-box"
      style="width:330px"
      v-if="searchConfig"
    /> -->
    <el-row
      v-if="btnConfig && btnConfig.left"
      class="app-actions"
    >
      <!-- v-permission="item.permission || []" -->
      <template v-if="btnConfig.dropdownList">
        <el-button
          v-for="(item, key) in btnConfig.list"
          :key="key"
          :type="item.type"
          :plain="item.plain || false"
          :size="item.size || $root.commonSize"
          :icon="item.icon"
          :disabled="item.disabled || false"
          @click="handleClickBtn(item.name)"
        >
          {{ item.name }}
        </el-button>

        <el-dropdown
          v-for="(item, key) in btnConfig.dropdownList"
          :key="'dropdown-' + key"
          class="ml-10"
        >
          <el-button
            type="primary"
            :size="item.size || $root.commonSize"
            :icon="item.icon"
          >
            {{ item.titleName }}
            <i class="el-icon-arrow-down el-icon--right" />
          </el-button>
          <el-dropdown-menu
            slot="dropdown"
          >
            <el-dropdown-item
              v-for="(childItem, childKey) in item.list"
              :key="'dropdown-item-' + childKey"
              :disabled="childItem.disabled"
              @click.native="handleClickBtn(childItem.name)"
            >
              {{ childItem.name }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </template>
    </el-row>

    <el-row
      v-else-if="btnConfig && !btnConfig.left"
      class="app-actions"
    >
      <!-- v-permission="item.permission || []" -->
      <template>
        <el-dropdown
          v-for="(item, key) in btnConfig.dropdownList"
          :key="'dropdown-' + key"
          class="mr-10"
        >
          <el-button
            type="primary"
            :size="item.size || $root.commonSize"
            :icon="item.icon"
          >
            {{ item.titleName }}<i class="el-icon-arrow-down el-icon--right" />
          </el-button>
          <el-dropdown-menu
            slot="dropdown"
          >
            <el-dropdown-item
              v-for="(childItem, childKey) in item.list"
              :key="'dropdown-item-' + childKey"
              :disabled="childItem.disabled"
              @click.native="handleClickBtn(childItem.name)"
            >
              {{ childItem.name }}
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>

        <el-button
          v-for="(item, key) in btnConfig.list"
          :key="key"
          :type="item.type"
          :plain="item.plain || false"
          :size="item.size || $root.commonSize"
          :icon="item.icon"
          :disabled="item.disabled || false"
          @click="handleClickBtn(item.name)"
        >
          {{ item.name }}
        </el-button>
      </template>
    </el-row>
    <DelayedSearch
      v-if="searchConfig"
      class="search-box"
      style="margin-right: 20px"
      :search-text="searchConfig.searchText"
      :placeholder="searchConfig.placeholder"
      @change="handleSearchKeyWordChange"
    />
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import Tabs from '../../Tabs/index.vue'
import DelayedSearch from '../../DelayedSearch/index.vue'
import DatetimeSearch from '../../DatetimeSearch/index.vue'

@Component({
  components: {
    DelayedSearch,
    DatetimeSearch,
    Tabs
  }
})
class CustomHeaderComponent extends Vue {
  @Prop() tabsConfig: object;
  @Prop() searchConfig: object;
  @Prop() btnConfig: object;
  @Prop() dropDownList: object;
  @Prop() tableData: Array<object>;
  

  /**
   * tab切换变更时触发
   * @param tab 选中tab的name
   */
  handleChangeTab(tab: string) {
    if (typeof this.tabsConfig['change'] === 'function') {
      this.tabsConfig['change'](tab)
    }
  }

  /**
   * 搜索输入框内容发生变化
   * @param searchVal
   */
  handleSearchKeyWordChange(searchVal: string) {
    // 是否开启远程搜索 
    if (this.searchConfig['remote']) {
      this.searchConfig['change'] && this.searchConfig['change'](searchVal)
    } else { // 本地搜索
      let resList = this.tableData.filter((item) => !searchVal || item['name'].toLowerCase().includes(searchVal.toLowerCase()))
      this.tableData = resList
    }
  }

  /**
   * 按钮点击触发事件
   * @param btnName 选中按钮的name
   */
  handleClickBtn(btnName: string) {
    if (typeof this.btnConfig['clickBtn'] === 'function') {
      this.btnConfig['clickBtn'](btnName)
    }
  }

}
export default CustomHeaderComponent
</script>
<style lang="scss">
.custom-header{
  .es-table-web{
    .el-tabs__header{
      margin: 0;
      color: #ffffff;
    }
    .el-tabs__nav-wrap{
      padding-left: 10px;
      box-sizing: border-box;
    }
    .el-tabs__item{
      height: 50px;
      line-height: 50px;
      color: #666;
    }
    .el-tabs__item.is-active{
      color: #526ECC;
    }
  }
}
</style>
<style lang="scss" scoped>
.custom-header{
  position: relative;
  min-height: 50px;
  .app-actions {
    padding: 10px 15px;
    margin-bottom: 0;
    border-top: 1px solid #dce0e6;
    border-bottom: 1px solid #dce0e6;
    color: #7f8fa4;
    height: 51px;
  }
  .search-box{
    width: 300px;
    position: absolute;
    right: 0;
    top: 9px;
  }
}
</style>
