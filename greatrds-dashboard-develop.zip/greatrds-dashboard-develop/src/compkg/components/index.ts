import DialogLayerComponent from './DialogLayer/index.vue'
import DrawerComponent from './Drawer/index.vue'
import DelayedSearchComponent from './DelayedSearch/index.vue'
import DownExcelComponent from './DownExcel/index.vue'
import PageHeaderComponent from './PageHeader/index.vue'
import TabsComponent from './Tabs/index.vue'
import TableComponent from './Table/index.vue'
import CommonTableComponent from './CommonTable/index.vue'
import MenuComponent from './Menu/index.vue'
import HeaderBannerComponent from './HeaderBanner/index.vue'

export class DialogLayer extends DialogLayerComponent { }
export class Drawer extends DrawerComponent {}
export class DelayedSearch extends DelayedSearchComponent { }
export class DownExcel extends DownExcelComponent { }
export class Table extends TableComponent { }
export class CommonTable extends CommonTableComponent { }
export class PageHeader extends PageHeaderComponent { }
export class Tabs extends TabsComponent { }
export class Menu extends MenuComponent { }
export class Banner extends HeaderBannerComponent { }

