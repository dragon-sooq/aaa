<template>
  <div class="pagination-containers">
    <span class="total-text">
      <span class="page-text">{{ currentPage * pageSize > total ? total : currentPage * pageSize }}</span>
      / 共{{ total }}条
    </span>
    <el-pagination
      :class="className || 'page'"
      @current-change="handleCurrentChange"
      :current-page="currentPage"
      :layout="layout || 'prev, pager, next, jumper'"
      :total="total"
      :pager-count="pagerCount || 11"
      :page-size="pageSize"
    />
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class Pagination extends Vue {
  @Prop() className: string;
  @Prop() layout: string;
  @Prop() currentPage: number;
  @Prop() pagerCount: number;
  @Prop() total: number;
  @Prop() pageSize: number;

  get current() {
    return (this.pagerCount || 1) * (this.pageSize || 10)
  }
  handleCurrentChange(page: number) {
    this.$emit('pageChange', page)
  }
}
</script>
<style lang="scss" scoped>
  .pagination-containers{
    position: relative;
    text-align: center;
    margin-top: 10px;
    padding: 10px 0;
    background: #fff;
    .total-text{
      position: absolute;
      top: 50%;
      font-size: 14px;
      margin-top: -10px;
      left: 10px;
    }
    .page-text{
      color: #526ECC;
    }
  }
</style>
