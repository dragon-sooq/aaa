#  导出Excel

### 参数：
参数|说明|类型|是否必传 |
-|:-|-|-
url | 接口	| string |  必传
ajaxData | 请求的参数 | object | 必传
text | 导出按钮的文案 | string | 可选
downName | 下载的文件名 | string | 可选
downLoadType | 下载的文件名 | boolean | 可选 默认false，当接口返回的是url时传递true
confirmData | 导出提示框 | Object  | 可选
||

##### confirmData的参数
参数|说明|类型|是否必填写 |
-|:-|-|-
content | 确认框文案		| string | true 
title | 弹窗title	 | string | true
||

