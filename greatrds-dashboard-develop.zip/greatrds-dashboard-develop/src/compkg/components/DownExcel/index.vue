<template>
  <el-button
    type="primary"
    :size="size || 'small'"
    :disabled="disabled"
    @click="handleDown()"
    :loading="downLoading"
  >
    {{ text || $t('导出EXCEL') }}
  </el-button>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import { getDateFormatStr } from '@/utils/date'
import { openNewWindowLink } from '@/utils/url'

@Component
export default class DownExcel extends Vue {
  @Prop() tag: string; // 调用标识
  @Prop() url: string;
  @Prop() data: any;
  @Prop() totalRow: any;
  @Prop() companyId: any;
  @Prop() bigDataExportType: any;
  @Prop() bigDataExportUrl: any;
  @Prop() downLoadType: any; // 区分接口下载返回是url还是文件流 不传默认是文件流
  @Prop() ajaxData: any;
  @Prop() text: string;
  @Prop() downName: string;
  @Prop() size: string;
  @Prop() disabled: string;

  private downLoading: boolean = false;

  // 运营开关key
  private tagKeys = {
    dynamic: {
      key: 'ReportBlog'
    },
    action: {
      key: 'ReportAction'
    },
    comment: {
      key: 'ReportCommentDafen'
    },
    taskAssign: {
      key: 'ReportWtTask'
    },
    task: {
      key: 'ReportTask'
    },
    timedTask: {
      key: 'TaskTimedActived'
    },
    alarm: {
      key: 'ReportAlarm'
    },
    attendance: {
      key: 'ReportAttendance'
    }
  };

  handleDown() {
    let that: any = this
    let params = that.ajaxData
    if (typeof that.ajaxData === 'function') {
      that.ajaxData().then((res: any) => {
        params = res
      })
    }
  }

  async downExcel(params: any) {
    const that = this
    try {
      that.downLoading = true
      let downParams = {
        'method': 'post',
        'url': that.url,
        'data': params,
        'headers': {
          companyId: that.companyId
        }
      }
      // 区分下载文件流还是URL
      if (!that.downLoadType) {
        downParams['responseType'] = 'arraybuffer'
        downParams['timeout'] = 60 * 1000
        downParams.headers['Content-type'] = 'application/json'
      }
      const data = await (that as any).$axios(downParams)
      that.downLoading = false
      if (data) {
        if (!that.downLoadType) {
          let blob = new Blob([data], {
            'type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          })
          let downName = that.downName + '_' + getDateFormatStr() + '.xlsx'
          if (window.navigator.msSaveBlob) {
            try {
              window.navigator.msSaveBlob(blob, downName)
            } catch (e) {
              console.log(e)
            }
          } else {
            openNewWindowLink({
              'url': URL.createObjectURL(blob),
              'downName': downName
            })
          }
        } else {
          window.open(data)
        }
      }
    } catch (err) {
      that.downLoading = false
    }
  }

  largeDataeExportApplication(params: any) {
    let that: any = this
    that.$prompt((that.$root as any).$t('请输入文件名', '申请导出文件'), {
      confirmButtonText: that.$t('确定'),
      cancelButtonText: that.$t('取消'),
      inputPattern: /\S/,
      inputErrorMessage: that.$t('文件名不能为空')
    }).then(({ value }) => {
      params.fileName = value
      that.doLargeDataeExportApplication(params)
    }).catch(() => {
    })
  }

  async doLargeDataeExportApplication(params: any) {
    let that = this
    try {
      await that.$axios({
        method: 'POST',
        url: that.bigDataExportUrl,
        data: params,
        'headers': {
          companyId: that.companyId
        }
      })
    } catch (err) {
      console.log(err)
    }
  }
}
</script>
