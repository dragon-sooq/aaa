# 当鼠标停止输入后搜索


### 参数：
参数|说明|类型
-|:-|-
placeholder | input的placeholder	| string
||

### 事件：

事件名|说明|参数
-|:-|-
change | 时时搜索 停止keyup时触发的函数	| keyword: 返回的当前input中输入的值
||

### 调用案例
```
<DelayedSearch
  class="input-containers"
  placeholder="请输入表单名称"
  @change="handleSearchChange"
  style="margin-right: 10px"
/>
```
