<template>
  <div>
    <el-input
      class="input-containers"
      prefix-icon="el-icon-search"
      :placeholder="$t(placeholder)"
      v-model="searchVal"
      @focus="handleInputFocusBlur(true)"
      @clear="handleInputClear()"
      size="small"
      clearable
      style="margin-right: 10px"
    />
  </div>
</template>
<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import Utils from '@/utils'

@Component
class DelayedSearchComponent extends Vue {

  @Prop({
    type: String,
    default: '请输入内容'
  })
  placeholder: string;
  @Prop(String) searchText: string;

  private searchVal: string = this.searchText || '';

  @Watch('searchVal')
  onKeywordChanged = Utils.Lodash.debounce((newVal) => {
    console.log(newVal)
    this.handleInputChange()
  }, 300);

  @Watch('searchText')
  onSearchTextChanged(newVal) {
    this.searchVal = newVal
  }

  /**
   * 触发input变化
   */
  handleInputChange() {
    this.$emit('change', this.searchVal)
  }

  /**
   * 触发input获取焦点
   */
  handleInputFocusBlur(flag) {
    this.$emit('focusblur', flag)
  }

  /**
   * 触发input clear
   */
  handleInputClear() {
    this.$emit('clear')
  }
}
export default DelayedSearchComponent
</script>
