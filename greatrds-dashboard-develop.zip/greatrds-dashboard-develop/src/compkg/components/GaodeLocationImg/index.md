# 高德静态图片

### 参数：
参数|说明|类型
-|:-|-
mapLng | 经度	| number
mapLat | 纬度 | number
name | 经度， 纬度对应的地理位置名称 | string


```
<GaodeLocationImg
  map-lng="116.397428"
  map-lat="39.90923"
  name="北京天安门"
/>
```

> 参考文档：
1. 文档地址：https://lbs.amap.com/api/webservice/guide/api/staticmaps/
2. 地图弹窗文档地址：https://elemefe.github.io/vue-amap/#/zh-cn/base/amap


