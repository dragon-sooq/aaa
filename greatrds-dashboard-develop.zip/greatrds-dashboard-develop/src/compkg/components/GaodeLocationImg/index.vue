<template>
  <div>
    <div
      class="es-gaode-location-containers"
      @click="handleOpenMap()"
    >
      <img
        :src="state.src"
        class="es-gaode-location-img"
      >
      <div class="es-gaode-location-name">
        <i class="fa fa-locationfill pull-left" />
        <span class="">我的位置：{{ name }}</span>
      </div>
    </div>
    <!-- <el-dialog
      width="40%"
      title="地图位置"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :before-close="handleClose"
      :append-to-body="true"
      :visible.sync="state.show"
      v-if="state.show"
      @close="handleClose"
      class="es-work-table-choose-containers"
    >
      <el-amap
        ref="map"
        vid="map-location-box"
        :amap-manager="state.amapManager"
        :center="state.center"
        :zoom="state.zoom"
        :events="{}"
        class="map-location-box"
      >
        <el-amap-marker
          v-for="(marker, index) in state.markers"
          :position="marker.position"
          :events="marker.events"
          :key="index"
        />
      </el-amap>
      <div
        slot="footer"
        class="dialog-footer"
      >
        <el-button
          @click="handleClose()"
          size="medium"
        >
          关 闭
        </el-button>
      </div>
    </el-dialog> -->
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'
import VueAMap from 'vue-amap'
Vue.use(VueAMap)
let amapManager = new VueAMap.AMapManager()

@Component
export default class GaodeLocationImg extends Vue {
  @Prop() mapLng: any;
  @Prop() mapLat: any;
  @Prop() name: string;
  
  private state: any = {
    src: '',
    show: false,
    amapManager,
    center: [this.mapLng, this.mapLat],
    zoom: 12,
    markers: [{
      position: [this.mapLng, this.mapLat],
      events: {}
    }]
  }
  created() {
    this.getLocationImgUrl()
  }
  handleOpenMap() {
    this.state.show = true
  }
  handleClose() {
    this.state.show = false
  }
  getLocationImgUrl() {
    const url = `location=${this.mapLng},${this.mapLat}&amp;zoom=15&amp;&markers=mid,,A:${this.mapLng},${this.mapLat}`
    this.state.src = 'https://restapi.amap.com/v3/staticmap?' + url + '&key=8fc54b8e6e84612045a1e8a3518087da'
  }
}
</script>
<style lang="scss" scoped>
  .es-gaode-location-containers{
    width: 320px;
    padding: 10px;
    background: #f5f6f7;
    cursor: pointer;
    .es-gaode-location-img{
      width: 320px;
      height: 180px;
    }
    .es-gaode-location-name{
      background: #526ECC;
      color: #fff;
      height: 36px;
      line-height: 36px;
      padding: 0 10px;
      width: 300px;
      display: flex;
      align-items: center;
      span {
        word-wrap: normal;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        font-size: 12px;
      }
    }
  }
  .map-location-box{
    height: 500px !important;
  }
</style>
