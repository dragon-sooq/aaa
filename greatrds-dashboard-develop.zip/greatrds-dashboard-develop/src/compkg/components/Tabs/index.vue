<template>
  <el-tabs
    v-model="activeName"
    @tab-click="handleClick"
    class="es-table-web"
  >
    <el-tab-pane
      v-for="item in tabs"
      :key="item.name"
      :label="item.label"
      :name="item.name"
      class="tab-pane-item"
    >
      <span slot="label"><i :class="item.icon" />{{ item.label }}</span>
    </el-tab-pane>
  </el-tabs>
</template>
<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'

@Component
export default class EsTabs extends Vue {
  @Prop() changeTab: any;
  @Prop() defaultActiveName: string;
  @Prop() tabList: any;

  private tabs:any = this.tabList || [];
  private activeName:string = this.defaultActiveName || this.tabList[0].label;

  @Watch('defaultActiveName')
  onDefaultActiveNameChanged(newVal: string) {
    this.activeName = newVal
  }

  handleClick(tab: any) {
    if (typeof this.changeTab === 'function') {
      this.changeTab(tab.label)
    }
  }
}
</script>
<style lang="scss">
.es-table-web{
  .el-tabs__header{
    margin: 0;
    color: #ffffff;
  }
  .el-tabs__item{
    color: #fff;
  }
  .el-tabs__item.is-active{
    color: #fff;
  }
}
</style>
