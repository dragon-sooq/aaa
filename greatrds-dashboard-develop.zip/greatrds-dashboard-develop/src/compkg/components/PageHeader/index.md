# 页面Header

### 参数：
参数|说明|类型|是否必传 |
-|:-|-|-
breadcrumb | 面包屑	| String or Array|  必传
border | 是否需要下border | Boolean | 可选
||