<template>
  <div :class="{'page-header-containers': true, 'page-header-border': border}">
    <!-- 若只是一种简单的文案title -->
    <span
      v-if="typeof breadcrumb === 'string'"
      class="fn-16"
    >{{ breadcrumb }}</span>
    <!-- 面包屑 :to="{ path: '/' }"-->
    <el-breadcrumb
      separator-class="el-icon-arrow-right"
      v-else
    >
      <el-breadcrumb-item
        v-for="(item, index) in breadcrumb"
        :key="item.name"
      >
        <span :class="{'nodisabled': item.path, 'active': index === breadcrumb.length - 1}">
          <router-link
            :to="item.path"
            v-if="item.path"
          >{{ $t(item.name) }}</router-link>
          <span
            v-else
            :class="{'cursor-p': item.page === 'secondePage'}"
            @click="itemClick(item)"
          >
            {{ $t(item.name) }}
          </span>
        </span>
      </el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from 'vue-property-decorator'

@Component
export default class PageHeader extends Vue {
  @Prop() breadcrumb: any;
  @Prop() border: boolean;

  itemClick(item) {
    let that = this
    this.$emit('itemClick', item)
  }
}
</script>
<style lang="scss">
  .page-header-containers{
    display: flex;
    flex-direction: column;
    justify-content: center;
    height: 54px;
    box-sizing: border-box;
    padding: 0 10px;
    .fn-16{
      font-size: 16px;
    }
    .el-breadcrumb__inner{
      color: #000;
      font-size: 16px;
    }
    .nodisabled{
      cursor: pointer;
      &:hover{
        color: #526ECC;
      }
    }
    .active{
      color: #526ECC;
    }
  }
  .page-header-border{
    border-bottom: 1px solid #eee;
  }
</style>
