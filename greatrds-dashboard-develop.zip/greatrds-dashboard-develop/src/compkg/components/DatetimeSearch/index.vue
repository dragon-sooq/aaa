<template>
  <el-date-picker
    class="input-containers"
    v-model="value"
    type="datetimerange"
    :start-placeholder="startPlaceholder"
    :end-placeholder="endPlaceholder"
    :default-time="dateTimeValue"
    size="small"
    style="margin-right: 320px"
  />
</template>

<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import Utils from '@/utils'

@Component
class DateTimeSearchComponent extends Vue {

  @Prop({default: '开始日期'}) startPlaceholder: string;
  @Prop({default: '结束日期'}) endPlaceholder: string;
  @Prop({default: () => ['12:00:00', '08:00:00']}) defaultTime: Array<string>;
  @Prop(String) value: Array<string>;

  private dateTimeValue: Array<string> = this.value || ['12:00:00', '08:00:00'];

  @Watch('dateTimeValue')
  onKeywordChanged = Utils.Lodash.debounce((newVal) => {
    console.log(newVal)
  }, 300);

  @Watch('defaultTime', {deep: true})
  onSearchTextChanged(newVal) {
    this.dateTimeValue = newVal
  }

}
export default DateTimeSearchComponent
</script>
