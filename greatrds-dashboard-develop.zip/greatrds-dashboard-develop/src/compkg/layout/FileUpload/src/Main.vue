<template>
  <div class="es-upload-container clearfix">
    <!-- <el-upload
      v-bind="this.mergedProps()"
      v-on="this.listeners()"
      action=""
      :class="{'el-upload-block': isStyleBlock}"
      :accept="fileAccept"
      :show-file-list="false"
      :before-upload="(file)=> fileUpload(file)"
      :multiple="true"
      :limit="fileLimit"
      :on-exceed="()=> exceedFileLimit()"
    >
      <el-button
        :disabled="loading || (uploadFileList && uploadFileList.length === fileLimit)"
      >
        <i class="fa fa-upload mr-5" />
        <span>{{ $t('点击上传') }}</span>
      </el-button>
    </el-upload>
    <ul
      class="el-upload-list"
      :class="fieldType === $root.DICT.FIELDTYPE_IMAGE?'el-upload-list--picture':'el-upload-list--text'"
      v-if="uploadFileList && uploadFileList.length"
    >
      <li
        v-for="(v, vindex) in uploadFileList"
        :key="vindex"
        :tabindex="vindex"
        class="el-upload-list__item is-success"
      >
        <el-image
          style="width: 100px; height: 70px"
          v-if="fieldType === $root.DICT.FIELDTYPE_IMAGE && v.filterval"
          :src="v.filterval"
          class="el-upload-list__item-thumbnail"
          :preview-src-list="imgPreviewList"
          :z-index="99999"
        />
        <el-tooltip
          effect="dark"
          placement="top"
          :content="v.label || v.name"
        >
          <a class="el-upload-list__item-name">
            <i class="el-icon-document" />{{ v.label || v.name }}
          </a>
        </el-tooltip>
        <label class="el-upload-list__item-status-label">
          <i class="el-icon-upload-success el-icon-circle-check" />
        </label>
        <i
          class="el-icon-close"
          @click="deleteFile(v)"
        />
      </li>
    </ul> -->
  </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { Getter } from 'vuex-class'
import OSS from '@/utils/oss'

@Component
class FileUploadComponent extends Vue {

  @Prop() fileList: Array<object>;
  @Prop() fieldType: string;
  @Prop() companyId: number;
  @Prop() ossType: string;
  @Prop() uploadType: string;
  @Prop() isStyleBlock: boolean;
  @Prop() limit: number;

  @Getter loading;

  // 最大可上传个数
  private fileLimit = this.limit || 9;
  // 上传附件列表
  private uploadFileList = [];
  // 大图浏览列表
  private imgPreviewList: Array<object> = [];

  // 获取文件允许类型
  get fileAccept() {
    return this.fieldType === this.$root['DICT'].FIELDTYPE_IMAGE ?
      this.$root['DICT'].FILE_ACCEPT_IMG :
      this.$root['DICT'].FILE_ACCEPT_ALL
  }

  // 监听
  @Watch('fileList', { immediate: true, deep: true })
  onFileList(data: any) {
    this.uploadFileList = []
    // 处理列表中的oss
    this.handleListOssFile(data || [])
  }

  /**
   * 处理列表中的oss
   */
  public async handleListOssFile(list) {
    const that = this
    // 处理列表中的oss
    await OSS.handleListOssFile({
      list,
      configs: [{
        key: 'value', // 取值
        keySet: 'filterval', // 赋值
        type: that.fieldType === that.$root['DICT'].FIELDTYPE_IMAGE ? 'img' : 'file'
      }],
      companyId: that.companyId
    })
    // 更新列表
    that.uploadFileList = list
    // 更新大图浏览
    that.updateImgPreviewList(that.uploadFileList)
  }

  /**
   * 文件上传
   */
  fileUpload(file: any) {
    const that = this
    // 执行oss上传
    this.doFileUpload(file)
    return false
  }

  /**
   * 文件上传校验
   */
  exceedFileLimit() {
    const that = this
  }

  /**
   * 执行附件oss上传
   */
  async doFileUpload(file) {
    const that = this
    // oss上传
    let fileList = await OSS.ossFileUpload({
      files: file,
      ossType: that.ossType,
      uploadType: that.uploadType
    })
    // 触发
    that.$emit('success', fileList)
    // that.updateImgPreviewList(fileList);
  }

  /**
   * 更新大图浏览列表
   */
  updateImgPreviewList(fileList) {
    const that = this
    // 图片单独处理大图浏览
    if (that.fieldType === this.$root['DICT'].FIELDTYPE_IMAGE) {
      // 滞空
      that.imgPreviewList = []
      fileList.map((item) => {
        if (item.filterval || item.absoluteUrl) {
          that.imgPreviewList.push(item.filterval || item.absoluteUrl)
        }
      })
    }
  }

  /**
   * 删除文件
   */
  async deleteFile(file: any) {
    const that = this
    try {
      await (that as any).$confirm(`确定要删除 ${file.label || file.name}？`)
      // 触发
      that.$emit('delete', file)
      // 图片单独处理
      if (that.fieldType === this.$root['DICT'].FIELDTYPE_IMAGE) {
        that.imgPreviewList.splice(that.imgPreviewList.indexOf(file), 1)
      }
    } catch (error) {
      console.log(error)
    }
  }

  listeners() {
    return {
      ...this.$listeners
    }
  }
  mergedProps() {
    return {
      ...this.$attrs,
      ...this.$props,
      ...this.$slots,
      ...this.$vnode,
      ...this.$scopedSlots,
      ...this.$mount,
      ...this.$refs
    }
  }
}
export default FileUploadComponent
</script>

<style lang="scss">
.es-upload-container{
  .el-button.is-disabled, .el-button.is-disabled:focus, .el-button.is-disabled:hover{
    color: #c0c4cc !important;
  }
}
.el-upload-block{
  .el-upload{
    display: block;
  }
}
.el-upload-list--picture {
  position: relative;
  z-index: 999;
  .el-upload-list__item {
    transition: all 0.5s cubic-bezier(0.55, 0, 0.1, 1);
    font-size: 14px;
    color: #606266;
    line-height: 1.8;
    margin-top: 5px;
    position: relative;
    z-index: auto;
    box-sizing: border-box;
    border-radius: 4px;
    width: 100%;
  }
  .el-upload-list__item-thumbnail {
    vertical-align: middle;
    display: inline-block;
    width: 70px !important;
    height: 70px !important;
    position: relative;
    z-index: auto;
    margin-left: -80px;
    background-color: #fff;
  }
}
</style>
