/**
 * Input Component
 * @author Nan
 * @description
*/

class Store {

}

export default Store
