<template>
  <el-container
    class="el-layout el-layout-has-sider"
    style="background: rgb(238, 240,245);"
    :class="{'hiddened': layoutHidden, 'el-theme-dark': $root.isDark, 'el-theme-white': !$root.isDark}"
    v-if="$route.meta.keepAlive"
  >
    <el-header 
      class="el-layout-header el-layout-header-fix" 
      style="height: 50px;"
    >
      <slot
        name="header"
      />
    </el-header>
    <el-container
      class="el-layout-inside"
    >
      <el-aside
        class="el-layout-sider el-layout-sider-fix"
        style="height: 100%;"
      >
        <slot
          name="aside"
        />
      </el-aside>
      <el-scrollbar>
        <banner
          v-if="$route.meta.banner"
          :header-config="$route.meta.banner"
        />
        <el-main
          class="el-layout-content el-layout-content-fix-with-header"
          :class="{'height-all': $route.meta.isTemplate}"
        >
          <slot
            name="main"
          />
        </el-main>
      </el-scrollbar>
      <el-footer v-if="isFooterShow">
        <slot
          name="footer"
        />
      </el-footer>
    </el-container>
  </el-container>
</template>

<script lang='ts'>
import { Vue, Component, Prop, Watch } from 'vue-property-decorator'
import { Mutation, Getter } from 'vuex-class'
import store from '@/stores/index'
import { Banner } from '@/compkg/components/index'

@Component({
  components: {
    Banner
  }
})
class ContainerComponent extends Vue {

  // private showAside: boolean = true;

  // @Mutation('toggleAsideCollapse') toggleAsideCollapse;
  
  private name: String = 'ContainerComponent';
  private windowWidth: number = (window as any).innerWidth;

  // @Prop(Boolean)
  // asideCollapse: boolean
  @Prop(Boolean)
  layoutHidden: boolean

  // computed
  get isFooterShow() {
    return false// 后面加拓展 分页可以放上面展示
  }

  /**
   * 绑定window缩放事件绑定
   */
  bindWindowResizeEvent() {
    window.onresize = () => {
      this.windowWidth = (window as any).innerWidth
    }
  }

  /**
   * 监听当前视窗的宽度动态加载导航的展开折叠
   * @author Arley Joe
   * @time - 2019年11月05日11:42:41
   * @description - 如果当前加载的视窗宽度大于1366则展开侧导航，反之则隐藏侧导航文字，显示图标导航
   */
  @Watch('windowWidth', {immediate: true})
  onWindowWidthChanged(newWidth) {
    if ((this as any).$route.name === 'Template') {
      if (newWidth <= 1366) {
        // 收起左侧菜单栏 展示更多有效区域
        // this.toggleAsideCollapse(true)
      } else {
        // 展开左侧菜单栏
        // this.toggleAsideCollapse(false)

      }
    }
  }

  created() {
    this.onWindowWidthChanged(this.windowWidth)
  }

  mounted() {
    this.bindWindowResizeEvent()

    // console.log(`Component "${this.name}" is rendered.`);
  }
}

export default ContainerComponent
</script>

<style lang="scss" scoped>
  @import '../index.scss';
  @import '../theme.scss';
</style>
