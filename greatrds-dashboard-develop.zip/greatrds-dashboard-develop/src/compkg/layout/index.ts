import ContainerComponent from './Container/src/Main.vue'
export class Container extends ContainerComponent {}
