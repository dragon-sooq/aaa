/**
 * Custom Error
 * @author Nan 2019-09-06 16:58:52
 * @description: In this file, we customized several types of errors for our development. You can use this errors
 *               in every project.
 */

export class CustomError extends Error {
  constructor(message: string) {
    super(message)
    this.name = '[Custom Error]';
    (Error as any).captureStackTrace(this, this.constructor)
  }
}

export class ParamsMissingError extends Error {
  constructor(param: string) {
    super(param)
    this.name = '[Params Error]'
    this.message = `Parmas of ${param} is needed, but not defined.`;
    (Error as any).captureStackTrace(this, this.constructor)
  }
}
