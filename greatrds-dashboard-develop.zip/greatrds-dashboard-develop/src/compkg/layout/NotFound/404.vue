<template>
  <a-row class="es-404">
    <a-col :span="12">
      <div class="grid-content es-img-404">
        <img
          src="../../compkg/assets/images/404.png"
          alt="img"
        >
      </div>
    </a-col>
    <a-col :span="12">
      <div class="grid-content">
        <a-alert
          type="error"
          :message="description"
        />
      </div>
    </a-col>
  </a-row>
</template>
<script lang="ts">
export default {
  name: 'NotFound',
  data() {
    return {
      description: (this as any).$route.params.description || '您好像访问了错误地址' // 描述信息
    }
  }
}
</script>
<style lang="scss">
  .es-404{
    padding-top: 150px;
    .el-alert--error{
      background:transparent;
      margin-top: 100px;
    }
  }
  .es-img-404{
    text-align: right;
    img{
      width: 600px;
    }
  }
</style>
