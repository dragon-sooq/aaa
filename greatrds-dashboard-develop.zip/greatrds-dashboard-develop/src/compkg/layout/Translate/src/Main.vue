<template>
  <span>
    <template 
      v-if="prefix"
    >
      {{ prefix }}
    </template>
    <template>
      {{ translated }}
    </template>
    <template
      v-if="subfix"
    >
      {{ subfix }}
    </template>
  </span>
</template>

<style lang='sass'></style>

<script lang='ts'>
import { Vue, Component, Prop } from 'vue-property-decorator'
import Utils from '@/utils'
import moment from 'moment'
import Store from '../index'

const store = new Store()

@Component
class TranslateComponent extends Vue {
  private name: String = 'TranslateComponent';
  // 默认类型
  private rules: any = {};
  private translated: string | number = '';
  private fixedLen: number;
  private connector: string; // Data connector

  @Prop([String, Number]) value : string | number;
  @Prop(String) prefix : string;
  @Prop(String) subfix : string;
  @Prop(String) type : string;
  @Prop([Number, String]) fixed: number | string; // 保留小数点位数
  @Prop(String) format: string;
  @Prop(String) joiner: string;

  store = store;

  constructor() {
    super()
    // Verify that whether the parameter "value" is passed in.
    if (typeof this.value === 'undefined') {
      throw new Utils.ParamsMissingError('value')
    }

    // Init default rules.
    this.rules = {
      date: this.format || 'YYYY-MM-DD', // 日期格式格式化规则
      datetime: this.format || 'YYYY-MM-DD HH:mm:ss', // 日期时间格式格式化规则
      finance: this.format || /(\d{1,3})(?=(?:\d{3})+(?!\d))/g, // 财务金额数字类型转换正则
      phone: this.format || /(^\d{3}|\d{4}\B)/g, // 手机号转换格式正则
      telephoneA: this.format || /(\d{3})(\d{0,4})(\d{0,4})/, // 三位区号固定电话转换格式正则
      telephoneB: this.format || /(\d{4})(\d{0,4})(\d{0,3})/ // 四位区号固定电话转换格式正则
    }
    
    // Init some attributes
    this.fixedLen = Number(this.fixed) || 2
    this.connector = typeof this.joiner !== 'undefined' ? this.joiner : ','
  }

  created() {
    if (typeof this.value === 'undefined') {
      return
    }
    switch (this.type) {
    case 'date':
      this.translated = moment(this.value).format(this.rules.date)
      break
    case 'datetime':
      this.translated = moment(this.value).format(this.rules.datetime)
      break
    case 'number':
      this.translated = Number(this.value).toFixed(this.fixedLen)
      break
    case 'finance':
      this.translated = Number(this.value).toFixed(this.fixedLen).toString().replace(this.rules.finance, `$1${this.connector}`)
      break
    case 'percent':
      this.translated = (Number(this.value) / 100).toFixed(this.fixedLen) + '%'
      break
    case 'phone':
      let value: string = this.value.toString()
      let areaCodeThreeReg = /^0[1,2]{1}[0-9]{1}\d{8}/ // 直辖市
      let areaCodeFourReg = /^0[1-9]{1}[0-9]{9}/ // 普通地市
      if (areaCodeThreeReg.test(value)) {
        this.translated = this.value.toString().replace(this.rules.telephoneA, '$1-$2 $3')
      } else if (areaCodeFourReg.test(value)) {
        this.translated = this.value.toString().replace(this.rules.telephoneB, '$1-$2 $3')
      } else {
        this.translated = this.value.toString().replace(this.rules.phone, '$1 ')
      }
      break
    default:
      this.translated = this.value
      break
    }
  }

  mounted() {
    // console.log(`Component "${this.name}" is rendered.`);
  }
}

export default TranslateComponent
</script>
