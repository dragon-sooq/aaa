/**
 * 系统变量
 */
const VARS = {
  splitStr: '靁', // 特殊字符
  moblie: {
    kf: '010-85911471',
    code: {
      reg: 1,
      bindphone: 1,
      login: 2,
      pwd: 3
    }
  },
  img: {
    logo: {
      default: 'static/images/icons/logo-lg.png',
      sm: 'static/images/icons/logo.png'
    },
    user: {
      face: 'static/images/icons/userFace.png'
    },
    friend: {
      group: 'static/images/icons/friendGroup.png'
    },
    company: {
      face: 'static/images/icons/companyFace.png'
    },
    things: {
      face: 'static/images/icons/thingsFace.png'
    },
    im: {
      companyTeam: 'static/images/icons/companyTeam.png',
      friendTeam: 'static/images/icons/friendTeam.png'
    },
    warning: {
      face: 'static/images/icons/icon-warning.png'
    }
  },
  file: {
    limit: {
      'size': 10485760, // 10MB
      'sizeStr': '10MB',
      'number': {
        'dynamic': 9,
        'comment': 3,
        'im': 9,
        'offlineimg': 100// 离线上传总个数
      }
    },
    types: {
      'jpg': 'img#tupian1',
      'jpeg': 'img#tupian1',
      'gif': 'img#tupian1',
      'png': 'img#tupian1',
      'bmp': 'img#tupian1',
      'zip': 'file#ZIP',
      'rar': 'file#ZIP',
      'txt': 'file#txt-copy',
      'doc': 'file#w',
      'docx': 'file#w',
      'wps': 'file#w',
      'xls': 'file#icon_excel',
      'xlsx': 'file#icon_excel',
      'ppt': 'file#ppt',
      'pptx': 'file#ppt',
      'pdf': 'file#pdf',
      'mp3': 'audio#yinle',
      'amr': 'audio#yinle',
      'mp4': 'video#shipin',
      'flv': 'video#shipin',
      'wmv': 'video#shipin',
      'avi': 'video#shipin',
      'rmvb': 'video#shipin',
      'mkv': 'video#shipin'
    },
    'accept': {
      'img': 'image/jpg,image/jpeg,image/png,image/bmp,image/gif',
      'file': 'audio/x-wav,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.template,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/zip,application/x-dwg,application/vnd.android,application/x-trash,text/plain,audio/mpeg,video/mpeg,video/mpeg4,video/mp4,video/x-msvideo'
    },
    oss: {
      location: 'oss-cn-beijing',
      folder: 9551687// 默认文件夹名 勿改勿删
    }
  },
  ajax: {
    wtBaseURL: 'http://192.168.60.189:18383/rest',
    code: {
      success: '0000'
    }
  },
  cookie: {
    'day': 7
  },
  secret: {
    'app': 'shi9527',
    'web': 'ethingswb',
    'wt': 'shishiming',
    'system': 'ethingsystem'
  },
  day: {
    'one': 86400000 // 1天=24*60*60*1000=86400000毫秒
  },
  limit: {
    choose: {
      'worktable': 3,
      'contact': 10
    },
    size: {
      'dynamic': {
        'comment': 8000,
        'viewMore': 2000
      },
      'worktable': {
        'val': 8000
      },
      'contact': 300,
      'notice': 10000
    },
    count: {
      'remainUserCount': '公司人数',
      'remainExternalCount': '外部联系人数',
      'largeDataeExportNum': 1000 // 大数据导出1000
    }
  },
  msg: {
    'ok': '确定',
    'close': '关闭',
    'cancle': '取消',
    'reload': '刷新页面',
    'prompt': '系统提示',
    'alert': '警告',
    'success': {
      'handle': '操作成功',
      'submit': '提交成功',
      'login': '登录成功',
      'reg': '注册成功'
    },
    'fail': {
      'handle': '操作失败',
      'submit': '提交失败'
    },
    'error': {
      'handle': '操作错误',
      'submit': '提交错误',
      'api': '服务器异常',
      'system': '系统错误',
      'network': '网络错误',
      'ajax': 'Ajax请求错误',
      'params': '缺少必要参数'
    },
    'null': {
      'content': '暂无内容',
      'data': '暂无内容',
      'search': '暂无搜索条件相关数据'
    }
  },
  code: {
  }
}
// 导出
export default VARS
