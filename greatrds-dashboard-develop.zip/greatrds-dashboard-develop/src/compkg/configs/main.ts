/**
 * 通用引入操作
 * update by boomer 2019-08-05 13:50:17
 */
import Vue, { DirectiveOptions } from 'vue'
import ElementUI from 'element-ui'
// import 'element-ui/lib/theme-chalk/index.css';
import './element-variables.scss'
// import Antd from 'ant-design-vue';
// import 'ant-design-vue/dist/antd.less';
import '../assets/css/core.scss'
import '../plugins/registerServiceWorker'
import '../plugins/filter'
import '@/permission'
import i18n from '@/compkg/configs/i18n'
import { API } from '@/utils/api'
import axios from 'axios'
import VARS from '@/compkg/configs/vars'
import * as directives from '@/directives'
import MD5 from 'crypto-js/md5'
import uuidv4 from 'uuid/v4'
import * as _ from 'lodash'
import VueSocketIOExt from 'vue-socket.io-extended'
import io from 'socket.io-client'

import Component from 'vue-class-component'
Component.registerHooks([
  'beforeRouteEnter', // 进入路由之前
  'beforeRouteLeave', // 离开路由之前
  'beforeRouteUpdate'
])
Vue.use(ElementUI, {
  i18n: (key, value) => i18n.t(key, value)
})

const socket = io('http://192.168.243.100:5001/greatrds', { autoConnect: false })
Vue.use(VueSocketIOExt, socket)

// Register global directives
Object.keys(directives).forEach((key) => {
  Vue.directive(key, (directives as { [key: string ]: DirectiveOptions })[key])
})
Vue.config.productionTip = false
Vue.prototype.$axios = axios
Vue.prototype.$api = API
Vue.prototype.$vars = VARS
Vue.prototype.$handleError = (err: any) => {
  console.log(err)
  if (err) {
    let errMsg: any = ''
    if (typeof (err) === 'object' && err.code && err.code === 'ECONNABORTED') {
      console.error(err.config.url + '请求超时')
      errMsg = '请求超时'
    } else if (typeof (err) === 'string') {
      errMsg = err
    }
    if (errMsg) {
      Vue.prototype.$notify.error({
        title: '系统提示',
        message: errMsg
      })
    }
  }
}
Vue.prototype.$safeApi = (config: any, authcode: string) => {
  return new Promise((resolve, reject) => {
    let { deviceId, channelType } = config.headers
    if (!(deviceId && channelType)) {
      reject('Error: safeApi need deviceId\channelType')
      return
    }
    // 增加http请求参数nonce_str，推荐随机字符串，保证签名不可预测
    let nonceStr: string = uuidv4().replace(/-/g, '')
    // 参数组装
    let paramArr = ['nonce_str']
    let paramObj: any = {
      nonce_str: nonceStr
    }
    // 特殊情况处理body update by boomer 2018-12-11 18:58:19
    if (config.data) {
      paramArr.push('body')
      let configData = config.data
      if (typeof (config.data) !== 'string') {
        configData = JSON.stringify(config.data)
      }
      paramObj.body = MD5(configData).toString().toUpperCase()
    }
    if (config.params) {
      for (let vv in config.params) {
        if (config.params[vv] || config.params[vv] === 0) {
          paramArr.push(vv)
        }
      }
    }
    // 设所有发送的数据为集合M，包含http请求的param参数和body参数，将集合M内非空参数值的参数按照参数名ASCII码从小到大排序（字典序），使用URL键值对的格式（即key1=value1&key2=value2…）拼接成字符串stringA
    paramArr = _.orderBy(paramArr)
    let stringA = ''
    let paramsSum = _.extend(paramObj, config.params || {})
    let paramArrLen = paramArr.length
    paramArr.map((v, vindex) => {
      let paramV = paramsSum[v]
      // 增加对象子属性去空处理 update by boomer 2018-12-11 18:07:51
      if (typeof (paramV) === 'object' && !_.isArray(paramV)) {
        for (let pkey in paramV) {
          if (!paramV[pkey]) {
            Reflect.deleteProperty(paramV, pkey)
          }
        }
      }
      stringA += (v + '=' + (typeof (paramV) === 'object' ? JSON.stringify(paramV) : paramV)) + (vindex === paramArrLen - 1 ? '' : '&')
    })
    // channel_type： pc设备编号，web端等于pc channel_type：渠道类型,现有header里是否存在？authcode:由接口获取得到signValue字符串，并对signValue进行MD5运算，再将得到的字符串所有字符转换为大写，得到sign值signValue
    let url = config.url
    // 截取处理iframe下的全路径情况
    if (url.indexOf('/rest/') > -1) {
      url = url.split('/rest/')[1]
    }
    const signValue = stringA + '&key=/rest/' + url + '.' + config.method.toUpperCase() + '.' + stringA.length + '.' + deviceId + '.' + channelType + '.' + (authcode || 'authcode:pc')
    // console.log('safeApi加密前：', signValue);
    resolve({
      nonce_str: nonceStr,
      sign: MD5(signValue).toString().toUpperCase()// 增加http请求参数sign=signValue
    })
  })
}

export default Vue
