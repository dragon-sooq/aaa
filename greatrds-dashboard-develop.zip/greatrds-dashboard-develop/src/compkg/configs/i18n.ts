import Vue from 'vue'
import VueI18n from 'vue-i18n'
import { i18nEn } from '../language/en'
import { i18nZh } from '../language/zh'
Vue.use(VueI18n)

// 首次基于url lang 缓存
if (location.href.indexOf('lang=') > -1) {
  localStorage.language = location.href.indexOf('lang=en') > -1 ? 'en' : 'zh'
} else {
  localStorage.language = localStorage.language === 'en' ? 'en' : 'zh'
}

const i18n = new VueI18n({
  locale: localStorage.language,
  messages: {
    en: i18nEn,
    zh: i18nZh
  },
  silentTranslationWarn: true // 国际化警告
})

export default i18n
