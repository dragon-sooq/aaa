/**
 * 图片压缩
 */
export const photoCompress = (file: any, config: any, callback: any) => {
  let ready = new FileReader()

  /* 开始读取指定的Blob对象或File对象中的内容. 当读取操作完成时,readyState属性的值会成为DONE,如果设置了onloadend事件处理程序,则调用之.同时,result属性中将包含一个data: URL格式的字符串以表示所读取文件的内容. */
  ready.readAsDataURL(file) // 调用reader.readAsDataURL()方法，把图片转成base64
  ready.onload = (evt: any) => {
    let img = new Image()
    img.src = evt.target.result
    img.onload = () => {
      // 默认按比例压缩
      let imgWid = img.width
      let imgHei = img.height
      let scale = imgWid / imgHei
      imgWid = config.width || imgWid
      imgHei = config.height || (imgWid / scale)
      let quality = 0.6
      // 生成canvas
      let canvas: any = document.createElement('canvas')
      let ctx: any = canvas.getContext('2d')
      // 创建属性节点
      let anw: any = document.createAttribute('width')
      anw.nodeValue = imgWid
      let anh: any = document.createAttribute('height')
      anh.nodeValue = imgHei
      canvas.setAttributeNode(anw)
      canvas.setAttributeNode(anh)
      ctx.drawImage(img, 0, 0, imgWid, imgHei)
      // 图像质量
      if (config.quality && config.quality <= 1 && config.quality > 0) {
        quality = config.quality
      }
      // quality值越小，所绘制出的图像越模糊
      // 回调函数返回base64的值
      callback(canvas.toDataURL('image/jpeg', quality))
    }
  }
}

// 将以base64的图片url数据转换为Blob
export const convertBase64UrlToBlob = (urlData: any) => {
  let arr = urlData.split(',')
  let mime = arr[0].match(/:(.*?);/)[1]
  let bstr = atob(arr[1])
  let bstrLen = bstr.length
  let u8arr = new Uint8Array(bstrLen)
  while (bstrLen--) {
    u8arr[bstrLen] = bstr.charCodeAt(bstrLen)
  }
  return new Blob([u8arr], { type: mime })
}
