/**
 * [esFilter description]
 * @type {Object}
 */
import Vue from 'vue'
import moment from 'moment'
import DICT from '@/utils/dict'
import i18n from '@/compkg/configs/i18n'
import { dateFilter } from '@/utils/date'

/**
 * textareaFilter
 */
Vue.prototype.textareaFilter = (val, limit) => {
  if (!val) {
    return ''
  }
  if (typeof val === 'string') {
    let ss = ''
    ss = val.replace(/&amp;/g, '&')
    ss = ss.replace(/<(?=[^o][^)])/g, '&lt;')
    ss = ss.replace(/>/g, '&gt;')
    // ss = ss.replace(/\'/g, '&quot;');
    ss = ss.replace(/\n/g, '<br>')
    if (limit) {
      let isMore = ss.length > limit
      ss = ss.substring(0, limit) + (isMore ? '...' : '')
    }
    return ss
  }
  return val
}

/**
 * 通用暂无数据
 */
Vue.filter('dbNullFilter', (str) => {
  if (!str || str === 'undefined' || str === 'null' || str === '{}') {
    str = i18n.t('暂无')
  }
  return str
})

/**
 * 类别暂无数据处理
 */
Vue.filter('dbCategoryNullFilter', (str) => {
  if (!str || str === 'undefined' || str === 'null' || str === '{}') {
    str = i18n.t('其他')
  }
  return str
})

/**
 * 通用日期
 */
Vue.filter('dateStrFilter', (val, format) => {
  if (val) {
    let kk = val * 1000
    if (typeof val === 'string') {
      kk = Number(val)
    }
    return moment(kk).format(format || 'YYYY-MM-DD')
  }
  return ''
})

/**
 * 最多N个字展示
 */
Vue.filter('dbStrLimitFilter', (str, lim) => {
  let limit = lim || 6
  let strNew = ''
  if (!str) {
    strNew = '-'
  } else if (str.length > limit) {
    strNew = str.substring(0, limit) + '...'
  }
  return strNew
})

/**
 * 去掉时间中的T
 */
Vue.filter('dbDateFilter', (str) => {
  if (str && str.indexOf('T') !== -1) {
    str = str.replace(/T/g, ' ').replace(/Z/g, '')
  }
  return str
})



/**
 * 解析表情
 */
Vue.filter('imEmojiFilter', (val) => {
  if (!val || !val.length) {
    return ''
  }
  if (typeof val === 'string') {
    if (val.indexOf('[') > -1 && val.indexOf(']')) {
      return window.WebIM.utils.parseEmoji(val)
    }
  }
  return val
})

/**
 * 状态是否启用 t/f
 */
Vue.filter('dbStatusFilter', (val) => {
  if (val && val === true) {
    return i18n.t('启用')
  } else if (val === false) {
    return i18n.t('禁用')
  }
  return val
})

/**
 * 定时器任务状态过滤
 */
Vue.filter('AlarmRuleStatusFilter', (val) => {
  if (val && val === 1) {
    return i18n.t('启用')
  } else if (val === 0) {
    return i18n.t('禁用')
  } else if (val === 2) {
    return i18n.t('暂停')
  }
  return val
})

/**
 * 告警状态过滤
 */
Vue.filter('TaskStatusFilter', (val) => {
  if (val && val === 'up') {
    return i18n.t('正常')
  } else if (val === 'down') {
    return i18n.t('停用')
  }
  return i18n.t('静默')
})

/**
 * 告警规则列表 告警级别过滤
 */
Vue.filter('AlarmLevelFilter', (val) => {
  if (val) {
    if (val === 'critical') {
      return i18n.t('紧急')
    } else if (val === 'major') {
      return i18n.t('重要')
    } else if (val === 'minor') {
      return i18n.t('次要')
    } else if (val === 'info') {
      return i18n.t('提示')
    }
  }
  return val
})

/**
 * 标签格式化
 */
Vue.filter('dbLabelFilter', (val) => {
  if (val instanceof Object) {
    if (Object.keys(val).length === 0) {
      return i18n.t('暂无')
    }
    let res = ''
    for (let k in val) {
      res += k + ':' + val.k + ' '
    }
    return i18n.t(res)
  }
  return i18n.t(val)
})

/**
 * 用户类型
 */
Vue.filter('dbUserFilter', (val) => {
  if (val && val === true) {
    return i18n.t('管理员')
  }
  return i18n.t('控制台用户')
})

/**
 * 角色类型
 */
Vue.filter('dbRoleFilter', (val) => {
  if (val && val === 'admin') {
    return i18n.t('管理员')
  }
  return i18n.t('控制台角色')
})

/**
 * 用户类型
 */
Vue.filter('dbUserFilter', (val) => {
  if (val && val === 'admin') {
    return i18n.t('管理员')
  }
  return i18n.t('控制台用户')
})

/**
 * 附件大小
 */
Vue.filter('dbFileSize', (bytes) => {
  if (bytes === null || bytes === 0) {
    return '0 B'
  }
  let k = 1000, // or 1024
    sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
    i = Math.floor(Math.log(bytes) / Math.log(k))
  return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i]
})

/**
 * 附件大小
 */
Vue.filter('dbTFFilter', (val) => {
  if (val || val === '1') {
    return i18n.t('是')
  }
  return i18n.t('否')
})

export default {}
