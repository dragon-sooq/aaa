/**
 * 英文国际化
 */
import enLocale from 'element-ui/lib/locale/lang/en'
import enAll from './all'

export const i18nEn = {
  ...enAll,
  ...enLocale
}
