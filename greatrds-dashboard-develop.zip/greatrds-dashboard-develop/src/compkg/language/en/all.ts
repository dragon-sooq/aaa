/**
 * 预留国际化文案
 */
const enAll = {}

export default enAll
