/**
 * 中文国际化
 */
import zhLocale from 'element-ui/lib/locale/lang/zh-CN'

export const i18nZh = {
  ...zhLocale
}
