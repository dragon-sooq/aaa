import { DirectiveOptions } from 'vue'
import store from '@/stores/index'
import CACHE from '@/utils/cache'

export const permission: DirectiveOptions = {
  inserted(el, binding) {
    const { value } = binding
    // const role = store.getters['user/role']
    let permissions: any = CACHE.localStorage.get('permission')
    if (value && value instanceof Array && value.length > 0 && permissions[value[0]]) {
      console.log(permissions[value[0]])
      const hasPermission = permissions[value[0]][value[1]]
      if (!hasPermission) {
        el.style.display = 'none'
      }
    } else {
      throw new Error('need permission! v-permission')
    }
  }
}
