/**
 * 公式计算
 * @author Nan 2019-12-19 16:02:16
 * @description - 根据`formula.js`提供的方法，自动进行公式计算
 * @resule - 返回计算完的结果，如果计算后的结果中含有[object Object]，则为公式设置错误，为非法公式
 * 
 * 用法：
 * Formula('sum(1,2,3) + 2 + abs(-1)');
 */

import * as Formulas from 'formula'

// 获取所有公式的名称
const FormulasNames = Object.keys(Formulas)

// 动态拼接完成的公式引用
let FormulasConstant: string = ''
// 生成公式函数常量
FormulasNames.forEach((name: string) => {
  // 暂时不考虑’if‘函数和’switch‘函数，但内部存在’IF‘和’SWITCH‘函数
  if (typeof Formulas[name] === 'function') {
    if (name === 'if' || name === 'switch') {
      FormulasConstant += `const ${name}_formula = ${Formulas[name]};`
    } else {
      FormulasConstant += `const ${name} = ${Formulas[name]};`
    }
  } else {
    FormulasConstant += `const ${name} = ${JSON.stringify(Formulas[name])};`
  }
})
// console.log(Formulas);
// console.log(FormulasNames);
// console.log(FormulasConstant);

/**
 * 公式计算函数（对外输出）
 * @param formula - 传入的计算公式
 */
const Formula = (formula: string) => {
  // 自动生成匿名函数且自执行
  const result: any = new Function(`${FormulasConstant} return ${formula}`)()
  // 检测返回值为string的状态，是否为公式设置错误
  if (typeof result === 'string' && result.indexOf('[object Object]')) {
    console.error(`公式(Formula)中设置了不符合用法规则的公式，请检查公式。公式为:${formula}`)
    return ''
  }
  return result
}

export default Formula
