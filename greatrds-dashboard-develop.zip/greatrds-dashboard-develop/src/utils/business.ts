/**
 * 业务通用
 */
import CACHE from '@/utils/cache'

/**
 * 获取国家
*/
export const getCountries = (opts: any) => {
  // CACHE.localStorage.remove('es_web_countries');
  const esWebCountries: any = [
    {
      countryCode: '+86',
      countryName: '中国',
      shortCode: 'CN',
      icon: ''
    },
    {
      countryCode: '+1',
      countryName: '加拿大',
      shortCode: 'CA',
      icon: ''
    },
    {
      countryCode: '+1',
      countryName: '美国',
      shortCode: 'US',
      icon: ''
    },
    {
      countryCode: '+591',
      countryName: '玻利维亚',
      shortCode: 'BO',
      icon: ''
    },
    {
      countryCode: '+65',
      countryName: '新加坡',
      shortCode: 'SG',
      icon: ''
    },
    {
      countryCode: '+852',
      countryName: '中国香港',
      shortCode: 'HK',
      icon: ''
    },
    {
      countryCode: '+886',
      countryName: '中国台湾',
      shortCode: 'TW',
      icon: ''
    }
  ]
  CACHE.localStorage.put('es_web_countries', esWebCountries)
  opts.success && opts.success(esWebCountries)
}

/**
 * 首字母大写
 */
export const upFirstLetter = (val: string) => {
  let str = val.toLowerCase()
  str = str.replace(/\b\w+\b/g, (word) => {
    return word.substring(0, 1).toUpperCase() + word.substring(1)
  })
  return str
}
