/**
 * Utils Class
 * @author Nan
 * @description
 */
import * as Errors from './Error'
import * as _ from 'lodash'
import FormatUtils from './format'
import GeekUtils from './geek'

namespace Utils {
  export class ParamsMissingError extends Errors.ParamsMissingError {}
  export class ArgumentsTypeError extends Errors.ArgumentsTypeError {}
  export class ArgumentsRangeError extends Errors.ArgumentsRangeError {}
  export const Format = FormatUtils
  export const Lodash = _
  export const Geek = GeekUtils
}


export default Utils
