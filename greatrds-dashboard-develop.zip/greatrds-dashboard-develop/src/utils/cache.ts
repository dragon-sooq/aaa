/**
 * 缓存服务
 */
import Cookies from 'js-cookie'

const CACHE = {
  localStorage: {
    put: (key: string, value: string) => {
      if (window.localStorage) {
        let tempval = value
        if (typeof (value) !== 'string') {
          tempval = JSON.stringify(value)
        }
        window.localStorage.setItem(key, tempval)
      }
    },
    get: (key: string) => {
      if (window.localStorage) {
        let value = window.localStorage.getItem(key)
        if (value && (value.indexOf('{"') > -1 || value.indexOf('[') > -1)) {
          value = JSON.parse(value)
        }
        return value
      }
      return null

    },
    remove: (key: string) => {
      if (window.localStorage) {
        window.localStorage.removeItem(key)
      }
    }
  },
  sessionStorage: {
    put: (key: string, value: any) => {
      if (window.sessionStorage) {
        window.sessionStorage.setItem(key, JSON.stringify(value))
      }
    },
    get: (key: string) => {
      if (window.sessionStorage) {
        let value = window.sessionStorage.getItem(key)
        return value ? JSON.parse(value) : null
      }
      return null

    },
    remove: (key: string) => {
      if (window.sessionStorage) {
        window.sessionStorage.removeItem(key)
      }
    }
  },
  cookies: {
    put: (key: any, val: any, expires: any) => {
      if (expires) {
        Cookies.set(key, val, { expires: expires || 7 })
      } else {
        Cookies.set(key, val)
      }
    },
    get: (key: any) => {
      return Cookies.get(key)
    },
    remove: (key: any) => {
      Cookies.remove(key)
    }
  }
}

export default CACHE
