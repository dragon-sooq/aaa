/**
 * 处理校验
 */
import Vue from '@/compkg/configs/main'
let { $message } = Vue.prototype

/**
  * 获取字符/汉字的长度
  */
/* eslint-disable */
export const getStrLength = (str: string) => {
  if (!str) {
    return 0;
  }
  let tempStr = str + '';
  let cArr = tempStr.match(/[^\x00-\xff]/ig);
  return tempStr.length + (cArr === null ? 0 : cArr.length);
};

/**
 * 支持中文处理的字符串截取
 * update by boomer 2018-07-10 16:29:56
 */
/* eslint-disable */
export const strIntercept = (str, len, hasDot?) => {
  let newLength = 0, newStr = '', chineseRegex = /[^\x00-\xff]/g, singleChar = '';
  let strLength = str.replace(chineseRegex, '**').length;
  for (let i = 0; i < strLength; i++) {
    singleChar = str.charAt(i).toString();
    if (singleChar.match(chineseRegex) != null) {
      newLength += 2;
    } else {
      newLength++;
    }
    if (newLength > len) {
      break;
    }
    newStr += singleChar;
  }
  if (hasDot && strLength > len) {
    newStr += hasDot;
  }
  return newStr;
};

/**
 * 增加通用文字验证和截取，1个文字=2个字符
 * @val 内容
 * @title 当前项名字
 * @limit 限制字符数
 * @isNumber 是否为数字类型
 * @isJustJude 是否只验证对错
 * @isTips 是否错误消息提示
 */
export const judgeTextInput = (opts: any = {}) => {
  let { val, title, limit, isNumber, isJustJude, isTips } = opts;
  //配置limit
  limit = (limit || 25) * 2;
  // 非数字类显示文案处理
  let getErrMsg = () => {
    return title + '最多' + (isNumber ? '' : (limit / 2) + '个汉字或') + limit + '个字符';
  };
  return new Promise((resolve, reject)=> {
    if (!val){
      resolve({
        value: ''
      });
      return;
    }
    if (getStrLength(val) > limit) {
      if (isTips) {
        console.log('messageError');
      }
      if (isJustJude){
        reject();
      }else{
        resolve({
          value: strIntercept(val, limit),
          message: getErrMsg()
        });
      }
    } else {
      resolve({
        value: val
      });
    }
  });
};
