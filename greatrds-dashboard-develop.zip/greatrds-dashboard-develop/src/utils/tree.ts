/**
 * 递归树服务
 */
export const handleTreeV2 = (data: any, id: string, pid: string, name: string) => {
  let parent: Array<object> = []
  for (let i = 0; i < data.length; i++) {
    if (data[i][pid] === '1' || data[i][pid] === '2') {
      let obj = {
        label: data[i][name],
        id: data[i][id],
        children: []
      }
      parent.push(obj)// 数组加数组值
    }
    // console.log(obj);
    //  console.log(parent,"bnm");

  }
  children(parent)

  // 调用子节点方法,参数为父节点的数组
  // eslint-disable-next-line no-shadow
  function children(parent: any) {
    if (data.length !== 0) {
      for (let i = 0; i < parent.length; i++) {
        for (let j = 0; j < data.length; j++) {
          if (parent[i].id === data[j][pid]) {
            let obj = {
              label: data[j][name],
              id: data[j][id],
              children: []
            }
            parent[i].children.push(obj)
          }
        }
        children(parent[i].children)
      }
    }
  }
  console.log(parent, 'bjil')
  return parent
}

/**
 * 清洗将待选择禁止选择列表洗入数据
 */
export const handleWaitDisabledList = (opts: any = {}) => {
  return new Promise((resolve) => {
    let { waitList, waitDisabledList, idKey } = opts
    if (!(waitDisabledList && waitDisabledList.length)) {
      resolve(waitList)
    }
    // 将禁止选择洗成hash
    let waitDisabledHash = {}
    waitDisabledList.forEach((item: any) => {
      waitDisabledHash[idKey ? item[idKey] : item.id] = 1
    })
    // 将禁止选择hash注入数据列表中
    waitList.forEach((item: any) => {
      if (waitDisabledHash[idKey ? item[idKey] : item.id]) {
        item.disabled = true
      }
    })
    resolve(waitList)
  })
}

/**
 * 清洗已选择/禁止选择列表
 */
export const handleHashList = (opts: any = {}) => {
  return new Promise((resolve) => {
    let { list, idKey, nameKey } = opts
    let hash: any = {}
    if (!(list && list.length)) {
      resolve(hash)
    }
    list.forEach((item: any) => {
      let id = idKey ? item[idKey] : (item.id || item._id)
      let name = nameKey ? item[nameKey] : item.name
      hash[id] = {
        id,
        name
      }
    })
    resolve(hash)
  })
}

/**
 * 将禁止选择hash注入数据列表中
 */
export const handleDisabledHash = (opts: any = {}) => {
  return new Promise((resolve) => {
    let { list, disabled, idKey } = opts
    list.forEach((item: any) => {
      let id = idKey ? item[idKey] : (item.id || item._id)
      if (disabled[id]) {
        item.disabled = true
      }
    })
    resolve(list)
  })
}
