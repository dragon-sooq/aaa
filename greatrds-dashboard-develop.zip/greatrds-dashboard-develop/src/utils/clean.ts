/**
  * 数据转换器
  * @param [data] - 默认值数据 (data为数组时, params必传)
  * @param [params] - label: id, value: thingsTitle 参数别名
  */
export const dataConvert = (opts: any = {}) => {
  let { data, param } = opts,
    convertData: Array<object> = []
  if (data && Array.isArray(data)) {
    data.map((item: any) => {
      let extension = {} 
      for (let key in param) {
        extension[key] = item[param[key]]
      }
      convertData.push(extension)
    })
  }
  return convertData
}
