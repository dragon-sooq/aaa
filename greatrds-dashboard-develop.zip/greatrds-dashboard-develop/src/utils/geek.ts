/**
 * Some tool function libraries that are self-defined or implemented.
 * @author Nan 2020-03-31 20:05:27
 * @description - 
 * @copyright - Arley Joe
 */
namespace Geek {

  /**
   * TimerEach
   * 
   * @param list - Collection of arrays to be iterates
   * @param callback - Processing logic required for each execution of the iterates
   * @param duration - Interval time required for each cycle
   * 
   * @description - This method provides a timed iterates function for events that require iterative processing of 
   *                each element in the array collection at regular intervals. This method requires three 
   *                required parameters. Refer to the parameter definitions for details.
   */
  export const TimerEach: Function = (list: Array<any>, callback: Function, duration: number) => {
    let count: number = 0
    const length: number = list.length
    const timer: any = setInterval(() => {
      callback(list[count])
      count++
      if (count === length) {
        clearInterval(timer)
      }
    }, duration)
  }
}

export default Geek
