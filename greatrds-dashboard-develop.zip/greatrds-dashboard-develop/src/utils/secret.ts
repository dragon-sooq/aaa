/**
 * 解密
 */
// import AES from 'crypto-js/aes';
// import EncBase64 from 'crypto-js/enc-base64';
// import EncUtf8 from 'crypto-js/enc-utf8';
import CryptoJS from 'crypto-js'
import VARS from '@/compkg/configs/vars'

/**
 * 前端加密
 * isHandleTszf 是否处理特殊字符
 */
export const safeJiami = (opts: any = {}) => {
  try {
    let { data, key, isHandleTszf, isBase64 } = opts
    if (!data) {
      return null
    }
    data.timestamp = Math.round(new Date().getTime() / 1000)
    let ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), VARS.secret[(key || 'web')]).toString()
    // 处理特殊字符
    if (isHandleTszf) {
      ciphertext = ciphertext.replace(/\//ig, '฿')
    }
    // 是否base64处理 避免malformed utf-8 data报错 update by boomer 2019-10-22 16:19:29
    if (isBase64) {
      // 对加密数据进行base64处理, 原理：就是先将字符串转换为utf8字符数组，再转换为base64数据
      ciphertext = CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(ciphertext))
    }
    // 使用encodeURIComponent将传递数据加工 避免转码后+/等符号转换失败； 接收方需要用decodeURIComponent解析下 update by boomer 2018-09-13 16:12:38
    return encodeURIComponent(ciphertext)
  } catch (error) {
    console.error(error)
    return null
  }
}

/**
 * 前端解密
 */
export const safeJiemi = (opts: any = {}) => {
  try {
    let { data, key, isHandleTszf, isBase64 } = opts
    if (!data) {
      return null
    }
    let ciphertext = decodeURIComponent(data)
    // 是否base64处理 避免malformed utf-8 data报错 update by boomer 2019-10-22 16:19:29
    if (isBase64) {
      // 对加密数据进行base64处理, 原理：就是先将字符串转换为utf8字符数组，再转换为base64数据
      ciphertext = CryptoJS.enc.Base64.parse(ciphertext).toString(CryptoJS.enc.Utf8)
    }
    // 处理特殊字符
    if (isHandleTszf) {
      ciphertext = ciphertext.replace(/฿/ig, '/')
    }
    let urlCanshus = CryptoJS.AES.decrypt(ciphertext, VARS.secret[(key || 'web')]).toString(CryptoJS.enc.Utf8)
    return urlCanshus ? JSON.parse(urlCanshus) : null
  } catch (error) {
    console.error(error)
    return null
  }
}
