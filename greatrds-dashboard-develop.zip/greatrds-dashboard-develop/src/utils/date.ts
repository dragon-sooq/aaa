/**
 * 日期服务
 */
import i18n from '@/compkg/configs/i18n'
import moment from 'moment'

/**
 * 日期时间配置
 */
export const getDatePickerOption = () => {
  return {
    'rangeSeparator': i18n.t('至'),
    'startPlaceholder': i18n.t('开始日期'),
    'endPlaceholder': i18n.t('结束日期'),
    'defaultTime': ['00:00:00', '23:59:59'],
    'defaultTwoYearValue': [new Date(`${moment().subtract(2, 'year').format('YYYY-MM-DD')} 00:00:00`), new Date(`${moment().format('YYYY-MM-DD')} 23:59:59`)],
    'defaultValue': [new Date(`${moment().subtract(1, 'month').format('YYYY-MM-DD')} 00:00:00`), new Date(`${moment().format('YYYY-MM-DD')} 23:59:59`)],
    'defaultValueSixDays': [new Date(`${moment().subtract(6, 'days').format('YYYY-MM-DD')} 00:00:00`), new Date(`${moment().format('YYYY-MM-DD')} 23:59:59`)],
    'disabledDateGtNow': (value: number) => {
      if (Date.now() <= value) {
        return true
      }
      return false
    },
    'last7days': [new Date(`${moment().subtract(6, 'days').format('YYYY-MM-DD')} 00:00:00`), new Date(`${moment().format('YYYY-MM-DD')} 23:59:59`)],
    'shortcuts': [
      {
        'text': i18n.t('过去一周'),
        onClick(picker: { $emit: (arg0: string, arg1: Date[]) => void; }) {
          const end = `${moment().format('YYYY-MM-DD')} 23:59:59`
          const start = `${moment().subtract(6, 'days').format('YYYY-MM-DD')} 00:00:00`
          picker.$emit('pick', [new Date(start), new Date(end)])
        }
      },
      {
        'text': i18n.t('过去1个月'),
        onClick(picker: { $emit: (arg0: string, arg1: Date[]) => void; }) {
          const end = `${moment().format('YYYY-MM-DD')} 23:59:59`
          const start = `${moment().subtract(1, 'month').format('YYYY-MM-DD')} 00:00:00`
          picker.$emit('pick', [new Date(start), new Date(end)])
        }
      },
      {
        'text': i18n.t('过去三个月'),
        onClick(picker: { $emit: (arg0: string, arg1: Date[]) => void; }) {
          const end = `${moment().format('YYYY-MM-DD')} 23:59:59`
          const start = `${moment().subtract(3, 'month').format('YYYY-MM-DD')} 00:00:00`
          picker.$emit('pick', [new Date(start), new Date(end)])
        }
      },
      {
        'text': i18n.t('本月'),
        onClick(picker: { $emit: (arg0: string, arg1: Date[]) => void; }) {
          const end = `${moment().format('YYYY-MM-DD')} 23:59:59`
          const start = `${moment().startOf('month').format('YYYY-MM-DD')} 00:00:00`
          picker.$emit('pick', [new Date(start), new Date(end)])
        }
      }
    ]
  }
}

/**
 * 获取日期string
 */
export const getDateFormatStr = (opts: any = {}) => {
  let { timestamp, format } = opts
  let dateNew: string | number | Date = new Date()
  if (timestamp) {
    let timestampStr = timestamp.toString()
    if (timestampStr.length === 10) {
      dateNew = new Date(timestamp * 1000)
    } else if (timestampStr.indexOf('-') > -1) {
      timestampStr = timestampStr.replace(/-/g, '/')
      dateNew = new Date(timestampStr)
    } else {
      dateNew = new Date(timestamp)
    }
  }
  return moment(dateNew).format(format || 'YYYY-MM-DD HH:mm:ss')
}

/**
 * 日期格式化
 * @param dateVal
 * @param format
 */
export const dateFilter = (dateVal: number | string | bigint | Date, format?: string) => {
  if (!dateVal || dateVal === '0') {
    return ''
  }
  let dateStr: any = dateVal.toString()
  if (dateStr.indexOf('-') > -1) { // cst日期格式处理
    dateVal = new Date(dateStr).getTime()
  }
  if (typeof dateVal === 'number') { // number
    dateStr = getDateFormatStr({
      timestamp: dateVal,
      format: format || 'YYYY-MM-DD HH:mm'
    })
  } else if (dateStr.length > 18) {
    dateStr = dateStr.substring(0, dateStr.length - 3)
  } else {
    dateStr = getDateFormatStr({
      timestamp: parseInt(dateStr, 10),
      format: format || 'YYYY-MM-DD HH:mm'
    })
  }
  let dateStrLen = dateStr.length
  if (moment(dateStr).isSame(moment(), 'day')) { // 是今天
    return dateStr.substring(10, dateStrLen)
  } else if (moment(dateStr).isSame(moment(), 'year')) { // 是今年
    return dateStr.substring(5, dateStr.length)
  }
  return dateStr
}


export const getCacheIndex = (dateStr: any) => {
  // let thisDate = getDateFormatStr(dateStr);
  // return moment.utc(thisDate).valueOf();
  if (dateStr) {
    let dateStrTemp = dateStr + '',
      dateStrArr = dateStr.split(' ')
    if (dateStrArr.length === 2 && dateStrTemp.indexOf('-') > -1) { // 年月日时分
      dateStr = dateStrTemp.replace(/-/g, '/')
    } else { // 时分
      dateStr = moment().format('YYYY/MM/DD') + ' ' + dateStr
    }
  }
  let thisDate: any = new Date()
  if (dateStr) {
    thisDate = new Date(dateStr)
  }
  return thisDate.getTime()
}

export const getCustomTime = () => {
  // eslint-disable-next-line radix
  let weekOfDay = parseInt(moment().format('E'))
  return {
    '自定义': [],
    '昨天': [`${moment().subtract(1, 'days').format('YYYY-MM-DD')}`, `${moment().subtract(1, 'days').format('YYYY-MM-DD')}`],
    '本周': [moment().subtract(weekOfDay - 1, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '上周': [moment().subtract(weekOfDay + 7 - 1, 'days').format('YYYY-MM-DD'), moment().subtract(weekOfDay, 'days').format('YYYY-MM-DD')],
    '近7天': [moment().subtract(6, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '近30天': [moment().subtract(29, 'days').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '本月': [moment().startOf('month').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '上月': [moment().subtract(1, 'month').startOf('month').format('YYYY-MM-DD'), moment().subtract(1, 'month').endOf('month').format('YYYY-MM-DD')],
    '本季度': [moment().quarter(moment().quarter()).startOf('quarter').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '上季度': [moment().quarter(moment().quarter() - 1).startOf('quarter').format('YYYY-MM-DD'), moment().quarter(moment().quarter() - 1).endOf('quarter').format('YYYY-MM-DD')],
    '本年': [moment().startOf('year').format('YYYY-MM-DD'), moment().format('YYYY-MM-DD')],
    '去年': [moment().subtract(1, 'year').startOf('year').format('YYYY-MM-DD'), moment().subtract(1, 'year').endOf('year').format('YYYY-MM-DD')]
  }
}
export const verificationTimeRange = (timeArr: any, maxDay: number) => {
  const cha = moment(timeArr[1]).diff(moment(timeArr[0]), 'days')
  if (maxDay && (cha > maxDay - 1)) {
    (this as any).$notification['error']({
      message: '系统提示',
      description: '时间范围不能超过' + maxDay + '天'
    })
    return false
  }
  return true
}
