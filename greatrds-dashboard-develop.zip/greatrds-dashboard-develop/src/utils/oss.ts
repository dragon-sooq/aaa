/**
 * OSS服务
 * @type {Object}
 */
import VARS from '@/compkg/configs/vars'
import axios from 'axios'
import uuidv4 from 'uuid/v4'
// import * as _ from 'lodash';
import * as AliOSS from 'ali-oss'
import { getDateFormatStr } from '@/utils/date'
import { photoCompress, convertBase64UrlToBlob } from '@/compkg/plugins/imgResize'

// oss允许类型
const ossAllowTypes = {
  shared: ['icon_ethings', 'qrcode_ethings', 'icon_company', 'qrcode_company', 'icon_user', 'qrcode_user', 'icon_friend', 'icon_group', 'qrcode_group', 'im', 'operation', 'collect', 'worktableOffline', 'designer_default_values', 'ething', 'default'],
  company: ['post_', 'photo', 'statdata', 'notice', 'wt_', 'task_', 'sign']
}

let isRefreshing: any = {} // 是否正在刷新的标记

const OSS = {
  /**
   * 文件上传
   * ossType：shared公共、company公司[必传]
   * companyId：ossType==company时[必传]
   * files：执行上传的文件s[必传]
   * uploadType：文件上传类型 用于命名等[必传] 下面为参数值明细：
   * 【ossType：shared】用户头像|朋友头像icon_user、
   * 【ossType：company】
   * isPreview：是否为假上传（平时不常用）[选传]
   * thingId, postOssCode, taskId 对应特定业务时传递 [选传]
   */
  async ossFileUpload(opts: any = {}) {
    let that = this
    try {
      let { files, ossType, uploadType, isPreview, companyId, userId, thingId, postOssCode, taskId } = opts
      // if (!(files && files.length)) {
      //   return Promise.reject('请选择要上传的文件');
      // }
      if (!Array.isArray(files) && typeof (files) === 'object' && Object.keys(files).length) {
        files = [files]
      }
      console.log(files)
      // 校验附件
      await that.fileValidate(files)
      // 校验osstoken
      ossType = ossType || 'shared' // oss类型
      // 获取ossClient
      const ossClient = await that.verifyOssTokenAndClient({
        files,
        ossType,
        companyId,
        uploadType,
        isPreview
      })
      // 初始化fileList 用于接受上传成功后的oss文件
      let fileList: Array<object> = []
      // 异步上传
      let syncUpload = async() => {
        let newFile = files.shift()
        if (!newFile) {
          return
        }
        let { file, isBlob } = await that.handleWaitUploadFile(newFile)
        let fileSuffix = that.getFileSuffix(file.name)
        let fileType = that.handleFileType(fileSuffix)
        let ossName: string = '', absoluteUrl: string = ''
        if (!isPreview) { // 当前为真实上传
          let saveAsName = that.handleOssFileName({
            ossType, uploadType, fileSuffix, companyId, thingId, postOssCode, taskId
          })
          if (!saveAsName) {
            return Promise.reject('生成oss上传路径和名称错误')
          }
          let { name: ossBackName } = await ossClient[isBlob ? 'put' : 'multipartUpload'](saveAsName, file, {
            partSize: 1024 * 1024,
            headers: {
              'Content-Disposition': 'attachment; filename="' + encodeURIComponent(file.name) + '"; filename*=' + encodeURIComponent(file.name) // 增加下载名称 update by wwj 2017-10-11 15:49:29
            },
            meta: {// 增加oss更多描述信息 update by boomer 2019-07-23 16:55:10
              os: ossType,
              userAgent: navigator.userAgent,
              userId: userId,
              routerName: location.hash.split('?')[0]
            },
            progress: (percentage) => {
              console.log(percentage * 100, file.name, '正在上传中......')
            }
          })
          ossName = ossBackName
          // let ossAllUrl = that.handleOssHost(window['ossToken'][ossType]) + ossBackName;
          absoluteUrl = await that.downOssFile({
            downUrl: ossBackName,
            downType: fileType, // 'img' : 'file'
            companyId
          })
        }
        fileList.push({
          name: file.name,
          size: typeof (file.size) === 'number' ? (file.size / 1024 / 1024).toFixed(2) + '' : file.size,
          type: fileSuffix,
          fileType: fileType,
          ossUrl: ossName, // ossUrl上传后的地址
          absoluteUrl: absoluteUrl // oss拼接全的地址
        })
        console.log(fileList)
        if (!(files && files.length)) {
          return Promise.resolve(fileList)
        }
        return syncUpload()
      }
      return syncUpload()
    } catch (error) {
      console.error(error)
      return Promise.reject(error)
    }
  },

  /**
   * 处理将要上传的文件
   * @param file
   */
  handleWaitUploadFile(file: any) {
    let that = this
    return new Promise((resolve) => {
      if (!file.lastModified && !file.name && file.type) { // 单独处理blob文件对象
        let reader = new FileReader()
        reader.readAsArrayBuffer(file)
        reader.onload = () => {
          let newFile = AliOSS.Buffer(reader.result)
          newFile.name = newFile.name || 'test' + Math.random() + '.png'
          resolve({
            file: newFile,
            isBold: true
          })
        }
      } else {
        let fileSuffix = that.getFileSuffix(file.name)
        let fileType = that.handleFileType(fileSuffix)
        if (fileType === 'img') {
          // 压缩
          photoCompress(file, {
            quality: 0.8
          }, (base64Codes) => {
            let blob = convertBase64UrlToBlob(base64Codes)
            let newFile = new File([blob], file.name, {
              type: file.type,
              lastModified: file.lastModified
            })
            resolve({
              file: newFile
            })
          })
        } else {
          resolve({
            file
          })
        }
      }
    })
  },

  /**
   * 验证文件上传个数和文件大小
   * files[必传]、
   * type文件类型[默认dynamic] dynamic: 9、comment: 3、im:9、wt:9、
   * uploadType上传类型[默认default]
   */
  fileValidate() {
    return Promise.resolve()
  },

  getOssToken(ossType: string, companyId: any) {
    if (ossType === 'shared') {
      // 获取sharedFileToken POST
      return axios({
        method: 'POST',
        url: 'osscenter/privateBucket/getOSSSharedFileToken',
        data: {
          userId: 1
        }
      })
    } else if (ossType === 'company') {
      if (!companyId) {
        return Promise.reject('请传入companyId')
      }
      // 获取getCompanyOSSToken POST
      return axios({
        method: 'POST',
        url: 'osscenter/getCompanyOSSToken',
        data: {
          userId: 1,
          companyId: parseInt(companyId, 10)
        }
      })
    }
  },

  /**
   * 获取ossToken
   * ossType：shared公共、company公司[必传]
   * 当ossType不为shared时，companyId[必传]
   */
  getOssTokenAndClient(opts: any = {}) {
    let that = this
    let { ossType, companyId } = opts
    return new Promise((resolve, reject) => {
      if (!isRefreshing[ossType]) {
        isRefreshing[ossType] = true
        that.getOssToken(ossType, companyId).then((resOss: any) => {
          isRefreshing[ossType] = false
          window['ossToken'] = window['ossToken'] || {}
          window['ossToken'][ossType] = resOss
          resolve(that.getOssClient({
            ossType,
            companyId
          }))
        }).catch((error) => {
          console.error(error)
          isRefreshing[ossType] = false
          reject(error)
        })
      } else {
        setTimeout(() => {
          reject('hadGettingOssToken')
        }, 300)
      }
    })
  },

  /**
   * OSS 验证token是否过期
   * ossType：shared公共、company公司、post动态分享im[必传]
   * 当ossType不为shared时，companyId[必传]
   */
  verifyOssTokenAndClient(opts: any = {}) {
    const that = this
    try {
      const { ossType, companyId } = opts
      if (!ossType) {
        return Promise.reject('请传入验证ossType')
      }
      const ossKey = that.getOssKey({ ossType, companyId })
      if (ossKey && window[ossKey] && window['ossToken']) { // 如果有oss 那么验证是否过期
        const expirationTime = window['ossToken'][ossType].expirationTime
        const now = new Date().getTime() + 10 * 60 * 1000 // 提前10分钟
        if (expirationTime < now) {
          console.warn('当前ossType对应ossToken已过期1')
          return that.getOssTokenAndClient({
            ossType,
            companyId
          })
        }
        return Promise.resolve(window[ossKey])
      }
      console.warn('没有ossType对应ossToken', ossType)
      return that.getOssTokenAndClient({
        ossType,
        companyId
      })
    } catch (error) {
      console.error(error)
      return Promise.reject(error)
    }
  },

  /**
   * 实例化oss
   * ossType：shared公共、company公司、post动态分享im[必传]
   * 当ossType不为shared时，companyId[必传]
   * 当ossType为post、wt时，postOssCode[必传]
   */
  getOssClient(opts: any = {}) {
    let that = this
    return new Promise((resolve, reject) => {
      let { ossType, companyId } = opts
      let esOss = window['ossToken'][ossType]
      // 重新生成公有oss上传 实例化
      let options: any = {
        region: VARS.file.oss.location,
        accessKeyId: esOss.accessKeyId,
        accessKeySecret: esOss.accessKeySecret,
        stsToken: esOss.securityToken,
        bucket: esOss.bucketName
      }
      let protocol = ((document.location.protocol === 'https:') ? 'https://' : 'http://')
      // 生产环境开启HTTPS访问模式 有效避免OSS Js SDK https请求ERRSSLPROTOCOLERROR
      // https://bbs.aliyun.com/read/275103.html?spm=5176.bbsr275115.0.0.pPZ17C
      if (protocol === 'https://') {
        options.secure = true // 如果指定了secure为true，则使用HTTPS访问
      }
      let ossKey = that.getOssKey({ ossType, companyId })
      if (!ossKey) {
        console.error('暂无可匹配oss实例化对象')
        reject('暂无可匹配oss实例化对象')
      } else {
        // 实例化
        window[ossKey] = new AliOSS(options)
        resolve(window[ossKey])
      }
    })
  },

  /**
   * 获取oss key
   * ossType：shared公共、company公司、post动态分享im[必传]
   * 当ossType不为shared时，companyId[必传]
   */
  getOssKey(opts: any = {}) {
    let { ossType, companyId } = opts
    let ossKey = ''
    if (ossType) {
      if (ossType === 'shared') {
        ossKey = 'oss' + ossType + 'Client'
      } else if (companyId && ossType === 'company') {
        ossKey = 'oss' + companyId + 'Client'
      }
    }
    return ossKey
  },

  /**
   * 处理文件存放类型
   */
  handleOssFileName(opts: any = {}) {
    let { ossType, uploadType, fileSuffix, companyId, thingId, postOssCode, taskId } = opts // 文件后缀名
    let today = getDateFormatStr({
      format: 'YYYY-MM-DD'
    }) // 今天
    let uuid: string = uuidv4() // uuid
    let fileName: string = ''
    if (ossType === 'shared' && ossAllowTypes[ossType].indexOf(uploadType) > -1) { // 共用上传
      fileName = 'sharedFile/'
      if (uploadType.indexOf('icon_') === 0) { // sharedFile/icon/icon_xxx/2019-01-01/0.png
        fileName += 'icon/' + uploadType
      } else if (uploadType.indexOf('qrcode_') === 0) { // sharedFile/qrcode/qrcode_xxxx/2019-01-01/0.png
        fileName += 'qrcode/' + uploadType
      } else { // sharedFile/xxxx/2019-01-01/0.png
        fileName += uploadType
      }
      fileName += '/' + today + '/' + uuid
    } else if (ossType === 'company') { // 公司上传
      let uploadKey = uploadType
      if (uploadType.indexOf('_') > -1) {
        uploadKey = uploadType.split('_')[0] + '_'
      }
      if (ossAllowTypes[ossType].indexOf(uploadKey) > -1) {
        fileName = 'privateFile/company_' + companyId + '/'
        if (uploadType.indexOf('post_') === 0 || uploadType.indexOf('wt_') === 0) {
          if (!postOssCode) {
            // 从uploadType中截取 update by boomer 2019-06-06 13:40:07
            if (uploadType.indexOf('post_') === 0) {
              postOssCode = uploadType.split('post_')[1]
            } else if (uploadType.indexOf('wt_') === 0) {
              postOssCode = uploadType.split('wt_')[1]
            }
            if (!postOssCode) {
              console.error('缺少必传参数postOssCode')
              return ''
            }
          }
          if (uploadType.indexOf('post_') === 0) { // privateFile/company_10663/ething_12345/post_xxxx/2019-01-01/0.png
            fileName += 'ething_' + thingId + '/' + 'post_' + postOssCode
          } else { // privateFile/company_10663/wt_xxxx/2019-05-13/0.png
            fileName += 'wt_' + postOssCode
          }
        } else if (uploadType.indexOf('task_') === 0) { // privateFile/company_10663/task_xxxx/2019-05-13/0.png
          fileName += 'task_' + taskId
        } else { // privateFile/company_10663/xxxx/2019-05-13/0.png
          fileName += uploadType
        }
        fileName += '/' + today + '/' + uuid
      }
    }
    if (fileName) {
      // 组装后缀名
      if (fileSuffix) {
        fileName += '.' + fileSuffix
      }
      return fileName
    }
    return null
  },

  /**
   * 处理oss拼接host
   * "endpoint":"https://oss-cn-beijing.aliyuncs.com","bucketName":"te-private-ething | st-private-ething | pr-private-ething"
   * http://te-private-ething.oss-cn-beijing.aliyuncs.com/company_300/icon/2017-07-05/E7918DD77EAD4E58BFE246C1175F09DD.jpg
   */
  handleOssHost(oss: any) {
    let bucketName = oss.bucketName // bucketName:"te-private-ething"
    let endpoint = oss.endpoint + '/' // endpoint:"http://oss-cn-beijing.aliyuncs.com"
    if (endpoint.indexOf('https://') === 0) {
      return endpoint.replace(/https:\/\//g, 'https://' + bucketName + '.')
    }
    return endpoint.replace(/http:\/\//g, 'https://' + bucketName + '.')
  },

  /**
   * 展示图片、附件
   * companyId在公司/im分享动态时必传
   */
  downOssFile(opts: any = {}) {
    let that = this
    return new Promise((resolve) => {
      let { downUrl, downType, companyId, isImgResize, defaultUrl } = opts
      downUrl = downUrl || ''
      downType = downType || 'img'
      // 无值直接回执默认
      if (!downUrl) {
        resolve(defaultUrl || VARS.img.logo.default)
        return
      }
      // 直接返回结果
      if (downUrl.indexOf('sharedFile/default/') > -1 || downUrl.indexOf('sharedFile/operation/') > -1) {
        resolve(downUrl)
        return
      }
      if (downUrl.indexOf('sharedFile/') > -1 || downUrl.indexOf('privateFile/') > -1) {
        // 含有com/ 先截取
        if (downUrl.indexOf('com/') > -1) {
          downUrl = downUrl.split('com/')[1]
        }
        if (downUrl.indexOf('?x-oss-process=') > -1) {
          downUrl = downUrl.split('?x-oss-process=')[0]
        } else if (downUrl.indexOf('?OSSAccessKeyId=') > -1) {
          downUrl = downUrl.split('?OSSAccessKeyId=')[0]
        }
        // 组装生成tokenClient的参数
        let params: any = {}
        if (downUrl.indexOf('sharedFile/') > -1) {
          params.ossType = 'shared'
        } else if (downUrl.indexOf('privateFile/') > -1) {
          params.companyId = companyId
          params.ossType = 'company'
        }
        that.verifyOssTokenAndClient(params).then((ossClient: any) => {
          if (isImgResize) {
            downUrl = ossClient.signatureUrl(downUrl, {
              process: 'image/resize,w_100/auto-orient,1/quality,q_90/interlace,1/format,jpg' // 只指定宽度、自动旋转、指定缩略图大于原图不缩略、图片格式webp、质量90、渐进展示、透明补白
            })
          } else {
            downUrl = ossClient.signatureUrl(downUrl)
          }
          // 处理http->https
          if (downUrl && downUrl.indexOf('aliyuncs.com') > -1 && downUrl.indexOf('http://') === 0) {
            downUrl = downUrl.replace(/http:/, 'https:')
          }
          resolve(downUrl)
        }, (error: any) => {
          console.warn('解析url失败', error)
          if (error === 'hadGettingOssToken') {
            // 再次请求 update by boomer 2019-07-09 16:16:20
            that.downOssFile(opts).then((resUrl: string) => {
              resolve(resUrl)
            })
          } else {
            resolve(downUrl)
          }
        })
      } else { // 旧数据兼容处理
        if (downType !== 'file' && isImgResize) {
          downUrl += '?x-oss-process=' + 'image/resize,w_100/auto-orient,1/quality,q_90/interlace,1/format,jpg'// 只指定宽度、自动旋转、指定缩略图大于原图不缩略、图片格式webp、质量90、渐进展示、透明补白
        }
        // 处理http->https
        if (downUrl && downUrl.indexOf('aliyuncs.com') > -1 && downUrl.indexOf('http://') === 0) {
          downUrl = downUrl.replace(/http:/, 'https:')
        }
        resolve(downUrl)
      }
    })
  },

  /**
   * 通用处理列表中的图片、附件
   * list: Array 列表
   * configs: Array [{key: xxx, keySet: '',type: 'img\file'}]
   * key 为获取当前参数值，keySet为真实赋值参数，不传则用key
   * companyId: Number | String 公司id
   */
  handleListOssFile(opts: any = {}) {
    const that = this
    const { companyId, list, configs } = opts
    return Promise.all(list.map(async(node: any) => {
      return Promise.all(configs.map(async(config: any) => {
        const absoluteUrl = await that.downOssFile({
          downUrl: node[config.key],
          downType: config.type || 'file',
          defaultUrl: config.defaultUrl,
          companyId
        })
        node[config.keySet || config.key] = absoluteUrl
        return node
      }))
    }))
  },

  /**
   * 处理文件后缀名
   * @param fileName
   */
  getFileSuffix(fileName: string) {
    if (!fileName) {
      return ''
    }
    let tempName = fileName.split('?')[0]// 去除参数
    let result = tempName.substring(tempName.lastIndexOf('.') + 1, tempName.length)
    result = result.toLowerCase()
    // 增加ios 新格式类型过滤 update by boomer 2019-01-21 22:33:13
    return result === 'heic' ? 'jpg' : result
  },

  /**
   * 处理文件名 除去后缀名
   */
  getFileNameNotSuffix(fileName: string) {
    if (!fileName) {
      return ''
    }
    let tempName = fileName.split('?')[0]// 去除参数
    return tempName.substring(0, tempName.lastIndexOf('.'))
  },

  /**
   * 处理文件设备
   */
  handleDeviceType(type: string) {
    if (type === 'camera') {
      return '拍照'
    } else if (type === 'picture') {
      return '相册'
    }
    return '文件'
  },

  /**
   * 处理文件名字
   */
  handleFileName(fileName: string) {
    if (!fileName) {
      return ''
    }
    if (fileName.length < 11) {
      return fileName
    }
    return fileName.substring(0, 10) + '...'
  },

  /**
   * 处理文件类型
   */
  handleFileType(filetype: string) {
    let typeStr = VARS.file.types[filetype]
    if (!typeStr) {
      return 'file'
    }
    return typeStr.split('#')[0]
  },

  /**
  * 是否为图片
  */
  isImg(url: string) {
    if (url.indexOf('.') > -1) {
      let fileSuffix = this.getFileSuffix(url)
      let fileType = this.handleFileType(fileSuffix)
      return fileType === 'img'
    }
    return false
  },

  /**
   * 处理文件图标
   */
  handleFileIcon(filetype: string) {
    let typeStr = VARS.file.types[filetype]
    if (!typeStr) {
      return 'fa-file1 text-file'
    }
    let aa = typeStr.split('#')[1]
    return 'fa-' + aa + ' text-' + aa

  },

  /**
   * 根据文件路径/文件名携带后缀名 获取文件名
   */
  getFileNameByPath(path: string) {
    if (!path) {
      return ''
    }
    return path.substring(path.lastIndexOf('/') + 1, path.length)
  },

  /**
   * 根据文件路径/文件名携带后缀名 获取文件类型
   */
  getFileTypeByPath(path: string) {
    if (!path) {
      return 'file'
    }
    let fileSuffix = this.getFileSuffix(path)
    return this.handleFileType(fileSuffix)
  },

  /**
   * 获取文件列表
   * notDel 是否能删除标识 update by boomer 2019-03-21 10:45:15
   */
  getFileListByPathStr(opts: any = {}) {
    let that = this
    let { urls, notDel, isDefaultVal } = opts
    if (!urls) {
      return []
    } else if (typeof (urls) === 'object' && Array.isArray(urls)) {
      return that.handleFileNewData(urls, notDel, isDefaultVal)// 通用处理文件新数据
    } else if (typeof (urls) === 'string') {
      if (urls.indexOf('[') === 0 && urls.indexOf(']') === urls.length - 1) {
        return that.handleFileOldData(JSON.parse(urls), notDel, isDefaultVal)// 通用处理文件旧数据
      }
      return that.handleFileOldData(urls.split(','), notDel, isDefaultVal)// 通用处理文件旧数据

    }
    return []

  },

  /**
   * 通用处理文件新数据
   */
  handleFileNewData(list: any, notDel: any, isDefaultVal: any) {
    let that = this
    let fileList: any = []
    list.map((v: any) => {
      let it: any = {
        ossPath: v.url
      }
      if ((!v.name || !v.type) && v.url) { // 容错 数组下仅有url
        let title = that.getFileNameByPath(v.url)
        it.file = {
          name: title,
          type: that.getFileSuffix(v.url),
          status: that.getFileTypeByPath(v.url)
        }
        it.title = title
        it.isUpload = true
      } else {
        // 增加ios 新格式类型过滤 update by boomer 2019-01-21 22:33:13
        v.type = v.type === 'heic' ? 'jpg' : v.type
        it.file = {
          name: v.name,
          type: v.type,
          size: typeof v.size === 'number' ? (v.size / 1024 / 1024).toFixed(2) + '' : v.size,
          status: that.handleFileType(v.type)
        }
        it.title = v.name
        it.localPath = v.local
        it.isUpload = isDefaultVal || v.isUpload || false// true有线 false离线
      }
      // 增加不可删除标识 update by boomer 2019-03-21 10:46:50
      if (notDel) {
        it.notDel = true
      }
      fileList.push(it)
    })
    return fileList
  },

  /**
   * 通用处理文件旧数据
   */
  handleFileOldData(list: any, notDel: any, isDefaultVal: any) {
    let that = this
    let fileList: any = []
    list.map((v: any) => {
      let it: any = {}
      if (typeof (v) === 'string') {
        let title = that.getFileNameByPath(v)
        it = {
          file: {
            name: title,
            status: that.getFileTypeByPath(v)
          },
          title: title,
          ossPath: v,
          isUpload: true
        }
      } else {
        let title = that.getFileNameByPath(v.ossPath)
        it = {
          file: {
            name: title,
            status: that.getFileTypeByPath(v.ossPath)
          },
          title: title,
          localPath: v.localPath,
          ossPath: v.ossPath, // ossPath:v,
          isUpload: isDefaultVal || v.isUpload || false
        }
      }
      // 增加不可删除标识 update by boomer 2019-03-21 10:46:50
      if (notDel) {
        it.notDel = true
      }
      fileList.push(it)
    })
    return fileList
  },

  /**
  * 工作表旧数据url兼容处理
  */
  fileUrlCompatible(url: any) {
    let that = this
    if (!url || url === '[]') {
      return []
    }
    if (!(url instanceof Array) && !Array.isArray(url)) {
      if (url.indexOf('[') > -1 && url.indexOf('ossPath') > -1) {
        let showvalueArr = JSON.parse(url)
        if (showvalueArr.length) {
          let arr2: any = []
          showvalueArr.map((sa: any) => {
            if (sa && sa.ossPath) {
              arr2.push(sa.ossPath)
            }
          })
          url = arr2.join(',')
        }
      }
      let valStr = url
      let valArr = valStr.split(',')
      let showValue: any = []
      valArr.map((va: any) => {
        if (va) {
          let index1 = va.lastIndexOf('.')
          let fileName = that.getFileNameByPath(va)
          let index2 = fileName.lastIndexOf('.')
          showValue.push({
            url: va,
            size: '',
            ispic: that.isImg(va),
            name: fileName.substring(0, index2),
            type: va.substring(index1 + 1, va.length)// 后缀名
          })
        }
      })
      return showValue
    }
    return url
  }
}

export default OSS
