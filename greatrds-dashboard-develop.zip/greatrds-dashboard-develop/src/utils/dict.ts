/**
 * 全局常量数据字典
 * @author Nan
 * @description 用来配置全站的常量数据，开发中使用常量变量进行开发。
 */

const DICT: any = {}

// 语言-中文
DICT.LANGUAGE_CH = 'zh-CN'
// 语言-英文
DICT.LANGUAGE_EN = 'en'
// 是否-是
DICT.YESORNO_YES = 1
// 是否-否
DICT.YESORNO_NO = 0
// 是否-默认（为默认空值准备）
DICT.YESORNO_DEFAULT = -1
// 真假-真
DICT.BOOLEAN_TRUE = 1
// 真假-否
DICT.BOOLEAN_FALSE = 0
// 真假-默认（为默认空值准备）
DICT.BOOLEAN_DEFAULT = -1

DICT.TIME_OPTIONS = {
  shortcuts: [{
    text: '最近一周',
    onClick(picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近一个月',
    onClick(picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
      picker.$emit('pick', [start, end])
    }
  }, {
    text: '最近三个月',
    onClick(picker) {
      const end = new Date()
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
      picker.$emit('pick', [start, end])
    }
  }]
}

/**
 * 匹配公式的正则
 */
DICT.FORMULAREG = /\$_formula_widget_((\d+)|((\d+)\.widget_(\d+)))#/mg

/**
 * 常用单元格管理
 */
// 任务(简易任务分派单、单方任务分派单、双方任务分派单)
DICT.TEMPLATE_TYPE_TASK_ALL = 1
DICT.TEMPLATE_TYPE_TASK_ALL_NAME = '任务'


export default DICT

