/**
 * 该文件主要书写通用的小处理
 * @author Nan
 */

import * as _ from 'lodash';

namespace Format {
  /** 
   * JSON或是基础类型数据'trim'方法;
  */
  export const trim = (params: any) => {
    // 数据直接是字符串
    if (_.isString(params)) {
      params = _.trim(params);
    } else if (_.isArray(params)) {
      params.forEach((param: any) => {
        param = trim(param);
      });
    } else if (_.isObject(params)) {
      for (let key in params) {
        params[key] = trim(params[key]);
      }
    }
    return params;
  };

  /**
   * JSON数组排序方法
   * @param collection - 待处理数据集合
   * @param iteratee - 迭代器
   * @param orders - 升序/降序
   */
  export const sortBy = (collection: Array<object> | object, iteratee: string, orders?: 'asc' | 'desc') => {
    return _.sortBy(collection, (item: object) => {
      if (orders === undefined || orders === 'asc') {
        return item[iteratee];
      }
      return -item[iteratee];
    });
  }
}

// let users = [
//   { 'user': 'fred',   'age': 48 },
//   { 'user': 'barney', 'age': 36 },
//   { 'user': 'fred',   'age': 40 },
//   { 'user': 'barney', 'age': 34 }
// ];
// let test = Format.sortBy(users, 'age');
// users = test;
// console.log(test, users);

export default Format;
