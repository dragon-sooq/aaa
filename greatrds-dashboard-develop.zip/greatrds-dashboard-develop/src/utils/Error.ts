/**
 * Customized Error Types
 * @author Nan
 * @description: In this file, we customized several types of error for our development. Everyone can use these error types
 *               in thire project.
 * @action : Take attention and be carefull to use these error types, because all of these error types are blocking classes.
 */

/**
 * Normal Error
 * @description Users can defined the error info.
 */
export class CustomError extends Error {
  constructor(message: string) {
    super(message)
    this.name = '[Custom Error]';
    (Error as any).captureStackTrace(this, this.constructor)
  }
}

/**
 * Params Error
 * @description Params Not Defined
 */
export class ParamsMissingError extends Error {
  constructor(param: string) {
    super(param)
    this.name = '[Params Missing Error]'
    this.message = `Parmas of ${param} is needed, but not defined.`;
    (Error as any).captureStackTrace(this, this.constructor)
  }
}

/**
 * Arguments Error
 * 
 * @param {Any} param : Argument
 * @param {String} type : parameter type. 
 * @description Arguments's type are not assignable to parameters type.
 */
export class ArgumentsTypeError extends Error {
  constructor(param: any, type: string) {
    super(param)
    this.name = '[Arguments Type Error]'
    this.message = `Argument of type '${param}' is not assignable to parameter of type '${type}'.`;
    (Error as any).captureStackTrace(this, this.constructor)
  }
}

/**
 * Arguments Error
 * 
 * @param {Any} param : Argument
 * @param {Any} range : Parameter allowed value.
 * @description Parameter's value is not one of the allowed values.
 */
export class ArgumentsRangeError extends Error {
  constructor(param: any, range: any) {
    super(param)
    this.name = '[Arguments Range Error]'
    this.message = `The value passed in the parameter "${param}" is incorrect. Values are only allowed to be one of "${range}".`;
    (Error as any).captureStackTrace(this, this.constructor)
  }
}
