/**
 * 用户token
 */
import Vue from '@/compkg/configs/main'
let { $axios, $confirm } = Vue.prototype

/**
 * 跳转到登录页
 */
const goLoginConfirm = () => {
  return $confirm('登录信息已过期,请您重新登录', '系统提示', {
    confirmButtonText: '确定',
    showConfirmButton: true,
    showCancelButton: false,
    showClose: false,
    closeOnClickModal: false,
    closeOnPressEscape: false
  })
}

/**
 * 获取token
 */
const getToken = async(refreshToken: string) => {
  if (window['isFetchTokening']) {
    return Promise.reject('tokenGetting')
  }
  const tokenData = await $axios.post('u/token/referesh', {
    refreshToken,
    skipLoading: true,
    skipAuth: true
  })
  window['isFetchTokening'] = false
  return tokenData
}

/**
 * 校验token
 * @param userToken
 */
const verifyToken = (userToken: any) => {
  let { refreshToken, tokenExpireTime } = userToken
  return new Promise((resolve) => {
    let now = new Date().getTime() + 3 * 60 * 1000 // 提前3分钟
    if (tokenExpireTime < now) {
      console.warn('当前用户token已过期，开始刷新token')
      return getToken(refreshToken)
    }
    resolve()
  })
}

export {
  verifyToken,
  getToken,
  goLoginConfirm
}
