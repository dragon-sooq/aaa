/**
 * All the request api router for web browser.
 * @author Nan
 */
// name项目名称：web\rds
// platform 当前项目环境 dev\te\st\pre\prod
import { platform as PLARFORM, name } from '../../config/project.env.dev'
const PROTOCOL: string = PLARFORM === 'dev' ? 'http://' : 'https://'
// const serverType = String(process.env.SERVER_TYPE) || 'local';
// console.log(serverType);

const ROUTERS: any = {
  web: {// 默认webapi
    dev: '172.16.70.243/v1/',
    te: 'te-webgateway.123eblog.com/rest/',
    st: 'st-webgateway.123eblog.com/rest/',
    pre: 'pr-webgateway.123eblog.com/rest/',
    prod: 'webgateway.123eblog.com/rest/',
    usp: '',
    ucapi: ''
  }
}

// api映射表
const ApiPlatform = {
  dev: '',
  te: 'te-',
  st: 'st-',
  pre: 'pr-',
  prod: '',
  usp: '',
  ucapi: ''
}
const ApiHostName = {
  dev: {
    web: '172.16.70.243:9018',
    system: '192.168.60.189:16161',
    admin: '192.168.60.189:18787'
  },
  other: {
    web: 'webgateway.123eblog.com',
    system: 'companyadmin.123eblog.com',
    admin: 'adminapi.123eblog.com'
  }
}

/**
 * 获取指定使用api前缀 基于当前启动环境
 * @param useType web\system\admin
 */
const getApiPrefix = (useType?: string) => {
  useType = useType || 'web'
  if (PLARFORM === 'dev') {
    return PROTOCOL + ApiHostName[PLARFORM][useType]
  }
  // https:// + te- + webgateway.123eblog.com
  return PROTOCOL + ApiPlatform[PLARFORM] + ApiHostName['other'][useType]
}

let tempRoute = ROUTERS[name] ? ROUTERS[name] : ROUTERS.web
const API: string = PROTOCOL + (tempRoute[PLARFORM] ? tempRoute[PLARFORM] : tempRoute.te)
// console.log(API)

export {
  API,
  getApiPrefix
}
