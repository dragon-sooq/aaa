/**
 * url相关处理
 */

/**
 * urlParse参数解析
 */
export const urlParse = (url: string) => {
  let urltemp = url || window.location.search
  let obj = {}
  let reg = /[?&][^?&]+=[^?&]+/g
  if (urltemp.indexOf('?') !== 0) {
    urltemp = '?' + urltemp
  }
  let arr = urltemp.match(reg)
  // ['?id=12345','&a=b']
  if (arr) {
    arr.forEach((item) => {
      let tempArr = item.substr(1).split('=')
      let key = decodeURIComponent(tempArr[0])
      let val = decodeURIComponent(tempArr[1])
      obj[key] = val
    })
  }
  return obj
}

/**
* 获取浏览器链接中？传递的参数
* @param  {[type]} val [description]
* @return {[type]}     [description]
*/
export const getRequestLinkStr = (href?, val?) => {
  // 获取参数
  let hrefNew = href || location.href
  let search = hrefNew.substring(hrefNew.lastIndexOf('?') + 1, hrefNew.length)
  // 组装?
  let uri = '?' + search
  let re = new RegExp('' + val + '=([^&?]*)', 'ig')
  let matchArr = uri.match(re)
  if (matchArr && matchArr.length) {
    return matchArr[0].substr(val.length + 1)
  }
  return null
}

/**
 * 获取当前页面的url
 */
export const getLocationHref = () => {
  let url: string = ''
  if (parent !== window) {
    try {
      url = parent.location.href
    } catch (e) {
      url = document.referrer
    }
  } else {
    url = window.location.href
  }
  return url
}

/**
  * Unicode编码
  */
/* eslint-disable */
// const uniEncode = (a) => {
//   if (!a) {
//     return '';
//   }
//   a = escape(a.toString()).replace(/\+/g, "%2B");
//   var b = a.match(/(%([0-9A-F]{2}))/gi);
//   if (b)
//     for (var c = 0; c < b.length; c++) {
//       var d = b[c].substring(1, 3);
//       parseInt(d, 16) >= 128 && (a = a.replace(b[c], "%u00" + d))
//     }
//   return a = a.replace("%25", "%u0025").replace(/%/g, "\\"), a
// };
/**
 * UniDecode解码
 */
/* eslint-disable */
const uniDecode = (a) => {
  if (!a) {
    return '';
  }
  a = a.replace(/\\/g, "%").replace("%u0025", "%25"), a = unescape(a.toString().replace(/%2B/g, "+"));
  var b = a.match(/(%u00([0-9A-F]{2}))/gi);
  if (b)
    for (var c = 0; c < b.length; c++) {
      var d = b[c].substring(1, 3),
        e = Number("0x" + d);
      e >= 128 && (a = a.replace(b[c], d))
    }
  return a = unescape(a.toString().replace(/%2B/g, "+")), a
}

/**
 * 转换参数
 * @param  {[type]} url [description]
 * @return {[type]}     [description]
 */
export const parseQueryString = (opts: any = {}) => {
  let url = opts && opts.url ? opts.url : window.location.hash;
  //对url进行解码
  url = decodeURI(url);
  let reqParams: any = {};
  if (url.indexOf("?") > -1) {
    let str = url.split("?")[1], strs = str.split("&");
    strs.forEach(function (tempStr: string) {
      let tempArr = tempStr.split("=");
      if (tempArr[0]) {
        reqParams[tempArr[0]] = uniDecode(tempArr[1]);
      }
    });
  }
  return reqParams;
};

/**
 * 下载链接
 * @param  {[type]} url [description]
 * @return {[type]}     [description]
 */
export const openNewWindowLink = (opts: any = {}) => { //在新窗口中打开
  let openLink = document.querySelector("#openNewWindowLink");
  if (!openLink) {
    let domA = document.createElement("a");
    domA.setAttribute('href', '');
    domA.setAttribute('target', '_blank');
    domA.setAttribute('id', 'openNewWindowLink');
    let body = document.querySelector('body');
    if (body) {
      body.appendChild(domA);
    }
    openLink = domA;
  }
  if (!opts.notDownload) {
    openLink.setAttribute('href', opts.url);
    if (opts.downName) {
      openLink.setAttribute('download', opts.downName);
    }
  } else {
    openLink.removeAttribute('download');
    openLink.setAttribute('href', opts.url);
  }
  setTimeout(function () {
    openLink && (openLink as any).click();
  }, 100);
};

