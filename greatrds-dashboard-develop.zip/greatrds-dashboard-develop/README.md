

# greatRDS

## Project setup
```
1. Installation dependence

npm install

2. build dll

npm run build:dll

3. Don't track project auto configuration files

git rm -r -n --cached .

git update-index --assume-unchanged config/project.env.dev.js

git update-index --assume-unchanged config/project.env.build.js

4、开启可以检测到文件名大小写的更改

git config core.ignorecase false

```

### Compiles and hot-reloads for development

#### 1. Command rules

```
npm [Command] [project-name]

[Command]: start / run [Command-name]
[project-name]: admin | web | wt | tech | system

const projectHashName = {
  rds: 'rds',
  db: 'db',
}
```

#### 2. Default Command Information

```
npm start [project-name] # test environment
npm run te [project-name] # test environment
npm run dev [project-name] # development environment
npm run st [project-name] # st environment

//例如：启动"rds" rds te测试环境
npm run te rds
```

### Compiles and minifies for production
```
# main command
npm run build [project-name]

# sub command
npm run build [project-name] # production environment
npm run build:st [project-name] # st environment
npm run build:dev [project-name] # devlopment environment
npm run build:te [project-name] # test environment

//例如：构建"技术开发平台" tech 正式环境
npm run build tech
//例如：构建"技术开发平台" tech 开发环境
npm run build:dev tech

//例如：构建"web端" web te测试环境
npm run build:te web
```

### Run Test

[description] : To run the test environment or run the unit / e2e test, use the test command below. You can run the test to each project by adding a project name after the main command below。

```
npm run test:e2e [project-name]
npm run test:unit [project-name]
```

### git

```
提交规范：
feat：新需求/组件
fix：修复某一bug结尾附带bug编号
docs：文档（documentation）
style： 格式（不影响代码运行的变动）
refactor：重构（即不是新增功能，也不是修改bug的代码变动）
test：增加测试
chore：构建过程或辅助工具的变动

例如：
修改用户的头像xxx
提交时写成：
fix：修改用户中心的头像xxx（bug1000）
—————————————— 
```

### ts

```js
// 类定义参考写法
interface RouteConfig = {
  path: string,
  component?: Component,
  name?: string, // 命名路由
  components?: { [name: string]: Component }, // 命名视图组件
  redirect?: string | Location | Function,
  props?: boolean | Object | Function,
  alias?: string | Array<string>,
  children?: Array<RouteConfig>, // 嵌套路由
  beforeEnter?: (to: Route, from: Route, next: Function) => void,
  meta?: any,

  // 2.6.0+
  caseSensitive?: boolean, // 匹配规则是否大小写敏感？(默认值：false)
  pathToRegexpOptions?: Object // 编译正则的选项
}
```

### js

```js
<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator';
// import esService from '@/compkg/services/esService.js';

@Component
export default class Home extends Vue {
  // data
  homeTitle: string = this.$vars.splitStr;

  created() {
    let that = this;
    that.init();
    // let aa = esService.uuid();
  }

  async init() {
    let that = this;
    let res = await that.$axios.post('https://te-webgateway.123eblog.com/rest/usercenter/u/login', {
      'mobile': 13261033532,
      'password': '96e79218965eb72c92a549dd5a330112',
      'countryCode': '+86',
      'skipAuth': true
    });
  }
}
</script>
```


```js
<script lang='ts'>
//vue-property-decorator使用指南
//https://juejin.im/post/5c173a84f265da610e7ffe44

import { Component, Vue, Prop, Watch, Emit } from "vue-property-decorator";
import HelloWorld from "@/components/HelloWorld";

@Component({
  components: {
    HelloWorld
	},
	directives: {
		focus: {
			// 指令的定义
			inserted: function (el) {
				el.focus()
			}
		}
	}
})
export default class App extends Vue {
  //data
	count = 0;

	// 初始数据可以直接声明为实例的属性
  message: string = 'Hello!'

  // 组件方法也可以直接声明为实例的方法
  onClick (): void {
    window.alert(this.message)
  }

  // computed
  get loginUser() {
    let { userInfo } = this.$store.getters;
    return userInfo;
  }

  //prop
  @Prop(String)
    propA: string;

  @Prop([String, Number])
    propB: string | number;

  @Prop({
    type: String, // type: [String , Number]
    default: "default value", // 一般为String或Number
    //如果是对象或数组的话。默认值从一个工厂函数中返回
    // defatult: () => {
    //     return ['a','b']
    // }
    required: true,
    validator: value => {
      return ["InProcess", "Settled"].indexOf(value) !== -1;
    }
  })
  propC: string;

  //watch
  @Watch('person', { immediate: true, deep: true })
    onPersonChanged(val: string, oldVal: string) {

    }

  //emit
  @Emit('addcount')
  addToCount(n: number) {
    this.count += n
  }

  @Emit('promise')
  promise() {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(20)
      }, 0)
    })
  }

}
</script>
```

```js
<template>
  <div>
    Demo
  </div>
</template>

<script lang='ts'>
import { Vue, Component } from 'vue-property-decorator';
import { Getter, namespace } from 'vuex-class';
import Utils from '@/utils';
import DICT from '@/utils/dict';
const companyModule = namespace('company');

@Component
class LayoutComponent extends Vue {
  @companyModule.Getter('companyId') companyId;

}

export default LayoutComponent;
</script>
```

```
// bak
// import { abs } from 'formula';
// console.log(FormulaUtils('sum(1,2,3) + 2 + abs([-1])'));
// console.log(FormulaUtils('sum(1,2,3) + 2 + abs(-1)'));
```

### Eslint 说明

1. 项目配置了eslint校验，

   a. 项目会对”git commit **” 做预处理钩子执行，进行eslint规则校验

   b. 校验通过则可以**提交成功**

   c. 校验不通过则返回错误信息，**提交不成功**

2. 禁止使用 git —no-verify 以达到屏蔽校验而进行提交动作

3. 可根据使用习惯对编辑器进行配置，达到实时规则校验(配置参考：Vscode 编辑器配置eslint指引)

### Vscode 编辑器配置eslint指引

1. 在编辑器中安装eslint校验运行工具，推荐：ESLint

2. 打开编辑器的首选项 > 偏好设置 > 用户/工作区 > 找到 eslint 工作配置项

3. 勾选符合自己使用习惯的配置项

4. 让编辑器支持在vue文件中进行自动校验及在保存（ctrl + s）时自动修正

   a. 打开vscode的settings.json

   b. 在配置项"settings"中添加一下代码：

   ```json
   # vscode -> settings.json -> settings

   "settings": {
   		"eslint.alwaysShowStatus": true,
   		"eslint.autoFixOnSave": true,
   		"editor.tabSize": 2,
   		"files.associations": {
   			"*.vue": "vue",
   			"*.jsx": "jsx"
   		},
   		"eslint.options": {
   			"extensions": [
   				".js",
   				".vue"
   			]
   		},
   		"eslint.validate": [
   			"javascript",
   			"javascriptreact",
   			{
   				"language": "vue",
   				"autoFix": true
   			},
   			"html",
   			"vue",
   			{
   				"language": "jsx",
   				"autoFix": true
   			},
   			"jsx"
   		],
   	}
   ```
5.
