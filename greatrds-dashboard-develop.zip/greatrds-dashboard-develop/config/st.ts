let projectName = process.argv[2];
let fs = require('fs');

fs.writeFileSync( './config/project.env.dev.js', `exports.name = '${ projectName }';\nexports.platform = 'st';`);

let exec = require('child_process').execSync;
exec('vue-cli-service serve', {stdio: 'inherit'});