/**
 * 项目启动的相关配置及自动化设置。
 * @author Nan
*/

// 运行环境
let platform = String(process.env.PROJECT_PLATFORM) || 'te';

// 启动类型 local-本地 prod-打包
let serverType = String(process.env.SERVER_TYPE) || 'local';

// 存储构建相关变量的文件位置
let projectConfFile, commond;

if ( serverType === 'dev' ) {
  projectConfFile = './config/project.env.dev.js';
  commond = 'vue-cli-service serve';
} else if ( serverType === 'prod' ) {
  projectConfFile = './config/project.env.build.js';
  commond = 'vue-cli-service build';
} else {
  projectConfFile = './config/project.env.dev.js';
  commond = 'vue-cli-service serve';
}

// 即将构建的项目名称
let projectName = process.argv[ 2 ];
let fs = require('fs');

fs.writeFileSync( `${projectConfFile}`, `exports.name = '${ projectName }';\nexports.platform = ${platform};`);

// 同步进程执行命令
let exec = require('child_process').execSync;
exec(`${commond}`, {stdio: 'inherit'});