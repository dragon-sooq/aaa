let projectName = process.argv[2];
let fs = require( 'fs' );
console.log(process.env.PROJECT_PLATFORM);
console.log(process.env.SERVER_TYPE);
fs.writeFileSync( './config/project.env.dev.js', `exports.name = '${ projectName }';\nexports.platform = 'te';`);

let exec = require( 'child_process' ).execSync;
exec('vue-cli-service serve', {stdio: 'inherit'});