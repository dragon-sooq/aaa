exports.name = 'dev';
exports.platform = 'st';