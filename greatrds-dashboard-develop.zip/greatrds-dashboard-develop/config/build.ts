let projectName = process.argv[ 2 ];
let fs = require('fs');

fs.writeFileSync( './config/project.env.build.js', `exports.name = '${ projectName }';\nexports.platform = 'prod';`);

let exec = require('child_process').execSync;
exec('vue-cli-service build', {stdio: 'inherit'});