// 启动类型 local-本地 prod-打包
const serverType = String(process.env.SERVER_TYPE) || 'local';
if (serverType === 'dev') {
  projectConfFile = './project.env.dev.js';
} else if ( serverType === 'prod' ) {
  projectConfFile = './project.env.dev.js';
} else {
  projectConfFile = './project.env.dev.js';
}

const { name, platform } = require(`${projectConfFile}`);
const projectFileName = name; // 构建的项目名称
const runPlatformt = platform; // 项目运行平台

console.log(`Project start build on ${process.env.NODE_ENV} environment.\n`);
console.log(`Build ${name} project start.\n`);
console.log(`Project will running at "${runPlatformt}" site.\n`);

const projectHashName = {
  db: 'dataAdmin',
  rds: 'rds',
}

let projectFilePath = '';
let projectName = '';
if (projectFileName === 'db') {
  projectFilePath = `src/projects/${projectHashName.db}/main.ts`;
  projectName = projectHashName.db;
} else if (projectFileName === 'rds') {
  projectFilePath = `src/projects/${projectHashName.rds}/main.ts`;
  projectName = projectHashName.rds;
} else {
  console.error('Build Error. Please check you setup commond, confirm the project name is insert.');
}

const CONFIG = {
  projectFilePath: projectFilePath,
  environment: runPlatformt,
  projectName: projectName
};

module.exports = CONFIG;
