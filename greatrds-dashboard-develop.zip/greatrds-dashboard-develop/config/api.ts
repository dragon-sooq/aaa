/**
 * All the request api router for web browser.
 * @author Nan
 * @description
 * @copyright
 */
const { platform } = require('./project');
// console.log(platform);

const PROTOCOL: string = 'https://';

// Init the router's configure interface.
interface initRouter
{
  dev: string,
  te: string,
  st: string,
  stb: string,
  prod: string,
  pre: string
}

const ROUTERS: initRouter = {
  dev: '172.16.70.243:9018/v1/',
  te: 'te-webgateway.123eblog.com/rest/',
  st: 'st-webgateway.123eblog.com/rest/',
  stb: 'stb-webgateway.123eblog.com/rest/',
  prod: 'webgateway.123eblog.com/rest/',
  pre: 'pr-webgateway.123eblog.com'
};

let ROUTER: string = '';
if (platform === 'te') {
  ROUTER = ROUTERS.te;
} else if (platform === 'dev') {
  ROUTER = ROUTERS.dev;
} else if (platform === 'st') {
  ROUTER = ROUTERS.st;
} else if (platform === 'stb') {
  ROUTER = ROUTERS.stb;
} else if (platform === 'prod') {
  ROUTER = ROUTERS.prod;
} else if (platform === 'pre') {
  ROUTER = ROUTERS.prod;
}

const API:string = PROTOCOL + ROUTER;

export default API;
