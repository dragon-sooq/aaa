/**
 * Configure for the development environment.
 * @author Nan
 *
 * @description
 *
 * @copyright
 *
 * @time 2019-08-08 17:10:51
 *
*/

interface ENV
{
  NODE_ENV: String,
  NAME: String,
  PORT: Number,
  API: String,
  PROTOCOL: String,
}

const config: ENV = {
  NODE_ENV: 'development',
  NAME: 'Etings Development',
  PORT: 8090,
  API: '',
  PROTOCOL: 'https://',
}

export default config;