/**
 * 项目启动的相关配置及自动化设置。
 * @author Nan
*/

const path = require('path');

// 运行环境
const platform = String(process.env.PROJECT_PLATFORM) || 'te';

// 启动类型 local-本地 prod-打包
const serverType = String(process.env.SERVER_TYPE) || 'local';

// 存储构建相关变量的文件位置
let projectConfFile, commond;

if (serverType === 'dev') {
  projectConfFile = path.resolve(__dirname, './project.env.dev.js');
  commond = 'vue-cli-service serve';
} else if (serverType === 'prod') {
  projectConfFile = path.resolve(__dirname, './project.env.dev.js');
  commond = 'vue-cli-service build';

  console.info('Please take attention. You are running build project for deploy, make sure the project name is right.');
} else if (serverType === 'test:e2e') {
  projectConfFile = path.resolve(__dirname, './project.env.dev.js');
  commond = 'vue-cli-service test:e2e --collectCoverage';
} else if (serverType === 'test:unit') {
  projectConfFile = path.resolve(__dirname, './project.env.dev.js');
  commond = 'vue-cli-service test:unit --collectCoverage --watch';
} else {
  projectConfFile = path.resolve(__dirname, './project.env.dev.js');
  commond = 'vue-cli-service serve';
}
// 即将构建的项目名称
let projectName = process.argv[2];
let fs = require('fs');

fs.writeFileSync(`${projectConfFile}`, `exports.name = '${projectName}';\nexports.platform = '${platform}';\n`);

// 同步进程执行命令
let exec = require('child_process').execSync;
exec(`${commond}`, { stdio: 'inherit' });
