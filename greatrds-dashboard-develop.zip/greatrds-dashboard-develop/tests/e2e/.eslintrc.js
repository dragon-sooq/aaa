module.exports = {
  plugins: [
    'cypress'
  ],
  env: {
    'cypress/globals': true,
    jest: true
  },
  rules: {
    strict: 'off'
  }
}
