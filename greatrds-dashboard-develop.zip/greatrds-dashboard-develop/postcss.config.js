module.exports = {
  'plugins': {
    'autoprefixer': {}
  }
}
